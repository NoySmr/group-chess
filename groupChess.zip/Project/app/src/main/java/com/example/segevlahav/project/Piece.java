package com.example.segevlahav.project;

import java.io.Serializable;
import java.util.ArrayList;

/**
 * Piece
 * This class save all the information we need about any piece. its moves, its position, its type and etc.
 */
public abstract class Piece implements Serializable {
    protected int moves; // number of moves its made
    protected int position; // current position
    protected char type; // the piece type (queen/king/rook/knight/bishop/pawn)
    protected boolean alive; // is the piece alive or not
    protected char team; // the team the piece belongs to.

    /**
     * Piece
     * constructor
     */
    Piece () {
        this.moves = 0;
        this.alive = true;
    }

    /**
     * getMoves
     * @return the moves the piece has made. If the piece has killed return -1.
     */
    public int getMoves() {
        if (this.alive) {
            return this.moves;
        }
        return -1;
    }

    /**
     * getPosition
     * @return the piece current position
     */
    public int getPosition() {
        return this.position;
    }

    /**
     * getAlive
     * @return true - if the piece alive.
     *         false - otherwise.
     */
    public boolean getAlive() {
        return this.alive;
    }

    /**
     * getType
     * @return the type of the piece.
     */
    public char getType() {
        return this.type;
    }

    /**
     * getTeam
     * @return the team the piece belongs to.
     */
    public char getTeam() {
        return this.team;
    }

    /**
     * setPosition
     * @param position - the position the piece is in it.
     */
    public void setPosition(int position) {
        this.position = position;
    }

    /**
     * setAlive
     * kill the piece (set "alive" to false).
     */
    public void setAlive() {
        this.alive = false;
    }

    /**
     * incrementMoves
     * Increment the piece moves.
     */
    public void incrementMoves() {
        this.moves++;
    }

    /**
     * sameTeam
     * checks if pieceA and pieceB are at the same team.
     * @param pieceA - first piece
     * @param pieceB - second piece
     * @return true - if pieceA and pieceB are at the same team.
     *         false - otherwise.
     */
    protected boolean sameTeam(int pieceA, int pieceB) {
        pieceA = (pieceA - 1) / Defines.NUMBER_OF_PIECES;
        pieceB = (pieceB - 1) / Defines.NUMBER_OF_PIECES;
        if (pieceA == pieceB) {
            return true;
        }
        return false;
    }

    /**
     * getPossibleMoves
     * @param position - the piece position
     * @param board - the board matrix
     * @param turn - the team the turn belongs to her
     * @return all the valid moves the piece can move.
     */
    abstract public ArrayList<Integer> getPossibleMoves(final int position, final int[] board, char turn);

    /**
     * getPossibleMovesFourDGame
     * @param position - the piece position
     * @param board - the board matrix
     * @param turn - the team the turn belongs to her
     * @return all the valid moves the piece can move for the 4D game.
     */
    abstract public ArrayList<Integer> getPossibleMovesFourDGame(final int position, final int[] board, char turn);
}
