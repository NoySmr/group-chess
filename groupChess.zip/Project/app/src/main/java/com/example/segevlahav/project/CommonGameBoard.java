package com.example.segevlahav.project;

import java.io.Serializable;

/**
 * CommonGameBoard
 * This class contains all the information about the state of the common game board. The pieces positions,
 * the team that the turn is its, the number of the moves that has been played, the manager of the game
 * and etc.
 */
public class CommonGameBoard extends GameBoard implements Serializable {

    /**
     * CommonGameBoard
     * constructor
     * @param isManager - true - if the user is the manager (the one who created the game).
     *                    false - otherwise.
     */
    CommonGameBoard(boolean isManager) {
        super();
        this.isManager = isManager;
    }

    /**
     * turnHasChanged
     * rotate the board in 180 degrees and doing super.turnHasChanged
     */
    public void turnHasChanged() {
        this.reverseBoard();
        super.turnHasChanged();
    }

    /**
     * addMoveToList
     * adding a move to the log of the game (the log contains all the moves that has been played so
     * far).
     * @param value - the value of the piece (1 - black rook, 2 - black knight ...)
     * @param to - the position the piece moved to
     * @param from - the last position of the piece (where it came from)
     */
    public void addMoveToList(int value, int to, int from) {
        if (value == Defines.BLACK_KING) { // case the piece is the black king
            if (from > to) {
                if (from - to == 2) { // big castling
                    this.moveItems.add(new MoveItem("O-O-O", "", value));
                    return;
                }
            } else if (to - from == 2) { // small castling
                this.moveItems.add(new MoveItem("O-O", "", value));
                return;
            }
        } else if (value == Defines.WHITE_KING) { // case the piece is the white king
            if (from > to) {
                if (from - to == 2) { // small castling
                    this.moveItems.add(new MoveItem("O-O", "", value));
                    return;
                }
            } else if (to - from == 2) { // big castling
                this.moveItems.add(new MoveItem("O-O-O", "", value));
                return;
            }
        }
        if (turn == 'W') { // in case it is not a castling
            this.moveItems.add(new MoveItem(convertingPosition(from), convertingPosition(to), value));
        } else {
            this.moveItems.add(new MoveItem(convertingPosition(BOARD_SIZE - 1 - from), convertingPosition(BOARD_SIZE - 1 - to), value));
        }
        return;
    }
}
