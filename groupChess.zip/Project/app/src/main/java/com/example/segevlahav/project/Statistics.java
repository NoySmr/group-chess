package com.example.segevlahav.project;

import java.io.Serializable;

/**
 * Statistics
 * This class save all the players statistics.
 */
public class Statistics implements Serializable {
    private int commonGames; // the number of common game the user has played
    private int commonDraw; // the number of draws in the common game
    private int groupWin; // the number of wins in the group game
    private int groupDraw; // the number of draws in the group game
    private int groupLose; // the number of loses in the group game
    private int fourDWin; // the number of wins in the 4D game
    private int fourDDraw; // the number of draws in the 4D game
    private int fourDLose; // the number of loses in the 4D game

    /**
     * Statistics
     * constructor
     */
    Statistics() {
        this.commonGames = 0;
        this.commonDraw = 0;
        this.groupWin = 0;
        this.groupDraw = 0;
        this.groupLose = 0;
        this.fourDWin = 0;
        this.fourDDraw = 0;
        this.fourDLose = 0;
    }

    /**
     * getCommonGames
     * @return the number of common game the user has played
     */
    public String getCommonGames() {
        return Integer.toString(this.commonGames);
    }

    /**
     * getCommonGames
     * @return the number of draws in the common game
     */
    public String getCommonDraw() {
        return Integer.toString(this.commonDraw);
    }

    /**
     * getCommonWinRate
     * @return the win rate in the common game
     */
    public String getCommonWinRate() {
        float commonGames = this.commonGames;
        float commonDraw = this.commonDraw;
        if (commonGames == 0 && commonDraw == 0) {
            return "-";
        } else {
            return Integer.toString(Math.round((commonGames / (commonGames + commonDraw)) * 100)) + Defines.PERCENT;
        }
    }

    /**
     * getGroupWin
     * @return the number of wins in the group game
     */
    public String getGroupWin() {
        return Integer.toString(this.groupWin);
    }

    /**
     * getGroupDraw
     * @return the number of draws in the group game
     */
    public String getGroupDraw() {
        return Integer.toString(this.groupDraw);
    }

    /**
     * getGroupLose
     * @return the number of loses in the group game
     */
    public String getGroupLose() {
        return Integer.toString(this.groupLose);
    }

    /**
     * getGroupWinRate
     * @return the win rate in the group game
     */
    public String getGroupWinRate() {
        float groupWin = this.groupWin;
        float groupDraw = this.groupDraw;
        float groupLose = this.groupLose;
        if (groupWin == 0 && groupDraw == 0 && groupLose == 0) {
            return "-";
        } else {
            return Integer.toString(Math.round((groupWin / (groupWin + groupDraw + groupLose)) * 100)) + Defines.PERCENT;
        }
    }

    /**
     * getFourDWin
     * @return the number of wins in the 4D game
     */
    public String getFourDWin() {
        return Integer.toString(this.fourDWin);
    }

    /**
     * getFourDDraw
     * @return the number of draws in the 4D game
     */
    public String getFourDDraw() {
        return Integer.toString(this.fourDDraw);
    }

    /**
     * getFourDLose
     * @return the number of loses in the 4D game
     */
    public String getFourDLose() {
        return Integer.toString(this.fourDLose);
    }

    /**
     * getFourDWinRate
     * @return the win rate in the 4D game
     */
    public String getFourDWinRate() {
        float fourDWin = this.fourDWin;
        float fourDDraw = this.fourDDraw;
        float fourDLose = this.fourDLose;
        if (fourDWin == 0 && fourDDraw == 0 && fourDLose == 0) {
            return "-";
        } else {
            return Integer.toString(Math.round((fourDWin / (fourDWin + fourDDraw + fourDLose)) * 100)) + Defines.PERCENT;
        }
    }

    /**
     * incrementCommonGames
     * increment the number of common game the user has played.
     */
    public void incrementCommonGames() {
        this.commonGames++;
    }

    /**
     * incrementCommonDraw
     * increment the number of common common game draws.
     */
    public void incrementCommonDraw() {
        this.commonDraw++;
    }

    /**
     * incrementGroupWin
     * increment the number of the group game wins.
     */
    public void incrementGroupWin() {
        this.groupWin++;
    }

    /**
     * incrementGroupDraw
     * increment the number of group game draws
     */
    public void incrementGroupDraw() {
        this.groupDraw++;
    }

    /**
     * incrementGroupLose
     * increment the number of group game loses
     */
    public void incrementGroupLose() {
        this.groupLose++;
    }

    /**
     * incrementFourDWin
     * increment the number of 4D game wins
     */
    public void incrementFourDWin() {
        this.fourDWin++;
    }

    /**
     * incrementFourDDraw
     * increment the number of 4D game draws
     */
    public void incrementFourDDraw() {
        this.fourDDraw++;
    }

    /**
     * incrementFourDLose
     * increment the number of 4D game loses
     */
    public void incrementFourDLose() {
        this.fourDLose++;
    }


}
