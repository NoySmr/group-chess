package com.example.segevlahav.project;

import android.app.Activity;
import android.app.FragmentManager;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.Toast;
import java.io.File;
import java.util.List;

/**
 * GroupGameController
 * This class is responsible of managing the game. It also responsible for the display of the game.
 */
public class GroupGameController extends GameController {

    /**
     * GroupGameController
     * constructor
     * @param context
     * @param gameCode - the code of the game
     * @param fileName - the name of the game details name
     */
    public GroupGameController(Context context, String gameCode, String fileName) {
        super(context, gameCode, fileName);
        File file = new File(context.getFilesDir() + "/" + gameCode);
        if(file.exists()) {
            this.board = FileManager.getGameBoard(context, gameCode);
        } else {
            this.board = new GroupGameBoard(false);
        }
        this.changeBoardFrame(((GroupGameBoard)this.board).getMyTeam());
        checkTurnMatch();
        checkGameState();
    }

    /**
     * setBoardView
     * This function is responsible for communicate with the user. The function checks if the user can
     * make a move (if it is turn or not, if he won't be in check if he will make this move, if the
     * game is not ove and etc.)
     * @param boardView - the chess board
     */
    @Override
    public void setBoardView(final GridView boardView) {
        this.boardView = boardView;
        this.boardAdapter = new GameController.BoardAdapter();
        this.boardView.setAdapter(this.boardAdapter);
        this.boardView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View v,
                                    int position, long id) {
                if (board.getGameState() == 'M' || board.getGameState() == 'P') {
                    // If the game is already over
                    return;
                }
                if (!board.isWaitingForPermission()) {
                    // If the user made a move and waiting for the manager to approve it.
                    boolean canMakeThatMove = false;
                    checkTurnMatch();
                    if (selectedNum > 0) {
                        // If the user clicked on a piece (pawn/rook/knight...)
                        if (positionNum == position) {
                            // In case the user clicked the same piece twice - is valid moves will
                            // disappear from the board (return the be regular squares instead of green)
                            canMakeThatMove = true;
                        }
                        if (possibleMoves.contains(position)) {
                            // If the user clicked on green square (valid move)
                            canMakeThatMove = true;
                            if (board.getIsManager()) {
                                // If the user is the manager of the game he can make the move
                                // without waiting for permission, and then he send messages about
                                // the move for the other players.
                                board.setValue(selectedNum, position, positionNum);
                                board.addMoveToList(selectedNum, position, positionNum);
                                board.checkEnPassant(selectedNum, position, positionNum);
                                if (board.needToChangePawn(position, selectedNum)) {
                                    // In case a pawn is in thee end of the board the application will
                                    // open a dialog for the user so he will change is pawn to other
                                    // game piece.
                                    final Activity activity = (Activity) context;
                                    FragmentManager manager = activity.getFragmentManager();
                                    Bundle bundle = new Bundle();
                                    bundle.putInt("position", position);
                                    ChangePawnDialog changePawn = new ChangePawnDialog();
                                    if (turn == 'W') { // In case the pawn was white.
                                        bundle.putChar("team", 'W');
                                        changePawn.setArguments(bundle);
                                        changePawn.show(manager, "whiteChange");
                                        return;
                                    } else { // In case the pawn was black
                                        bundle.putChar("team", 'B');
                                        changePawn.setArguments(bundle);
                                        changePawn.show(manager, "blackChange");
                                        return;
                                    }
                                }
                                // Send sms about the move for the other players.
                                sendSmsMove(positionNum, position, turn, board.getMoves(), 'O');
                                // Change the game turn in the game controller and the game board.
                                board.turnHasChanged();
                                changeTurn();
                                // Make the move sound
                                mediaPlayer.start();
                                // Check if check/math or draw
                                checkGameState();
                                switch (board.getGameState()) {
                                    case 'M':
                                        if (board.turn == ((GroupGameBoard)board).getMyTeam()) {
                                            statistics.incrementGroupLose();
                                        } else {
                                            statistics.incrementGroupWin();
                                        }
                                        FileManager.saveStatistics(context, statistics);
                                        break;
                                    case 'P':
                                        statistics.incrementGroupDraw();
                                        FileManager.saveStatistics(context, statistics);
                                        break;
                                    default:
                                        break;
                                }
                                // Save the game board with the last move
                                FileManager.saveGameBoard(context, gameCode, board);
                            } else { // In case the user is not the manager
                                if (board.needToChangePawn(position, selectedNum)) {
                                    // In case a pawn is in thee end of the board the application will
                                    // open a dialog for the user so he will change is pawn to other
                                    // game piece.
                                    final Activity activity = (Activity) context;
                                    FragmentManager manager = activity.getFragmentManager();
                                    Bundle bundle = new Bundle();
                                    bundle.putInt("position", position);
                                    ChangePawnDialog changePawn = new ChangePawnDialog();
                                    if (turn == 'W') { // In case the pawn was white.
                                        bundle.putChar("team", 'W');
                                        changePawn.setArguments(bundle);
                                        changePawn.show(manager, "whiteChange");
                                        return;
                                    } else { // In case the pawn was black.
                                        bundle.putChar("team", 'B');
                                        changePawn.setArguments(bundle);
                                        changePawn.show(manager, "blackChange");
                                        return;
                                    }
                                }
                                // Sending message about the move the user want to operate to the
                                // manger and waiting for approval. The user can't play till he will
                                // get a message from the manager.
                                sendToManager(positionNum, position, turn, board.getMoves(), 'O');
                                board.setWaitingForPermission(true);
                            }
                        }
                        // Clearing the board from all the valid moves and reset the variables.
                        int j = 0;
                        for (Integer i : possibleMoves) {
                            ((ImageView) boardView.getChildAt(i)).setBackground(squaresColors.get(j++));
                        }
                        ((ImageView) boardView.getChildAt(positionNum)).setBackground(squaresColors.get(j++));
                        possibleMoves.clear();
                        squaresColors.clear();
                        selectedNum = 0;
                        positionNum = 0;
                        dataSetChanged();
                    }
                    if (((GroupGameBoard) board).getMyTeam() == turn && !canMakeThatMove) {
                        // If the user clicked a new piece and it is the user turn
                        selectedNum = board.getValue(position);
                        positionNum = position;
                        if (checkMyTurn(selectedNum)) {
                            // If the user clicked on a piece that belong to the team that the turn
                            // is it.
                            possibleMoves = board.getPossibleMoves(position);
                            if (possibleMoves != null) {
                                // If the piece can move
                                // Color the valid squares that the clicked piece can move to.
                                for (Integer i : possibleMoves) {
                                    squaresColors.add(((ImageView) boardView.getChildAt(i)).getBackground());
                                    ((ImageView) boardView.getChildAt(i)).setBackgroundResource(R.drawable.valid_icon_background);
                                }
                                squaresColors.add(((ImageView) boardView.getChildAt(positionNum)).getBackground());
                                ((ImageView) boardView.getChildAt(positionNum)).setBackgroundResource(R.drawable.chosen_icon_background);
                            } else {
                                selectedNum = 0;
                            }
                        } else {
                            selectedNum = 0;
                        }
                    }
                } else {
                    // In case we made a move and waiting for the manager to approve his move.
                    Toast.makeText(context, "Waiting for permission", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }

    /**
     * handleChangePawn
     * This function is called when the user has chose to which piece he would like to change his
     * pawn to when his pawn got to the end of the board.
     * @param type - the type of the piece the user want to change his pawn to
     * @param position - the position the pawn is in it when we need to change him
     */
    public void handleChangePawn(char type, int position) {
        if (board.getIsManager()) {
            board.changePawn(position, type);
            sendSmsMove(positionNum, position, turn, board.getMoves(), type);
            board.turnHasChanged();
            changeTurn();
            FileManager.saveGameBoard(context, gameCode, board);
            int j = 0;
            for (Integer i : possibleMoves) {
                ((ImageView) boardView.getChildAt(i)).setBackground(squaresColors.get(j++));
            }
            ((ImageView) boardView.getChildAt(positionNum)).setBackground(squaresColors.get(j++));
            possibleMoves.clear();
            squaresColors.clear();
            selectedNum = 0;
            positionNum = 0;
            dataSetChanged();
        } else {
            sendToManager(positionNum, position, turn, board.getMoves(), type);
            board.setWaitingForPermission(true);
        }
    }

    /**
     * sendSmsMove
     * If the manager has made a move he send sms to the other players about the move so they will
     * commit it in their game.
     * @param lastPosition - the position the piece moved from.
     * @param newPosition - the position the piece is moving to.
     * @param turn - the turn of the game.
     * @param moves - the moves that has been played so far (for synchronized).
     * @param changePawn - let the other players know if there were a pawn changing.
     */
    @Override
    protected void sendSmsMove(int lastPosition, int newPosition, char turn, int moves, char changePawn) {
        SMSManager smsManager = new SMSManager();
        final GameDetails details = FileManager.getGameDetails(this.context, this.fileName);
        List<String> whiteNumbers = details.getTeamByCode(this.gameCode, 'W');
        List<String> blackNumbers = details.getTeamByCode(this.gameCode, 'B');
        String whiteMessage = SMSManager.messageIdentifier + " m " + this.gameCode;
        String blackMessage = SMSManager.messageIdentifier + " m " + this.gameCode;
        if (turn == 'B') {
            blackMessage += Defines.SPACE + Integer.toString(lastPosition);
            blackMessage += Defines.SPACE + Integer.toString(newPosition);
            whiteMessage += Defines.SPACE + Integer.toString((GameBoard.BOARD_SIZE - 1) - lastPosition);
            whiteMessage += Defines.SPACE + Integer.toString((GameBoard.BOARD_SIZE - 1) - newPosition);
        } else {
            whiteMessage += Defines.SPACE + Integer.toString(lastPosition);
            whiteMessage += Defines.SPACE + Integer.toString(newPosition);
            blackMessage += Defines.SPACE + Integer.toString((GameBoard.BOARD_SIZE - 1) - lastPosition);
            blackMessage += Defines.SPACE + Integer.toString((GameBoard.BOARD_SIZE - 1) - newPosition);
        }
        whiteMessage += Defines.SPACE + turn;
        blackMessage += Defines.SPACE + turn;
        whiteMessage += Defines.SPACE + Integer.toString(moves);
        blackMessage += Defines.SPACE + Integer.toString(moves);
        whiteMessage += Defines.SPACE + changePawn;
        blackMessage += Defines.SPACE + changePawn;
        whiteMessage += Defines.TILDA;
        blackMessage += Defines.TILDA;
        for (String smsNum : whiteNumbers) {
            smsManager.sendSMS(smsNum, whiteMessage);
        }
        for (String smsNum : blackNumbers) {
            smsManager.sendSMS(smsNum, blackMessage);
        }
    }

    /**
     * sendToManager
     * If the user is not the manager of the game he need to send message to the manager with the
     * play he want to do and wait fot the manager approval.
     * @param lastPosition - the position the piece moved from.
     * @param newPosition - the position the piece is moving to.
     * @param turn - the turn of the game.
     * @param moves - the moves that has been played so far (for synchronized).
     * @param changePawn - let the other players know if there were a pawn changing.
     */
    @Override
    protected void sendToManager(int lastPosition, int newPosition, char turn, int moves, char changePawn) {
        SMSManager smsManager = new SMSManager();
        final GameDetails details = FileManager.getGameDetails(this.context, this.fileName);
        List<String> whiteNumbers = details.getTeamByCode(this.gameCode, 'W');
        String manager = details.getManager(this.gameCode);
        if (whiteNumbers.contains(manager)) {
            String whiteMessage = SMSManager.messageIdentifier + " m " + this.gameCode;
            if (turn == 'B') {
                whiteMessage += Defines.SPACE + Integer.toString((GameBoard.BOARD_SIZE - 1) - lastPosition);
                whiteMessage += Defines.SPACE + Integer.toString((GameBoard.BOARD_SIZE - 1) - newPosition);
            } else {
                whiteMessage += Defines.SPACE + Integer.toString(lastPosition);
                whiteMessage += Defines.SPACE + Integer.toString(newPosition);
            }
            whiteMessage += Defines.SPACE + turn;
            whiteMessage += Defines.SPACE + Integer.toString(moves);
            whiteMessage += Defines.SPACE + changePawn;
            whiteMessage += Defines.TILDA;
            smsManager.sendSMS(manager, whiteMessage);
        } else {
            String blackMessage = SMSManager.messageIdentifier + " m " + this.gameCode;
            if (turn == 'B') {
                blackMessage += Defines.SPACE + Integer.toString(lastPosition);
                blackMessage += Defines.SPACE + Integer.toString(newPosition);
            } else {
                blackMessage += Defines.SPACE + Integer.toString((GameBoard.BOARD_SIZE - 1) - lastPosition);
                blackMessage += Defines.SPACE + Integer.toString((GameBoard.BOARD_SIZE - 1) - newPosition);
            }
            blackMessage += Defines.SPACE + turn;
            blackMessage += Defines.SPACE + Integer.toString(moves);
            blackMessage += Defines.SPACE + changePawn;
            blackMessage += Defines.TILDA;
            smsManager.sendSMS(manager, blackMessage);
        }
    }
}
