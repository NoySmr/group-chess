package com.example.segevlahav.project;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * ContactListActivity
 * In this activity we let the user choose contact for the groups. The user will get to that screen
 * after pressing the add button in the game board activities.
 */
public class ContactListActivity extends Activity {

    private MyCustomAdapter dataAdapter = null; // adapter of the contacts list
    private String gameName = ""; // the name of the group
    private int gamePicture = 0; // the icon of the group
    private String fileName = ""; // the game details file

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contant_list);

        Bundle bundle = getIntent().getExtras();
        try {
            gamePicture = bundle.getInt("gamePicture");
            gameName = bundle.getString("gameName");
            fileName = bundle.getString("fileName");
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        //Generate list View from ArrayList
        displayListView();

        checkButtonClick();
    }

    private void displayListView() {
        //Array list of countries
        ArrayList<ContactInfo> contactInfoList = new ArrayList<ContactInfo>();
        ContentResolver cr = getContentResolver();
        Cursor cur = cr.query(ContactsContract.Contacts.CONTENT_URI,
                null, null, null, null);

        if (cur.getCount() > 0) {
            while (cur.moveToNext()) {
                String id = cur.getString(
                        cur.getColumnIndex(ContactsContract.Contacts._ID));
                String name = cur.getString(cur.getColumnIndex(
                        ContactsContract.Contacts.DISPLAY_NAME));

                if (Integer.parseInt(cur.getString(cur.getColumnIndex(
                        ContactsContract.Contacts.HAS_PHONE_NUMBER))) > 0) {
                    Cursor pCur = cr.query(
                            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                            null,
                            ContactsContract.CommonDataKinds.Phone.CONTACT_ID + " = ?",
                            new String[]{id}, null);
                    while (pCur.moveToNext()) {
                        String phoneNo = pCur.getString(pCur.getColumnIndex(
                                ContactsContract.CommonDataKinds.Phone.NUMBER));
                        ContactInfo contactInfo = new ContactInfo(name,phoneNo);
                        contactInfoList.add(contactInfo);
                    }
                    pCur.close();
                }
            }
            ArrayList<ContactInfo> temp = new ArrayList<ContactInfo>();
            for (ContactInfo c : contactInfoList) {
                if (!temp.contains(c)) {
                    temp.add(c);
                }
            }
            //create an ArrayAdaptar from the String Array
            dataAdapter = new MyCustomAdapter(this,
                    R.layout.contacts_info, temp);
            ListView listView = (ListView) findViewById(R.id.contactList);

            // Assign adapter to ListView
            listView.setAdapter(dataAdapter);


            listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                public void onItemClick(AdapterView<?> parent, View view,
                                        int position, long id) {
                    // When clicked, show a toast with the TextView text
                    return;
                }
            });
        }
    }

    /**
     * MyCustomAdapter
     * To fit the contacts info to the list.
     */
    private class MyCustomAdapter extends ArrayAdapter<ContactInfo> {
        private ArrayList<ContactInfo> contactInfoList;

        /**
         * MyCustomAdapter
         * constructor
         * @param context
         * @param textViewResourceId
         * @param contactInfoList
         */
        public MyCustomAdapter(Context context, int textViewResourceId,
                               ArrayList<ContactInfo> contactInfoList) {
            super(context, textViewResourceId, contactInfoList);
            this.contactInfoList = new ArrayList<ContactInfo>();
            this.contactInfoList.addAll(contactInfoList);

            Collections.sort(this.contactInfoList, new Comparator<ContactInfo>() {
                @Override
                public int compare(ContactInfo o1, ContactInfo o2) {
                    return o1.getName().compareTo(o2.getName());
                }
            });
        }

        private class ViewHolder {
            TextView code; // the name of the participant
            CheckBox name; // a radio button to choose the team of the other participants
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            ViewHolder holder = null;

            if (convertView == null) {
                LayoutInflater vi = (LayoutInflater)getSystemService(
                        Context.LAYOUT_INFLATER_SERVICE);
                convertView = vi.inflate(R.layout.contacts_info, null);

                holder = new ViewHolder();
                holder.code = (TextView) convertView.findViewById(R.id.code);
                holder.name = (CheckBox) convertView.findViewById(R.id.checkBox1);
                convertView.setTag(holder);

                holder.name.setOnClickListener( new View.OnClickListener() {
                    public void onClick(View v) {
                        CheckBox cb = (CheckBox) v ;
                        ContactInfo contactInfo = (ContactInfo) cb.getTag();
                        contactInfo.setSelected(cb.isChecked());
                    }
                });
            }
            else {
                holder = (ViewHolder) convertView.getTag();
            }

            ContactInfo contactInfo = this.contactInfoList.get(position);
            holder.code.setText(" (" +  contactInfo.getNumber() + ")");
            holder.name.setText(contactInfo.getName());
            holder.name.setChecked(contactInfo.isSelected());
            holder.name.setTag(contactInfo);

            return convertView;
        }
    }

    /**
     * checkButtonClick
     * Check if the user chose at least one player for each team (except for the white team - because
     * he is in the white team). If the user chose players for all teams he get back to the previous
     * activity (the game list). Otherwise, a toast with the information about the problem is appears.
     */
    private void checkButtonClick() {
        Button myButton = (Button) findViewById(R.id.findSelected);
        myButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                ArrayList<ContactInfo> contactInfoList = dataAdapter.contactInfoList;
                List<ContactInfo> selectedContacts = new ArrayList<ContactInfo>();

                // initialize the contact info list
                for (int i = 0; i < contactInfoList.size(); i++) {
                    ContactInfo contactInfo = contactInfoList.get(i);
                    if (contactInfo.isSelected()) {
                        selectedContacts.add(contactInfo);
                    }
                }

                if (!selectedContacts.isEmpty()) {
                    // If the user chose at least one contact
                    if (fileName.equals(Defines.FOUR_D_GAME_FILE)) {
                        // If the user choose contacts for the 4D Game.
                        if (selectedContacts.size() >= 3) {
                            // Need at least three other people for the 4D Game
                            ContactInfo[] contactInfos = new ContactInfo[selectedContacts.size()];
                            selectedContacts.toArray(contactInfos);
                            Intent intent = new Intent(ContactListActivity.this, ChooseFourTeamsActivity.class);
                            intent.putExtra("fileName", fileName);
                            intent.putExtra("gameName", gameName);
                            intent.putExtra("gamePicture", gamePicture);
                            intent.putExtra("contacts", contactInfos);
                            startActivity(intent);
                        } else {
                            // In case the user didn't choose three people or more for the 4D Game
                            Toast.makeText(getApplicationContext(), "Please choose at least three contacts", Toast.LENGTH_LONG).show();
                        }
                    } else if (fileName.equals(Defines.GROUP_GAME_FILE)) {
                        // If the user choose contacts for the Group Game.
                        ContactInfo[] contactInfos = new ContactInfo[selectedContacts.size()];
                        selectedContacts.toArray(contactInfos);
                        Intent intent =  new Intent(ContactListActivity.this, ChooseTeamsActivity.class);
                        intent.putExtra("fileName", fileName);
                        intent.putExtra("gameName", gameName);
                        intent.putExtra("gamePicture", gamePicture);
                        intent.putExtra("contacts", contactInfos);
                        startActivity(intent);
                    } else {
                        // If the user choose contacts for the Common Game.
                        GameDetails gameDetails = FileManager.getGameDetails(ContactListActivity.this, fileName);
                        String gameId = FileManager.createId();
                        List<String> phoneNumbers = getNumbers(selectedContacts);
                        if (gameDetails == null) {
                            gameDetails = new GameDetails();
                        }
                        gameDetails.addCodeAndNameAndPhoneNumbersAndPicture(gameId, gameName, phoneNumbers, gamePicture, "manager");
                        gameDetails.setCodeAndNew(gameId, true);
                        FileManager.saveGameDetails(ContactListActivity.this, gameDetails, fileName);
                        FileManager.saveGameBoard(ContactListActivity.this, gameId, new CommonGameBoard(true));
                        smsCreateGame(gameId, phoneNumbers);
                        Intent intent = new Intent(ContactListActivity.this, GameListActivity.class);
                        intent.putExtra("fileName", fileName);
                        startActivity(intent);
                    }
                } else {
                    // In case the user didn't choose any contact at all.
                    Toast.makeText(getApplicationContext(), "Please choose contacts", Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    /**
     * getNumbers
     * @param contactInfos - contact info list
     * @return list that contains only the phone numbers of the players.
     */
    public List<String> getNumbers(List<ContactInfo> contactInfos) {
        List<String> numbers = new ArrayList<String>();
        for (ContactInfo c : contactInfos) {
            numbers.add(SMSManager.convertPhone(c.getNumber()));
        }
        return numbers;
    }

    /**
     * smsCreateGame
     * This function is for the common game.
     * This function send to each player sms message to let them know that a game as been created.
     * The sms contain the game name, game code, the phone numbers of the players, and the game icon.
     * @param code - the code of the game
     * @param numbers - the phone numbers of the players
     */
    private void smsCreateGame(String code, List<String> numbers) {
        SMSManager smsManager = new SMSManager();
        String smsMessage = SMSManager.messageIdentifier + " C " + code +
                Defines.SPACE + gameName + Defines.SPACE + Integer.toString(gamePicture) + Defines.TILDA;

        for (String smsNum : numbers) {
            String tempSms = smsMessage;
            for (String num : numbers) {
                if (!smsNum.equals(num)) {
                    tempSms += SMSManager.convertPhone(num);
                }
                tempSms += Defines.COLON;
            }
            smsManager.sendSMS(smsNum, tempSms);
        }
    }

}
