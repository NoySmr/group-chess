package com.example.segevlahav.project;

import java.io.Serializable;

/**
 * Settings
 * This class save all the information about the game settings the user chose.
 */
public class Settings implements Serializable {
    private char blackTile; // the black squares color
    private char whiteTile; // the white squares color
    private char blackPiece; // the black piece color
    private char whitePiece; // the white piece color
    private static final int[] TILES_IMAGES = { R.drawable.white_brown, R.drawable.white_green,
            R.drawable.yellow_red };
    private static final int[] PIECES_IMAGES = { R.drawable.black_white_king, R.drawable.red_white_king,
            R.drawable.blue_white_king, R.drawable.red_green_king, R.drawable.blue_green_king};
    private int tPosition; // tiles position - save the last position in the tiles array
    private int pPosition; // pieces position - save the last position in the piece array

    /**
     * Settings
     * constructor
     */
    Settings () {
        this.whitePiece = 'w';
        this.blackPiece = 'b';
        this.whiteTile = 'w';
        this.blackTile = 'b';
        this.tPosition = 0;
        this.pPosition  = 0;
    }

    /**
     * getWhiteTile
     * @return the white tiles color
     */
    public char getWhiteTile () {
        return this.whiteTile;
    }

    /**
     * getBlackTile
     * @return the black tiles color
     */
    public char getBlackTile () {
        return this.blackTile;
    }

    /**
     * getWhiteTile
     * @return the white pieces color
     */
    public char getWhitePiece () {
        return this.whitePiece;
    }

    /**
     * getBlackPiece
     * @return the black pieces color
     */
    public char getBlackPiece () {
        return this.blackPiece;
    }

    /**
     * changeTileColor
     * change the tiles color
     */
    private void changeTileColor() {
        switch (tPosition) {
            case 0:
                blackTile = 'b';
                whiteTile = 'w';
                break;
            case 1:
                blackTile = 'g';
                whiteTile = 'w';
                break;
            case 2:
                blackTile = 'r';
                whiteTile = 'y';
                break;
            default:
                blackTile = 'b';
                whiteTile = 'w';
        }
    }

    /**
     * changePieceColor
     * changes the pieces color
     */
    private void changePieceColor() {
        switch (pPosition) {
            case 0:
                blackPiece = 'b';
                whitePiece = 'w';
                break;
            case 1:
                blackPiece = 'r';
                whitePiece = 'w';
                break;
            case 2:
                blackPiece = 'k';
                whitePiece = 'w';
                break;
            case 3:
                blackPiece = 'r';
                whitePiece = 'g';
                break;
            case 4:
                blackPiece = 'k';
                whitePiece = 'g';
                break;
            default:
                blackPiece = 'b';
                whitePiece = 'w';
                break;
        }
    }

    /**
     * getCurrentTiles
     * @return the current color of tiles the user chose
     */
    public int getCurrentTiles() {
        return TILES_IMAGES[tPosition];
    }

    /**
     * getCurrentPieces
     * @return the current color of the pieces the user chose
     */
    public int getCurrentPieces() {
        return PIECES_IMAGES[pPosition];
    }

    /**
     * onSwitchRightTiles
     * @return the next tiles images
     */
    public int onSwitchRightTiles() {
        tPosition = (tPosition + 1) % TILES_IMAGES.length;
        this.changeTileColor();
        return TILES_IMAGES[tPosition];
    }

    /**
     * onSwitchLeftTiles
     * @return the previous tiles images
     */
    public int onSwitchLeftTiles() {
        tPosition = (((tPosition - 1) % TILES_IMAGES.length) + TILES_IMAGES.length) % TILES_IMAGES.length;
        this.changeTileColor();
        return TILES_IMAGES[tPosition];
    }

    /**
     * onSwitchRightPieces
     * @return the new pieces images
     */
    public int onSwitchRightPieces() {
        pPosition = (pPosition + 1) % PIECES_IMAGES.length;
        this.changePieceColor();
        GameController.iconsInitialized = false;
        return PIECES_IMAGES[pPosition];
    }

    /**
     * onSwitchLeftPieces
     * @return the previous pieces images
     */
    public int onSwitchLeftPieces() {
        pPosition = (((pPosition - 1) % PIECES_IMAGES.length) + PIECES_IMAGES.length) % PIECES_IMAGES.length;
        this.changePieceColor();
        GameController.iconsInitialized = false;
        return PIECES_IMAGES[pPosition];
    }
}
