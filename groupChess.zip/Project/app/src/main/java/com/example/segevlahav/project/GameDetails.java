package com.example.segevlahav.project;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


/**
 * GameDetails
 * All the details we need about a specific game. The players numbers, the game picture, the game
 * name and etc.
 */
public class GameDetails implements Serializable {
    private static final long serialVersionUID = 1L;
    private Map<String, String> codeAndName = new HashMap<String, String>();
    private Map<String, List<String>> codeAndPhoneNumbers = new HashMap<String, List<String>>();
    private Map<String, Integer> codeAndPicture = new HashMap<String, Integer>();
    private Map<String, Map<Character, List<String>>> codeAndTeams = new HashMap<String, Map<Character, List<String>>>();
    private Map<String, String> codeAndManager = new HashMap<String, String>();
    private Map<String, Boolean> codeAndNew = new HashMap<String, Boolean>();

    /**
     * GameDetails
     * empty constructor
     */
    GameDetails() {}

    /**
     * addCodeAndNameAndPhoneNumbersAndPicture
     * set function
     * @param code - the game code
     * @param name - the game name
     * @param numbers - the other players number
     * @param picture - the game picture
     * @param manager - the game manager
     */
    public void addCodeAndNameAndPhoneNumbersAndPicture(String code, String name, List<String> numbers, int picture, String manager) {
        this.codeAndName.put(code, name);
        this.codeAndPhoneNumbers.put(code, numbers);
        this.codeAndPicture.put(code, picture);
        this.codeAndManager.put(code, manager);
    }

    /**
     * setCodeAndTeams
     * set the codeAndTeams map.
     * @param code - the game code
     * @param whiteTeam - the white team numbers
     * @param blackTeam - the black team numbers
     */
    public void setCodeAndTeams(String code, List<String> whiteTeam, List<String> blackTeam) {
        Map<Character, List<String>> teams = new HashMap<Character, List<String>>();
        teams.put('W', whiteTeam);
        teams.put('B', blackTeam);
        codeAndTeams.put(code, teams);
    }

    /**
     * setCodeAndTeams
     * set the codeAndTeams map.
     * @param code - the game code
     * @param whiteTeam - the white team numbers
     * @param blackTeam - the black team numbers
     * @param redTeam - the red team numbers
     * @param greenTeam - the green team numbers
     */
    public void setCodeAndTeams(String code, List<String> whiteTeam, List<String> blackTeam,
                                List<String> redTeam, List<String> greenTeam) {
        Map<Character, List<String>> teams = new HashMap<Character, List<String>>();
        teams.put('W', whiteTeam);
        teams.put('B', blackTeam);
        teams.put('R', redTeam);
        teams.put('G', greenTeam);
        codeAndTeams.put(code, teams);
    }

    /**
     * setCodeAndNew
     * set codeAndNew map
     * @param code - the game code
     * @param isNew - if the game is new or not (so we can add an "new" icon next to it in the game list)
     */
    public void setCodeAndNew(String code, boolean isNew) {
        if (this.codeAndNew.containsKey(code)) {
            this.codeAndNew.remove(code);
        }
        this.codeAndNew.put(code, isNew);
    }

    /**
     * getIsNew
     * @param code - game code
     * @return true - if the game wasn't open yet.
     *         false - otherwise.
     */
    public boolean getIsNew(String code) {
        return this.codeAndNew.get(code);
    }

    /**
     * getTeamByCode
     * @param code - the game code
     * @param team - the team we want to get their members number
     * @return the numbers of "team" members.
     */
    public List<String> getTeamByCode(String code, char team) {
        return codeAndTeams.get(code).get(team);
    }

    /**
     * getCodeAndName
     * @return codeAndName map
     */
    public Map<String, String> getCodeAndName() {
        return this.codeAndName;
    }

    /**
     * getCodeAndPicture
     * @return codeAndPicture map
     */
    public Map<String, Integer> getCodeAndPicture() {
        return this.codeAndPicture;
    }

    /**
     * getManager
     * @param code - the game code
     * @return the manager of the game.
     */
    public String getManager(String code) {
        return this.codeAndManager.get(code);
    }

    /**
     * getPhoneNumbersByCode
     * @param code - the game code
     * @return return the phone number of the participants by the game code
     */
    public List<String> getPhoneNumbersByCode(String code) {
        return this.codeAndPhoneNumbers.get(code);
    }

    /**
     * removeNumber
     * remove user from the game details in case he deleted the current game
     * @param code - the game code
     * @param number - the number we need to remove
     * @param fileName - the name of the game details file
     */
    public void removeNumber(String code, String number, String fileName) {
        if (this.codeAndPhoneNumbers.containsKey(code)) {
            List<String> newList = this.codeAndPhoneNumbers.get(code);
            newList.remove(number);
            this.codeAndPhoneNumbers.put(code, newList);
            if (fileName.equals(Defines.GROUP_GAME_FILE)) {
                codeAndTeams.get(code).get('W').remove(number);
                codeAndTeams.get(code).get('B').remove(number);
            } else if (fileName.equals(Defines.FOUR_D_GAME_FILE)) {
                codeAndTeams.get(code).get('W').remove(number);
                codeAndTeams.get(code).get('B').remove(number);
                codeAndTeams.get(code).get('R').remove(number);
                codeAndTeams.get(code).get('G').remove(number);
            }
        }
    }

    /**
     * deleteGame
     * deleting the game from the game details file
     * @param code - the game code of the game we want to delete
     */
    public void deleteGame(String code) {
        this.codeAndPhoneNumbers.remove(code);
        this.codeAndName.remove(code);
        this.codeAndPicture.remove(code);
        this.codeAndTeams.remove(code);
        this.codeAndManager.remove(code);
        this.codeAndNew.remove(code);
    }

    /**
     * isExist
     * Checks if the game is exist in the game details.
     * @param code - the game code
     * @return true - if the game exist.
     *         false - otherwise.
     */
    public boolean isExist(String code) {
        if (codeAndPhoneNumbers.containsKey(code)) {
            return true;
        }
        return false;
    }

}
