package com.example.segevlahav.project;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;

/**
 * GroupGameBoard
 * This class contains all the information about the state of the group game board. The pieces positions,
 * the team that the turn is its, the number of the moves that has been played, the manager of the game
 * and etc.
 */
public class GroupGameBoard extends GameBoard implements Serializable {
    private char myTeam;

    /**
     * GroupGameBoard
     * constructor
     * @param isManger - true - if the user is the manager (the one who created the game).
     *                    false - otherwise.
     */
    GroupGameBoard(boolean isManger) {
        super();
        this.myTeam = 'W';
        this.isManager = isManger;

    }

    /**
     * GroupGameBoard
     * @param team - the team of the user
     * @param isManger - true - if the user is the manager (the one who created the game).
     *                    false - otherwise.
     */
    GroupGameBoard(char team, boolean isManger) {
        super();
        this.myTeam = team;
        if (team == 'B') {
            this.reverseBoard();
        }
        this.isManager = isManger;
    }

    /**
     * setValue
     * Change the piece position after making a move
     * @param value - the value of the position (1 - Black Rook, 2 - Black Knight...)
     * @param newPosition - the position the piece is moving to
     * @param lastPosition - the position the piece came from
     */
    public void setValue(final int value, final int newPosition, final int lastPosition) {
        int rivalPieceValue = board[newPosition];
        if (rivalPieceValue != EMPTY_PIECE && rivalPieceValue != EN_PASSANT) {
            for (Piece p : pieceBoard[rivalPieceValue - 1]) {
                if (p.getPosition() == newPosition && p.getAlive()) {
                    p.setAlive();
                    break;
                }
            }
        } else if (rivalPieceValue == EN_PASSANT && value % Defines.NUMBER_OF_PIECES == 0) {
            if (this.myTeam == this.turn) {
                rivalPieceValue = board[this.enPassant + GameBoard.BOARD_ROWS];
                board[this.enPassant + GameBoard.BOARD_ROWS] = 0;
                for (Piece p : pieceBoard[rivalPieceValue - 1]) {
                    if (p.getPosition() == newPosition && p.getAlive()) {
                        p.setAlive();
                        break;
                    }
                }
            } else {
                rivalPieceValue = board[this.enPassant - GameBoard.BOARD_ROWS];
                board[this.enPassant - GameBoard.BOARD_ROWS] = 0;
                for (Piece p : pieceBoard[rivalPieceValue - 1]) {
                    if (p.getPosition() == newPosition && p.getAlive()) {
                        p.setAlive();
                        break;
                    }
                }
            }
        }
        if (value == Defines.BLACK_KING || value == Defines.WHITE_KING) {
            this.setRookForCastling(value, lastPosition, newPosition);
        }
        board[newPosition] = value;
        board[lastPosition] = EMPTY_PIECE;
        for (Piece p : pieceBoard[value - 1]) {
            if (p.getPosition() == lastPosition && p.getAlive()) {
                p.setPosition(newPosition);
                p.incrementMoves();
                break;
            }
        }
    }

    /**
     * setRookForCastling
     * @param value - the value of the king so we can know to which team it belong
     * @param lastPosition - the last position of the king before the castling
     * @param newPosition - the new position of the king after the castling
     */
    protected void setRookForCastling(int value, int lastPosition, int newPosition) {
        switch (value) {
            case Defines.BLACK_KING:
                if (this.myTeam == 'B') {
                    if (lastPosition > newPosition) {
                        if (lastPosition - newPosition == 2) {
                            int rightRookLastPosition = this.pieceBoard[Defines.BLACK_ROOK - 1][1].getPosition();
                            this.pieceBoard[Defines.BLACK_ROOK - 1][1].setPosition(newPosition + 1);
                            this.pieceBoard[Defines.BLACK_ROOK - 1][1].incrementMoves();
                            this.board[newPosition + 1] = this.board[rightRookLastPosition];
                            this.board[rightRookLastPosition] = EMPTY_PIECE;
                        }
                    } else if (newPosition - lastPosition == 2) {
                        int leftRookLastPosition = this.pieceBoard[Defines.BLACK_ROOK - 1][0].getPosition();
                        this.pieceBoard[Defines.BLACK_ROOK - 1][0].setPosition(newPosition - 1);
                        this.pieceBoard[Defines.BLACK_ROOK - 1][0].incrementMoves();
                        this.board[newPosition - 1] = this.board[leftRookLastPosition];
                        this.board[leftRookLastPosition] = EMPTY_PIECE;
                    }
                } else {
                    if (lastPosition > newPosition) {
                        if (lastPosition - newPosition == 2) {
                            int leftRookLastPosition = this.pieceBoard[Defines.BLACK_ROOK - 1][0].getPosition();
                            this.pieceBoard[Defines.BLACK_ROOK - 1][0].setPosition(newPosition + 1);
                            this.pieceBoard[Defines.BLACK_ROOK - 1][0].incrementMoves();
                            this.board[newPosition + 1] = this.board[leftRookLastPosition];
                            this.board[leftRookLastPosition] = EMPTY_PIECE;
                        }
                    } else if (newPosition - lastPosition == 2) {
                        int rightRookLastPosition = this.pieceBoard[Defines.BLACK_ROOK - 1][1].getPosition();
                        this.pieceBoard[Defines.BLACK_ROOK - 1][1].setPosition(newPosition - 1);
                        this.pieceBoard[Defines.BLACK_ROOK - 1][1].incrementMoves();
                        this.board[newPosition - 1] = this.board[rightRookLastPosition];
                        this.board[rightRookLastPosition] = EMPTY_PIECE;
                    }
                }
                break;
            case Defines.WHITE_KING:
                if (this.myTeam == 'W') {
                    if (lastPosition > newPosition) {
                        if (lastPosition - newPosition == 2) {
                            int rightRookLastPosition = this.pieceBoard[Defines.WHITE_ROOK - 1][0].getPosition();
                            this.pieceBoard[Defines.WHITE_ROOK - 1][0].setPosition(newPosition + 1);
                            this.pieceBoard[Defines.WHITE_ROOK - 1][0].incrementMoves();
                            this.board[newPosition + 1] = this.board[rightRookLastPosition];
                            this.board[rightRookLastPosition] = EMPTY_PIECE;
                        }
                    } else if (newPosition - lastPosition == 2) {
                        int leftRookLastPosition = this.pieceBoard[Defines.WHITE_ROOK - 1][1].getPosition();
                        this.pieceBoard[Defines.WHITE_ROOK - 1][1].setPosition(newPosition - 1);
                        this.pieceBoard[Defines.WHITE_ROOK - 1][1].incrementMoves();
                        this.board[newPosition - 1] = this.board[leftRookLastPosition];
                        this.board[leftRookLastPosition] = EMPTY_PIECE;
                    }
                } else {
                    if (lastPosition > newPosition) {
                        if (lastPosition - newPosition == 2) {
                            int leftRookLastPosition = this.pieceBoard[Defines.WHITE_ROOK - 1][1].getPosition();
                            this.pieceBoard[Defines.WHITE_ROOK - 1][1].setPosition(newPosition + 1);
                            this.pieceBoard[Defines.WHITE_ROOK - 1][1].incrementMoves();
                            this.board[newPosition + 1] = this.board[leftRookLastPosition];
                            this.board[leftRookLastPosition] = EMPTY_PIECE;
                        }
                    } else if (newPosition - lastPosition == 2) {
                        int rightRookLastPosition = this.pieceBoard[Defines.WHITE_ROOK - 1][0].getPosition();
                        this.pieceBoard[Defines.WHITE_ROOK - 1][0].setPosition(newPosition - 1);
                        this.pieceBoard[Defines.WHITE_ROOK - 1][0].incrementMoves();
                        this.board[newPosition - 1] = this.board[rightRookLastPosition];
                        this.board[rightRookLastPosition] = EMPTY_PIECE;
                    }
                }
                break;
            default:
                return;
        }
    }

    /**
     * calculateValidMoves
     * Calculate the valid moves that a player can perform in his turn.
     */
    protected void calculateValidMoves() {
        if (this.turn == this.calculatedMoves) {
            return;
        } else {
            this.validMoves.clear();
            this.calculatedMoves = this.turn;
        }
        ArrayList<Integer> pieceMoves = new ArrayList<Integer>();
        Iterator<Integer> iterator;
        int lastPosition = 0;
        switch (this.turn) {
            case 'W':
                for (int i = (MAX_VALUE / 2) ; i < MAX_VALUE; i++) {
                    for (Piece piece : this.pieceBoard[i]) {
                        lastPosition = piece.getPosition();
                        if (piece.getType() == 'K') {
                            ((King) piece).setRightRookMoved(this.pieceBoard[Defines.WHITE_ROOK - 1][0].getMoves());
                            ((King) piece).setLeftRookMoved(this.pieceBoard[Defines.WHITE_ROOK - 1][1].getMoves());
                        }
                        if (this.myTeam == 'W') {
                            pieceMoves.addAll(piece.getPossibleMoves(lastPosition, board, this.turn));
                        } else {
                            pieceMoves.addAll(piece.getPossibleMoves(lastPosition, board, this.getRivalTeam(this.turn)));
                        }
                        if (!pieceMoves.isEmpty()) {
                            iterator = pieceMoves.iterator();
                            while (iterator.hasNext()) {
                                int pos = iterator.next();
                                if (setValueForCheck(board[lastPosition], pos, lastPosition, 'B')) {
                                    iterator.remove();
                                }
                            }
                        }
                        if (!pieceMoves.isEmpty()) {
                            validMoves.put(lastPosition, new ArrayList<Integer>(pieceMoves));
                        }
                        pieceMoves.clear();
                    }
                }
                break;
            case 'B':
                for (int i = 0; i < MAX_VALUE / 2; i++) {
                    for (Piece piece : pieceBoard[i]) {
                        lastPosition = piece.getPosition();
                        if (piece.getType() == 'k') {
                            ((King) piece).setRightRookMoved(this.pieceBoard[Defines.BLACK_ROOK - 1][0].getMoves());
                            ((King) piece).setLeftRookMoved(this.pieceBoard[Defines.BLACK_ROOK - 1][1].getMoves());
                        }
                        if (this.myTeam == 'B') {
                            pieceMoves.addAll(piece.getPossibleMoves(lastPosition, board, this.turn));
                        } else {
                            pieceMoves.addAll(piece.getPossibleMoves(lastPosition, board,this.getRivalTeam(this.turn)));
                        }
                        if (!pieceMoves.isEmpty()) {
                            iterator = pieceMoves.iterator();
                            while (iterator.hasNext()) {
                                int pos = iterator.next();
                                if (setValueForCheck(board[lastPosition], pos, lastPosition, 'W')) {
                                    iterator.remove();
                                }
                            }
                        }
                        if (!pieceMoves.isEmpty()) {
                            validMoves.put(lastPosition, new ArrayList<Integer>(pieceMoves));
                        }
                        pieceMoves.clear();
                    }
                }
                break;
            default:
                break;
        }
    }

    /**
     * getMyTeam
     * @return the user team
     */
    public char getMyTeam() {
        return this.myTeam;
    }

    /**
     * checkEnPassant
     * Check if there was an en passant move and take care of it.
     * @param value - the value of the pawn that commit the en passant
     * @param newPosition - the position the pawn is moving to
     * @param lastPosition - the position the pawn came from
     */
    public void checkEnPassant(final int value, final int newPosition, final int lastPosition) {
        if (this.enPassant != -1) {
            if (this.board[this.enPassant] == EN_PASSANT) {
                this.board[this.enPassant] = EMPTY_PIECE;
            }
            this.enPassant = -1;
        }
        if (value % Defines.NUMBER_OF_PIECES == 0) {
            if (lastPosition - newPosition == (GameBoard.BOARD_ROWS * 2)) {
                this.enPassant = lastPosition - GameBoard.BOARD_ROWS;
                this.board[lastPosition - GameBoard.BOARD_ROWS] = EN_PASSANT;
            } else if (newPosition - lastPosition == (GameBoard.BOARD_ROWS * 2)) {
                this.enPassant = lastPosition + GameBoard.BOARD_ROWS;
                this.board[lastPosition + GameBoard.BOARD_ROWS] = EN_PASSANT;
            }
        }
    }

    /**
     * addMoveToList
     * Adding a move to the move list
     * @param value - the value of the piece that has moved
     * @param to - the position the piece has been moved to
     * @param from - the position the piece came from
     */
    public void addMoveToList(int value, int to, int from) {
        if (value == Defines.BLACK_KING || value == Defines.WHITE_KING) {
            if (this.myTeam == 'B') {
                if (from > to) {
                    if (from - to == 2) {
                        this.moveItems.add(new MoveItem("O-O-O", "", value));
                        return;
                    }
                } else if (to - from == 2) {
                    this.moveItems.add(new MoveItem("O-O", "", value));
                    return;
                }
            } else {
                if (from > to) {
                    if (from - to == 2) {
                        this.moveItems.add(new MoveItem("O-O", "", value));
                        return;
                    }
                } else if (to - from == 2) {
                    this.moveItems.add(new MoveItem("O-O-O", "", value));
                    return;
                }
            }
        }
        switch (this.myTeam) {
            case 'W':
                this.moveItems.add(new MoveItem(convertingPosition(from), convertingPosition(to), value));
                break;
            case 'B':
                this.moveItems.add(new MoveItem(convertingPosition(BOARD_SIZE - 1 - from), convertingPosition(BOARD_SIZE - 1 - to), value));
                break;
            default:
                break;
        }
    }
}
