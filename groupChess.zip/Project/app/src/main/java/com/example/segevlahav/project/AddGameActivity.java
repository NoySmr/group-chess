package com.example.segevlahav.project;


import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

/**
 * AddGameActivity
 * In this activity we let the user to pick the name and the icon of the game
 * he/she would like to open.
 */
public class AddGameActivity extends AppCompatActivity {
    Integer[] image = {R.drawable.group_picture1, R.drawable.group_picture2, R.drawable.group_picture3
            , R.drawable.group_picture4, R.drawable.group_picture5, R.drawable.group_picture6, R.drawable.group_picture7};

    /**
     * onCreate
     * This function is called when we start the activity.
     * @param savedInstanceState
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_game);

        Bundle bundle = getIntent().getExtras();
        final String fileName = bundle.getString("fileName"); // the game details file

        final EditText text = (EditText) findViewById(R.id.full_name); // the group name
        final Spinner spin = (Spinner) findViewById(R.id.pictureSpinner); // the icon of the game
        Button addFriendsButton = (Button) findViewById(R.id.addFriends); // button to move to next screen
        addFriendsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            /**
             * onClick
             * Move to the contact list activity after checking that the group name is valid (doesn't
             * contain '='/'~'/':' or its not empty.
             */
            public void onClick(View v) {
                String gameName = text.getText().toString();
                if (gameName.length() > 0) {
                    if (gameName.contains("=") || gameName.contains("~") || gameName.contains(":")) {
                        Toast.makeText(getApplicationContext(), "Name can't contain '='/'~'/':'", Toast.LENGTH_LONG).show();
                        return;
                    }
                    gameName = gameName.replace(' ', '=');
                    Integer res = image[spin.getSelectedItemPosition()];
                    Intent mIntent = new Intent(AddGameActivity.this, ContactListActivity.class);
                    mIntent.putExtra("gamePicture", res);
                    mIntent.putExtra("gameName", gameName);
                    mIntent.putExtra("fileName", fileName);
                    startActivity(mIntent);
                } else {
                    Toast.makeText(getApplicationContext(), "Please choose name", Toast.LENGTH_LONG).show();
                }
            }
        });
        SimpleImageArrayAdapter adapter = new SimpleImageArrayAdapter(this, image);
        spin.setAdapter(adapter);
    }
}
