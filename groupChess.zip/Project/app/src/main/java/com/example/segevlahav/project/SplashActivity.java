package com.example.segevlahav.project;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;

/**
 * SplashActivity
 * The entry screen.
 */
public class SplashActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
        final ImageView img = (ImageView) findViewById(R.id.imageView);
        final ImageView logo = (ImageView) findViewById(R.id.logo);
        final Animation translateAnim= AnimationUtils.loadAnimation(getApplicationContext(),
                R.anim.translate);
        final Animation a = AnimationUtils.loadAnimation(getBaseContext(),R.anim.rotate);

        final Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() { //change the text
                            img.startAnimation(translateAnim);
                        }
                    });
                    //sleep one second.
                    Thread.sleep(1000);
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() { //change the text
                            img.startAnimation(a);
                        }
                    });
                }catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }

        });
        t.start();
        //i.startAnimation(translateAnim);
        a.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {

            }

            @Override
            public void onAnimationEnd(Animation animation) {
                finish();
                startActivity(new Intent(SplashActivity.this, MenuActivity.class));


            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });
    }
}
