package com.example.segevlahav.project;

import java.io.Serializable;

/**
 * MoveItem
 * A list item for the log screen. (moves screen)
 */
public class MoveItem implements Serializable {
    private String from;
    private String to;
    private int icon; // the image of the piece

    /**
     * MoveItem
     * constructor
     * @param from - piece last position
     * @param to - piece new position
     * @param icon - piece icon
     */
    public MoveItem(String from, String to, int icon){
        this.from = from;
        this.icon = icon;
        this.to = to;
    }

    /**
     * getFrom
     * @return the last position
     */
    public String getFrom(){
        return this.from;
    }

    /**
     * getTo
     * @return the new position
     */
    public String getTo(){
        return this.to;
    }

    /**
     * getIcon
     * @return the icon of the piece
     */
    public int getIcon(){
        return this.icon;
    }
}
