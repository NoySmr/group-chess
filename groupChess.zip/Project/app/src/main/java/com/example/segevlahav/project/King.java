package com.example.segevlahav.project;

import java.util.ArrayList;

/**
 * King
 * The king piece.
 */
public class King extends Piece {
    boolean rightRookMoved; // is the right rook has moved
    boolean leftRookMoved; // is the left rook has moved

    /**
     * King
     * constructor
     * @param position- the piece position
     * @param type - the piece type
     * @param team - the piece team
     */
    King(int position, char type, char team) {
        super();
        this.position = position;
        this.type = type;
        this.team = team;
        this.rightRookMoved = false;
        this.leftRookMoved = false;
    }

    /**
     * setRightRooked
     * if the right rook has moved then "rightRookMoved" will be false. otherwise true.
     * @param moves - the moves the rooked has done
     */
    public void setRightRookMoved(int moves) {
        if (moves != 0) {
            this.rightRookMoved = true;
        }
    }

    /**
     * setLeftRooked
     * if the left rook has moved then "rightRookMoved" will be false. otherwise true.
     * @param moves - the moves the rooked has done
     */
    public void setLeftRookMoved(int moves) {
        if (moves != 0) {
            this.leftRookMoved = true;
        }
    }

    /**
     * canCastlingRight
     * checks if the king can castling to the right side
     * @param board - the game board
     * @return true - if the king can castling right.
     *         false - otherwise.
     */
    private boolean canCastlingRight(final int[] board) {
        if (this.moves == 0 && !this.rightRookMoved) {
            for (int i = this.position - 1; i % GameBoard.BOARD_ROWS != 0; i--) {
                if (board[i] != GameBoard.EMPTY_PIECE) {
                    return false;
                }
            }
            return true;
        }
        return false;
    }

    /**
     * canCastlingLeft
     * checks if the king can castling to the left side
     * @param board - the game board
     * @return true - if the king can castling left.
     *         false - otherwise.
     */
    private boolean canCastlingLeft(final int[] board) {
        if (this.moves == 0 && !this.leftRookMoved) {
            for (int i = this.position + 1; i % (GameBoard.BOARD_ROWS - 1) != 0; i++) {
                if (board[i] != GameBoard.EMPTY_PIECE) {
                    return false;
                }
            }
            return true;
        }
        return false;
    }

    /**
     * canCastlingRightFourDGame
     * checks if the king can castling to the left side in the 4D game
     * @param board - the game board
     * @return true - if the king can castling right.
     *         false - otherwise.
     */
    private boolean canCastlingRightFourDGame(final int[] board) {
        if (this.moves == 0 && !this.rightRookMoved) {
            for (int i = this.position - 1; (i % FourDGameBoard.BOARD_ROWS) != 3; i--) {
                if (board[i] != FourDGameBoard.EMPTY_PIECE) {
                    return false;
                }
            }
            return true;
        }
        return false;
    }

    /**
     * canCastlingLeftFourDGame
     * checks if the king can castling to the left side in the 4D game
     * @param board - the game board
     * @return true - if the king can castling left.
     *         false - otherwise.
     */
    private boolean canCastlingLeftFourDGame(final int[] board) {
        if (this.moves == 0 && !this.leftRookMoved) {
            for (int i = this.position + 1; (i % FourDGameBoard.BOARD_ROWS) != 10; i++) {
                if (board[i] != FourDGameBoard.EMPTY_PIECE) {
                    return false;
                }
            }
            return true;
        }
        return false;
    }

    /**
     * getPossibleMoves
     * @param position - the piece position
     * @param board - the board matrix
     * @param turn - the team the turn belongs to her
     * @return all the valid moves the piece can move.
     */
    public ArrayList<Integer> getPossibleMoves(final int position, final int[] board, char turn) {
        ArrayList<Integer> possibleMoves = new ArrayList<Integer>();
        if (!this.alive) {
            return possibleMoves;
        }
        if (position >= GameBoard.BOARD_ROWS) {
            if (board[position - GameBoard.BOARD_ROWS] == GameBoard.EMPTY_PIECE || board[position - GameBoard.BOARD_ROWS] == GameBoard.EN_PASSANT
                    || !sameTeam(board[position], board[position - GameBoard.BOARD_ROWS])) {
                possibleMoves.add(position - GameBoard.BOARD_ROWS);
            }
        }
        if (position >= (GameBoard.BOARD_ROWS - 1) && (position - (GameBoard.BOARD_ROWS - 1)) % GameBoard.BOARD_ROWS != 0) {
            if (board[position - (GameBoard.BOARD_ROWS - 1)] == GameBoard.EMPTY_PIECE || board[position - (GameBoard.BOARD_ROWS - 1)] == GameBoard.EN_PASSANT
                    || !sameTeam(board[position], board[position - (GameBoard.BOARD_ROWS - 1)])) {
                possibleMoves.add(position - (GameBoard.BOARD_ROWS - 1));
            }
        }
        if (position >= (GameBoard.BOARD_ROWS + 1) && (position - (GameBoard.BOARD_ROWS + 1)) % GameBoard.BOARD_ROWS != (GameBoard.BOARD_ROWS - 1)) {
            if (board[position - (GameBoard.BOARD_ROWS + 1)] == GameBoard.EMPTY_PIECE || board[position - (GameBoard.BOARD_ROWS + 1)] == GameBoard.EN_PASSANT
                    || !sameTeam(board[position], board[position - (GameBoard.BOARD_ROWS + 1)])) {
                possibleMoves.add(position - (GameBoard.BOARD_ROWS + 1));
            }
        }
        if (position <= (GameBoard.BOARD_SIZE - GameBoard.BOARD_ROWS - 1)) {
            if (board[position + GameBoard.BOARD_ROWS] == GameBoard.EMPTY_PIECE || board[position + GameBoard.BOARD_ROWS] == GameBoard.EN_PASSANT
                    || !sameTeam(board[position], board[position + GameBoard.BOARD_ROWS])) {
                possibleMoves.add(position + GameBoard.BOARD_ROWS);
            }
        }
        if (position <= (GameBoard.BOARD_SIZE - GameBoard.BOARD_ROWS) && (position + (GameBoard.BOARD_ROWS - 1)) % GameBoard.BOARD_ROWS != (GameBoard.BOARD_ROWS - 1)) {
            if (board[position + (GameBoard.BOARD_ROWS - 1)] == GameBoard.EMPTY_PIECE || board[position + (GameBoard.BOARD_ROWS - 1)] == GameBoard.EN_PASSANT
                    || !sameTeam(board[position], board[position + 7])) {
                possibleMoves.add(position + (GameBoard.BOARD_ROWS - 1));
            }
        }
        if (position <= (GameBoard.BOARD_SIZE - GameBoard.BOARD_ROWS - 2) && (position + (GameBoard.BOARD_ROWS + 1)) % GameBoard.BOARD_ROWS != 0) {
            if (board[position + (GameBoard.BOARD_ROWS + 1)] == GameBoard.EMPTY_PIECE || board[position + (GameBoard.BOARD_ROWS + 1)] == GameBoard.EN_PASSANT
                    || !sameTeam(board[position], board[position + (GameBoard.BOARD_ROWS + 1)])) {
                possibleMoves.add(position + (GameBoard.BOARD_ROWS + 1));
            }
        }
        if (position % GameBoard.BOARD_ROWS != 0) {
            if (board[position - 1] == GameBoard.EMPTY_PIECE || board[position - 1] == GameBoard.EN_PASSANT
                    || !sameTeam(board[position], board[position - 1])) {
                possibleMoves.add(position - 1);
            }
        }
        if (position % GameBoard.BOARD_ROWS != (GameBoard.BOARD_ROWS - 1)) {
            if (board[position + 1] == GameBoard.EMPTY_PIECE || board[position + 1] == GameBoard.EN_PASSANT
                    || !sameTeam(board[position], board[position + 1])) {
                possibleMoves.add(position + 1);
            }
        }

        // check for castling
        if (this.canCastlingRight(board)) {
            possibleMoves.add(position - 2);
        }
        if (this.canCastlingLeft(board)) {
            possibleMoves.add(position + 2);
        }

        return possibleMoves;
    }

    /**
     * getPossibleMovesFourDGame
     * @param position - the piece position
     * @param board - the board matrix
     * @param turn - the team the turn belongs to her
     * @return all the valid moves the piece can move for the 4D game.
     */
    @Override
    public ArrayList<Integer> getPossibleMovesFourDGame(int position, int[] board, char turn) {
        ArrayList<Integer> possibleMoves = new ArrayList<Integer>();
        if (!this.alive) {
            return possibleMoves;
        }
        if (position >= FourDGameBoard.BOARD_ROWS) {
            if (board[position - FourDGameBoard.BOARD_ROWS] != FourDGameBoard.BAD_PLACE &&
                    (board[position - FourDGameBoard.BOARD_ROWS] == FourDGameBoard.EMPTY_PIECE
                    || board[position - FourDGameBoard.BOARD_ROWS] == FourDGameBoard.EN_PASSANT
                    || !sameTeam(board[position], board[position - FourDGameBoard.BOARD_ROWS]))) {
                possibleMoves.add(position - FourDGameBoard.BOARD_ROWS);
            }
        }
        if (position >= (FourDGameBoard.BOARD_ROWS - 1) && (position - (FourDGameBoard.BOARD_ROWS - 1)) % FourDGameBoard.BOARD_ROWS != 0) {
            if (board[position - (FourDGameBoard.BOARD_ROWS - 1)] != FourDGameBoard.BAD_PLACE &&
                    (board[position - (FourDGameBoard.BOARD_ROWS - 1)] == FourDGameBoard.EMPTY_PIECE
                    || board[position - (FourDGameBoard.BOARD_ROWS - 1)] == FourDGameBoard.EN_PASSANT
                    || !sameTeam(board[position], board[position - (FourDGameBoard.BOARD_ROWS - 1)]))) {
                possibleMoves.add(position - (FourDGameBoard.BOARD_ROWS - 1));
            }
        }
        if (position >= (FourDGameBoard.BOARD_ROWS + 1) && (position - (FourDGameBoard.BOARD_ROWS + 1)) % FourDGameBoard.BOARD_ROWS != (FourDGameBoard.BOARD_ROWS - 1)) {
            if (board[position - (FourDGameBoard.BOARD_ROWS + 1)] != FourDGameBoard.BAD_PLACE &&
                    (board[position - (FourDGameBoard.BOARD_ROWS + 1)] == FourDGameBoard.EMPTY_PIECE
                    || board[position - (FourDGameBoard.BOARD_ROWS + 1)] == FourDGameBoard.EN_PASSANT
                    || !sameTeam(board[position], board[position - (FourDGameBoard.BOARD_ROWS + 1)]))) {
                possibleMoves.add(position - (FourDGameBoard.BOARD_ROWS + 1));
            }
        }
        if (position <= (FourDGameBoard.BOARD_SIZE - FourDGameBoard.BOARD_ROWS - 1)) {
            if (board[position + FourDGameBoard.BOARD_ROWS] != FourDGameBoard.BAD_PLACE &&
                    (board[position + FourDGameBoard.BOARD_ROWS] == FourDGameBoard.EMPTY_PIECE
                    || board[position + FourDGameBoard.BOARD_ROWS] == FourDGameBoard.EN_PASSANT
                    || !sameTeam(board[position], board[position + FourDGameBoard.BOARD_ROWS]))) {
                possibleMoves.add(position + FourDGameBoard.BOARD_ROWS);
            }
        }
        if (position <= (FourDGameBoard.BOARD_SIZE - FourDGameBoard.BOARD_ROWS) && (position + (FourDGameBoard.BOARD_ROWS - 1)) % FourDGameBoard.BOARD_ROWS != (FourDGameBoard.BOARD_ROWS - 1)) {
            if (board[position + (FourDGameBoard.BOARD_ROWS - 1)] != FourDGameBoard.BAD_PLACE &&
                    (board[position + (FourDGameBoard.BOARD_ROWS - 1)] == FourDGameBoard.EMPTY_PIECE
                    || board[position + (FourDGameBoard.BOARD_ROWS - 1)] == FourDGameBoard.EN_PASSANT
                    || !sameTeam(board[position], board[position + (FourDGameBoard.BOARD_ROWS - 1)]))) {
                possibleMoves.add(position + (FourDGameBoard.BOARD_ROWS - 1));
            }
        }
        if (position <= (FourDGameBoard.BOARD_SIZE - FourDGameBoard.BOARD_ROWS - 2) && (position + (FourDGameBoard.BOARD_ROWS + 1)) % FourDGameBoard.BOARD_ROWS != 0) {
            if (board[position + (FourDGameBoard.BOARD_ROWS + 1)] != FourDGameBoard.BAD_PLACE &&
                    (board[position + (FourDGameBoard.BOARD_ROWS + 1)] == FourDGameBoard.EMPTY_PIECE
                    || board[position + (FourDGameBoard.BOARD_ROWS + 1)] == FourDGameBoard.EN_PASSANT
                    || !sameTeam(board[position], board[position + (FourDGameBoard.BOARD_ROWS + 1)]))) {
                possibleMoves.add(position + (FourDGameBoard.BOARD_ROWS + 1));
            }
        }
        if (position % FourDGameBoard.BOARD_ROWS != 0) {
            if (board[position - 1] != FourDGameBoard.BAD_PLACE &&
                    (board[position - 1] == FourDGameBoard.EMPTY_PIECE
                    || board[position - 1] == FourDGameBoard.EN_PASSANT
                    || !sameTeam(board[position], board[position - 1]))) {
                possibleMoves.add(position - 1);
            }
        }
        if (position % FourDGameBoard.BOARD_ROWS != (FourDGameBoard.BOARD_ROWS - 1)) {
            if (board[position + 1] != FourDGameBoard.BAD_PLACE &&
                    (board[position + 1] == FourDGameBoard.EMPTY_PIECE
                    || board[position + 1] == FourDGameBoard.EN_PASSANT
                    || !sameTeam(board[position], board[position + 1]))) {
                possibleMoves.add(position + 1);
            }
        }

        // check for castling
        if (this.canCastlingRightFourDGame(board)) {
            possibleMoves.add(position - 2);
        }
        if (this.canCastlingLeftFourDGame(board)) {
            possibleMoves.add(position + 2);
        }

        return possibleMoves;
    }
}
