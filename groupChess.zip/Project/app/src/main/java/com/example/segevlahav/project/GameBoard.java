package com.example.segevlahav.project;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 * GameBoard
 * This class contains all the information about the state of the game board. The pieces positions,
 * the team that the turn is its, the number of the moves that has been played, the manager of the game
 * and etc.
 */
public abstract class GameBoard implements Serializable {
    private static final long serialVersionUID = 0L;
    public static final int BOARD_ROWS = 8; // 8x8 board
    public static final int BOARD_SIZE = BOARD_ROWS * BOARD_ROWS; // 8x8 board
    public static final int EMPTY_PIECE = 0;
    public static final int MIN_VALUE = 1;
    public static final int MAX_VALUE = 12;
    public static final int EN_PASSANT = 13;
    private static final int [] SEED_GRID = { // the board of the common game board and the group game board
            Defines.BLACK_ROOK,Defines.BLACK_KNIGHT,Defines.BLACK_BISHOP,Defines.BLACK_KING,Defines.BLACK_QUEEN,Defines.BLACK_BISHOP,Defines.BLACK_KNIGHT,Defines.BLACK_ROOK,
            Defines.BLACK_PAWN,Defines.BLACK_PAWN,Defines.BLACK_PAWN,Defines.BLACK_PAWN,Defines.BLACK_PAWN,Defines.BLACK_PAWN,Defines.BLACK_PAWN,Defines.BLACK_PAWN,
            EMPTY_PIECE,EMPTY_PIECE,EMPTY_PIECE,EMPTY_PIECE,EMPTY_PIECE,EMPTY_PIECE,EMPTY_PIECE,EMPTY_PIECE,
            EMPTY_PIECE,EMPTY_PIECE,EMPTY_PIECE,EMPTY_PIECE,EMPTY_PIECE,EMPTY_PIECE,EMPTY_PIECE,EMPTY_PIECE,
            EMPTY_PIECE,EMPTY_PIECE,EMPTY_PIECE,EMPTY_PIECE,EMPTY_PIECE,EMPTY_PIECE,EMPTY_PIECE,EMPTY_PIECE,
            EMPTY_PIECE,EMPTY_PIECE,EMPTY_PIECE,EMPTY_PIECE,EMPTY_PIECE,EMPTY_PIECE,EMPTY_PIECE,EMPTY_PIECE,
            Defines.WHITE_PAWN,Defines.WHITE_PAWN,Defines.WHITE_PAWN,Defines.WHITE_PAWN,Defines.WHITE_PAWN,Defines.WHITE_PAWN,Defines.WHITE_PAWN,Defines.WHITE_PAWN,
            Defines.WHITE_ROOK,Defines.WHITE_KNIGHT,Defines.WHITE_BISHOP,Defines.WHITE_KING,Defines.WHITE_QUEEN,Defines.WHITE_BISHOP,Defines.WHITE_KNIGHT,Defines.WHITE_ROOK
    };
    protected int[] board = new int[BOARD_SIZE];
    protected Piece[][] pieceBoard = new Piece[MAX_VALUE][];
    protected Map<Integer, ArrayList<Integer>> validMoves;
    protected char turn;
    protected char calculatedMoves;
    protected int moves; // number of moves that have been played in the game
    protected int enPassant;
    protected boolean isManager; // if the user is the manager of this game or not
    protected boolean waitingForPermission; // if the user is waiting to message from the manager
    protected char gameState;
    protected List<MoveItem> moveItems; // list of the moves that has been played

    /**
     * GameBoard
     * constructor
     */
    public GameBoard(){
        this.board = new int[BOARD_SIZE];
        System.arraycopy(SEED_GRID, 0, board, 0, BOARD_SIZE);
        this.initializePieceBoard();
        this.validMoves = new HashMap<Integer, ArrayList<Integer>>();
        this.turn = 'W';
        this.gameState = 'K';
        this.moves = 0;
        this.calculatedMoves = 'B';
        this.enPassant = -1;
        this.waitingForPermission = false;
        this.moveItems = new ArrayList<MoveItem>();
    }

    public GameBoard(boolean isManager) {
        this.validMoves = new HashMap<Integer, ArrayList<Integer>>();
        this.turn = 'W';
        this.gameState = 'K';
        this.moves = 0;
        this.calculatedMoves = 'B';
        this.enPassant = -1;
        this.waitingForPermission = false;
        this.moveItems = new ArrayList<MoveItem>();
        this.isManager = isManager;
    }

    /**
     /**
     * initializePieceBoard
     * Initialize the piece board so each piece will have: 1. team
     *                                                     2. type
     *                                                     3. position
     */
    private void initializePieceBoard() {
        pieceBoard[Defines.BLACK_ROOK - 1] = new Piece[2];
        pieceBoard[Defines.BLACK_KNIGHT - 1] = new Piece[2];
        pieceBoard[Defines.BLACK_BISHOP - 1] = new Piece[2];
        pieceBoard[Defines.BLACK_QUEEN - 1] = new Piece[1];
        pieceBoard[Defines.BLACK_KING - 1] = new Piece[1];
        pieceBoard[Defines.BLACK_PAWN - 1] = new Piece[8];
        pieceBoard[Defines.WHITE_ROOK - 1] = new Piece[2];
        pieceBoard[Defines.WHITE_KNIGHT - 1] = new Piece[2];
        pieceBoard[Defines.WHITE_BISHOP - 1] = new Piece[2];
        pieceBoard[Defines.WHITE_QUEEN - 1] = new Piece[1];
        pieceBoard[Defines.WHITE_KING - 1] = new Piece[1];
        pieceBoard[Defines.WHITE_PAWN - 1] = new Piece[8];
        pieceBoard[Defines.BLACK_ROOK - 1][0] = new Rook(0, 'r', 'B');
        pieceBoard[Defines.BLACK_ROOK - 1][1] = new Rook(7, 'r', 'B');
        pieceBoard[Defines.BLACK_KNIGHT - 1][0] = new Knight(1, 'n', 'B');
        pieceBoard[Defines.BLACK_KNIGHT - 1][1] = new Knight(6, 'n', 'B');
        pieceBoard[Defines.BLACK_BISHOP - 1][0] = new Bishop(2, 'b', 'B');
        pieceBoard[Defines.BLACK_BISHOP - 1][1] = new Bishop(5, 'b', 'B');
        pieceBoard[Defines.BLACK_QUEEN - 1][0] = new Queen(4, 'q', 'B');
        pieceBoard[Defines.BLACK_KING - 1][0] = new King(3, 'k', 'B');
        pieceBoard[Defines.BLACK_PAWN - 1][0] = new Pawn(8, 'p', 'B');
        pieceBoard[Defines.BLACK_PAWN - 1][1] = new Pawn(9, 'p', 'B');
        pieceBoard[Defines.BLACK_PAWN - 1][2] = new Pawn(10, 'p', 'B');
        pieceBoard[Defines.BLACK_PAWN - 1][3] = new Pawn(11, 'p', 'B');
        pieceBoard[Defines.BLACK_PAWN - 1][4] = new Pawn(12, 'p', 'B');
        pieceBoard[Defines.BLACK_PAWN - 1][5] = new Pawn(13, 'p', 'B');
        pieceBoard[Defines.BLACK_PAWN - 1][6] = new Pawn(14, 'p', 'B');
        pieceBoard[Defines.BLACK_PAWN - 1][7] = new Pawn(15, 'p', 'B');
        pieceBoard[Defines.WHITE_ROOK - 1][0] = new Rook(56, 'R', 'W');
        pieceBoard[Defines.WHITE_ROOK - 1][1] = new Rook(63, 'R', 'W');
        pieceBoard[Defines.WHITE_KNIGHT - 1][0] = new Knight(57, 'N', 'W');
        pieceBoard[Defines.WHITE_KNIGHT - 1][1] = new Knight(62, 'N', 'W');
        pieceBoard[Defines.WHITE_BISHOP - 1][0] = new Bishop(58, 'B', 'W');
        pieceBoard[Defines.WHITE_BISHOP - 1][1] = new Bishop(61, 'B', 'W');
        pieceBoard[Defines.WHITE_QUEEN - 1][0] = new Queen(60, 'Q', 'W');
        pieceBoard[Defines.WHITE_KING - 1][0] = new King(59, 'K', 'W');
        pieceBoard[Defines.WHITE_PAWN - 1][0] = new Pawn(48, 'P', 'W');
        pieceBoard[Defines.WHITE_PAWN - 1][1] = new Pawn(49, 'P', 'W');
        pieceBoard[Defines.WHITE_PAWN - 1][2] = new Pawn(50, 'P', 'W');
        pieceBoard[Defines.WHITE_PAWN - 1][3] = new Pawn(51, 'P', 'W');
        pieceBoard[Defines.WHITE_PAWN - 1][4] = new Pawn(52, 'P', 'W');
        pieceBoard[Defines.WHITE_PAWN - 1][5] = new Pawn(53, 'P', 'W');
        pieceBoard[Defines.WHITE_PAWN - 1][6] = new Pawn(54, 'P', 'W');
        pieceBoard[Defines.WHITE_PAWN - 1][7] = new Pawn(55, 'T', 'W');
    }

    /**
     * setValue
     * Change the piece position after making a move
     * @param value - the value of the position (1 - Black Rook, 2 - Black Knight...)
     * @param newPosition - the position the piece is moving to
     * @param lastPosition - the position the piece came from
     */
    public void setValue(final int value, final int newPosition, final int lastPosition) {
        int rivalPieceValue = board[newPosition];
        if (rivalPieceValue != EMPTY_PIECE && rivalPieceValue != EN_PASSANT) {
            // In case we kill rival piece
            for (Piece p : pieceBoard[rivalPieceValue - 1]) {
                if (p.getPosition() == newPosition && p.getAlive()) {
                    p.setAlive();
                    break;
                }
            }
        } else if (rivalPieceValue == EN_PASSANT && value % Defines.NUMBER_OF_PIECES == 0) {
            // In case we kill rival pawn by en passant
            rivalPieceValue = board[this.enPassant + BOARD_ROWS];
            board[this.enPassant + BOARD_ROWS] = 0;
            for (Piece p : pieceBoard[rivalPieceValue - 1]) {
                if (p.getPosition() == newPosition && p.getAlive()) {
                    p.setAlive();
                    break;
                }
            }
        }
        if (value == Defines.BLACK_KING || value == Defines.WHITE_KING) {
            // In case the user has moved the king we need to check for castling
            this.setRookForCastling(value, lastPosition, newPosition);
        }
        board[newPosition] = value;
        board[lastPosition] = EMPTY_PIECE;
        for (Piece p : pieceBoard[value - 1]) {
            // In case the user has move his piece to an empty position
            if (p.getPosition() == lastPosition && p.getAlive()) {
                p.setPosition(newPosition);
                p.incrementMoves();
                break;
            }
        }
    }

    /**
     * getGameState
     * @return the state of the game (check/mate/draw/nothing)
     */
    public char getGameState() {
        return this.gameState;
    }

    /**
     * setWaitingForPermission
     * @param waiting - true - if the user is waiting for manager approval on his move.
     *                  false - otherwise.
     */
    public void setWaitingForPermission(boolean waiting) {
        this.waitingForPermission = waiting;
    }

    /**
     * isWaitingForPermission
     * @return true - if the user is waiting for manager approval on his move.
     *         false - otherwise.
     */
    public boolean isWaitingForPermission() {
        return this.waitingForPermission;
    }

    /**
     * setRookForCastling
     * @param value - the value of the king so we can know to which team it belong
     * @param lastPosition - the last position of the king before the castling
     * @param newPosition - the new position of the king after the castling
     */
    protected void setRookForCastling(int value, int lastPosition, int newPosition) {
        switch (value) {
            case Defines.BLACK_KING:
                if (lastPosition > newPosition) {
                    if (lastPosition - newPosition == 2) {
                        int rightRookLastPosition = this.pieceBoard[Defines.BLACK_ROOK - 1][1].getPosition();
                        this.pieceBoard[Defines.BLACK_ROOK - 1][1].setPosition(newPosition + 1);
                        this.pieceBoard[Defines.BLACK_ROOK - 1][1].incrementMoves();
                        this.board[newPosition + 1] = this.board[rightRookLastPosition];
                        this.board[rightRookLastPosition] = EMPTY_PIECE;
                    }
                } else if (newPosition - lastPosition == 2) {
                    int leftRookLastPosition = this.pieceBoard[Defines.BLACK_ROOK - 1][0].getPosition();
                    this.pieceBoard[Defines.BLACK_ROOK - 1][0].setPosition(newPosition - 1);
                    this.pieceBoard[Defines.BLACK_ROOK - 1][0].incrementMoves();
                    this.board[newPosition - 1] = this.board[leftRookLastPosition];
                    this.board[leftRookLastPosition] = EMPTY_PIECE;
                }
                break;
            case Defines.WHITE_KING:
                if (lastPosition > newPosition) {
                    if (lastPosition - newPosition == 2) {
                        int rightRookLastPosition = this.pieceBoard[Defines.WHITE_ROOK - 1][0].getPosition();
                        this.pieceBoard[Defines.WHITE_ROOK - 1][0].setPosition(newPosition + 1);
                        this.pieceBoard[Defines.WHITE_ROOK - 1][0].incrementMoves();
                        this.board[newPosition + 1] = this.board[rightRookLastPosition];
                        this.board[rightRookLastPosition] = EMPTY_PIECE;
                    }
                } else if (newPosition - lastPosition == 2) {
                    int leftRookLastPosition = this.pieceBoard[Defines.WHITE_ROOK - 1][1].getPosition();
                    this.pieceBoard[Defines.WHITE_ROOK - 1][1].setPosition(newPosition - 1);
                    this.pieceBoard[Defines.WHITE_ROOK - 1][1].incrementMoves();
                    this.board[newPosition - 1] = this.board[leftRookLastPosition];
                    this.board[leftRookLastPosition] = EMPTY_PIECE;
                }
                break;
            default:
                return;
        }
    }

    /**
     * getValue
     * @param position - the position in the board we want to get its value
     * @return the value of a specific position in the board
     */
    public int getValue(final int position) {
        if (position < 0 || position >= BOARD_SIZE) {
            return EMPTY_PIECE;
        }
        return board[position];
    }

    /**
     * getMoves
     * @return - the number of moves that has been played in this game so far
     */
    public int getMoves() {
        return this.moves;
    }

    /**
     * reverseBoard
     * Rotate the board and the piece board in 180 degrees
     */
    protected void reverseBoard() {
        int[] tempBoard = new int[BOARD_SIZE];
        int j = 0;
        for (int i = BOARD_SIZE - 1; i >= 0; i--) {
            tempBoard[j] = board[i];
            j++;
        }
        board = tempBoard;

        for (int i = 0; i < MAX_VALUE; i++) {
            for(Piece piece : this.pieceBoard[i]) {
                piece.setPosition(BOARD_SIZE - 1 - piece.getPosition());
            }
        }
    }

    /**
     * changeTurn
     * Changing the turn of the game according to teams position in the board
     */
    protected void changeTurn() {
        if (this.turn == 'W') {
            this.turn = 'B';
            this.calculatedMoves = 'W';
        } else {
            this.turn = 'W';
            this.calculatedMoves = 'B';
        }
    }

    /**
     * getIsManager
     * @return true - if the user is the manager of this game.
     *         false - otherwise.
     */
    public boolean getIsManager() {
        return this.isManager;
    }

    /**
     * turnHasChanged
     * Handle the game after a move has been played by any player. This function changing the game turn,
     * calculate the moves for the next team and increment the number of moves that has been played so far.
     */
    public void turnHasChanged() {
        this.changeTurn();
        this.calculateValidMoves();
        this.moves++;
    }

    /**
     * checkIfChess
     * @param team
     * @return true - if "team" is treating the other team (the other team is in chess).
     *         false - otherwise.
     */
    protected Boolean checkIfChess(char team) {
        ArrayList<Integer> possibleMoves = new ArrayList<Integer>();
        if (team == 'B') {
            for (int i = 0; i < MAX_VALUE / 2; i++) {
                for (Piece piece : pieceBoard[i]) {
                    possibleMoves.addAll(piece.getPossibleMoves(piece.getPosition(), board, this.turn));
                }
            }
            if (possibleMoves.contains(pieceBoard[Defines.WHITE_KING - 1][0].getPosition())) {
                return true;
            }
        } else {
            for (int i = (MAX_VALUE / 2) ; i < MAX_VALUE; i++) {
                for (Piece piece : pieceBoard[i]) {
                    possibleMoves.addAll(piece.getPossibleMoves(piece.getPosition(), board, this.turn));
                }
            }
            if (possibleMoves.contains(pieceBoard[Defines.BLACK_KING - 1][0].getPosition())) {
                return true;
            }
        }
        return false;
    }

    /**
     * setValueForCheck
     * Make a move to check if this move is valid or not (if move will make the user to be in check
     * after commit it - the move is not valid). and than return the board to current state.
     * @param value - the value of the piece
     * @param newPosition - the position the piece is moving to
     * @param lastPosition - the position the piece has moved from
     * @param team - the team of the piece
     * @return true - if the move is valid.
     *         false - otherwise.
     */
    protected boolean setValueForCheck(final int value, final int newPosition, final int lastPosition, char team) {
        if (value >= MIN_VALUE && value <= MAX_VALUE) {
            int temp = board[newPosition];
            board[newPosition] = value;
            board[lastPosition] = EMPTY_PIECE;
            for (Piece p : pieceBoard[value - 1]) {
                if (p.getPosition() == lastPosition && p.getAlive()) {
                    p.setPosition(newPosition);
                    break;
                }
            }
            boolean inChess = checkIfChess(team);
            for (Piece p : pieceBoard[value - 1]) {
                if (p.getPosition() == newPosition && p.getAlive()) {
                    p.setPosition(lastPosition);
                    break;
                }
            }
            board[newPosition] = temp;
            board[lastPosition] = value;
            return inChess;
        }
        return false;
    }

    /**
     * calculateValidMoves
     * Calculate the valid moves that a player can perform in his turn.
     */
    protected void calculateValidMoves() {
        if (this.turn == this.calculatedMoves) {
            return;
        } else {
            this.validMoves.clear();
            this.calculatedMoves = this.turn;
        }
        ArrayList<Integer> pieceMoves = new ArrayList<Integer>();
        Iterator<Integer> iterator;
        int lastPosition = 0;
        switch (this.turn) {
            case 'W':
                for (int i = (MAX_VALUE / 2) ; i < MAX_VALUE; i++) {
                    for (Piece piece : this.pieceBoard[i]) {
                        lastPosition = piece.getPosition();
                        if (piece.getType() == 'K') {
                            ((King) piece).setRightRookMoved(this.pieceBoard[Defines.WHITE_ROOK - 1][0].getMoves());
                            ((King) piece).setLeftRookMoved(this.pieceBoard[Defines.WHITE_ROOK - 1][1].getMoves());
                        }
                        pieceMoves.addAll(piece.getPossibleMoves(lastPosition, board, this.turn));
                        if (!pieceMoves.isEmpty()) {
                            iterator = pieceMoves.iterator();
                            while (iterator.hasNext()) {
                                int pos = iterator.next();
                                if (setValueForCheck(board[lastPosition], pos, lastPosition, 'B')) {
                                    iterator.remove();
                                }
                            }
                        }
                        if (!pieceMoves.isEmpty()) {
                            validMoves.put(lastPosition, new ArrayList<Integer>(pieceMoves));
                        }
                        pieceMoves.clear();
                    }
                }
                break;
            case 'B':
                for (int i = 0; i < MAX_VALUE / 2; i++) {
                    for (Piece piece : pieceBoard[i]) {
                        lastPosition = piece.getPosition();
                        if (piece.getType() == 'k') {
                            ((King) piece).setRightRookMoved(this.pieceBoard[Defines.BLACK_ROOK - 1][0].getMoves());
                            ((King) piece).setLeftRookMoved(this.pieceBoard[Defines.BLACK_ROOK - 1][1].getMoves());
                        }
                        pieceMoves.addAll(piece.getPossibleMoves(lastPosition, board, this.turn));
                        if (!pieceMoves.isEmpty()) {
                            iterator = pieceMoves.iterator();
                            while (iterator.hasNext()) {
                                int pos = iterator.next();
                                if (setValueForCheck(board[lastPosition], pos, lastPosition, 'W')) {
                                    iterator.remove();
                                }
                            }
                        }
                        if (!pieceMoves.isEmpty()) {
                            validMoves.put(lastPosition, new ArrayList<Integer>(pieceMoves));
                        }
                        pieceMoves.clear();
                    }
                }
                break;
            default:
                break;
        }
    }

    /**
     * getPossibleMoves
     * @param position - the position of the piece the user clicked on so he will get the valid
     *                   moves that it can make.
     * @return the valid moved for the piece in 'position'.
     */
    public ArrayList<Integer> getPossibleMoves(int position) {
        this.calculateValidMoves();
        if (this.validMoves.containsKey(position)) {
            return new ArrayList<>(this.validMoves.get(position));
        } else {
            return null;
        }
    }

    /**
     * checkForChess
     * @param turn - the team that the turn is it
     * @return 'P' - if there is a draw
     *         'M' - if there is a mate
     *         'C' - if there is a check
     *         'K' - otherwise.
     */
    public char calculateGameState(char turn) {
        if (checkForDraw(turn)) {
            this.gameState = 'P';
            return 'P';
        }
        if (this.validMoves.isEmpty() && moves != 0) {
            this.gameState = 'M';
            return 'M';
        }
        if (this.checkIfChess(getRivalTeam(turn))) {
            this.gameState = 'C';
            return 'C';
        }
        this.gameState = 'K';
        return 'K';
    }

    /**
     * checkForDraw
     * @param turn - the team that the turn is belong to it.
     * @return true - if there is a draw. false - otherwise.
     */
    private boolean checkForDraw(char turn) {
        if (!checkIfChess(getRivalTeam(turn)) && this.validMoves.isEmpty() && moves != 0) {
            return true;
        }
        int numOfKnightsAndBishops = 0;
        for (int i = 0; i < BOARD_SIZE; i++) {
            if (board[i] % Defines.NUMBER_OF_PIECES == Defines.BLACK_KNIGHT ||
                    board[i] % Defines.NUMBER_OF_PIECES == Defines.BLACK_BISHOP ||
                    board[i] % Defines.NUMBER_OF_PIECES == Defines.BLACK_KING) {
                numOfKnightsAndBishops++;
            } else if (board[i] != EMPTY_PIECE && board[i] != EN_PASSANT) {
                numOfKnightsAndBishops = 4;
                break;
            }
        }
        if (numOfKnightsAndBishops <= 3) {
            return true;
        }
        return false;
    }

    /**
     * getRivalTeam
     * @param turn - the team we want to get its rival
     * @return the other team
     */
    public char getRivalTeam(char turn) {
        if (turn == 'W')
            return 'B';
        return 'W';
    }

    /**
     * getTurn
     * @return the team that the turn belongs to it.
     */
    public char getTurn(){
        return this.turn;
    }

    /**
     * checkEnPassant
     * Check if there was an en passant move and take care of it.
     * @param value - the value of the pawn that commit the en passant
     * @param newPosition - the position the pawn is moving to
     * @param lastPosition - the position the pawn came from
     */
    public void checkEnPassant(final int value, final int newPosition, final int lastPosition) {
        if (this.enPassant != -1) {
            if (this.board[this.enPassant] == EN_PASSANT) {
                this.board[this.enPassant] = EMPTY_PIECE;
            }
            this.enPassant = -1;
        }
        if (value % Defines.NUMBER_OF_PIECES == 0 && lastPosition - newPosition == (BOARD_ROWS  * 2)) {
            this.enPassant = (BOARD_SIZE - 1) - (lastPosition - BOARD_ROWS);
            this.board[lastPosition - BOARD_ROWS] = EN_PASSANT;
        }
    }

    /**
     * createFEN
     * @return a FEN string to sent to the hint function.
     */
    public String createFEN() {
        String fen = ""; // each line from left to right
        for (int i = 0; i < BOARD_SIZE; i += BOARD_ROWS) {
            int counter = 0;
            for (int j = i + BOARD_ROWS - 1; j >= i; j--) {
                if (board[j] == EMPTY_PIECE || board[j] == EN_PASSANT) {
                    counter++;
                } else if (counter == 0) {
                    fen += this.pieceBoard[board[j] - 1][0].getType();
                } else { //counter != 0
                    fen += Integer.toString(counter);
                    fen += this.pieceBoard[board[j] - 1][0].getType();
                    counter = 0;
                }
                if (j % BOARD_ROWS == 0) {
                    if (counter != 0) {
                        fen += Integer.toString(counter);
                    }
                    fen += "/";
                }
            }
        }
        fen = fen.substring(0, fen.length() - 1);
        fen += " " + Character.toLowerCase(this.turn);
        fen += " " + this.canCastlingFEN();
        fen += " " + this.enPassantFEN();
        return fen;
    }

    /**
     * can canCastlingFEN
     * @return the string fot the castling in the FEN.
     */
    private String canCastlingFEN() {
        String castling = "";
        if (this.pieceBoard[Defines.WHITE_KING - 1][0].getMoves() == 0) {
            if (this.pieceBoard[Defines.WHITE_ROOK - 1][0].getMoves() == 0) {
                castling += 'K';
            }
            if (this.pieceBoard[Defines.WHITE_ROOK - 1][1].getMoves() == 0) {
                castling += 'Q';
            }
        }

        if (this.pieceBoard[Defines.BLACK_KING - 1][0].getMoves() == 0) {
            if (this.pieceBoard[Defines.BLACK_ROOK - 1][1].getMoves() == 0) {
                castling += 'k';
            }
            if (this.pieceBoard[Defines.BLACK_ROOK - 1][0].getMoves() == 0) {
                castling += 'q';
            }
        }

        if (castling.isEmpty()) {
            return "-"; // can't castling for both teams
        }
        return castling;
    }

    /**
     * enPassantFEN
     * @return the en passant FEN string
     */
    private String enPassantFEN() {
        if (this.enPassant == -1) {
            return "-";
        }
        String enPassant = "";
        switch (this.enPassant % BOARD_ROWS) {
            case 0:
                enPassant += "h";
                break;
            case 1:
                enPassant += "g";
                break;
            case 2:
                enPassant += "f";
                break;
            case 3:
                enPassant += "e";
                break;
            case 4:
                enPassant += "d";
                break;
            case 5:
                enPassant += "c";
                break;
            case 6:
                enPassant += "b";
                break;
            case 7:
                enPassant += "a";
                break;
        }
        switch (this.enPassant / BOARD_ROWS) {
            case 0:
                enPassant += "8";
                break;
            case 1:
                enPassant += "7";
                break;
            case 2:
                enPassant += "6";
                break;
            case 3:
                enPassant += "5";
                break;
            case 4:
                enPassant += "4";
                break;
            case 5:
                enPassant += "3";
                break;
            case 6:
                enPassant += "2";
                break;
            case 7:
                enPassant += "1";
                break;
        }
        return enPassant;
    }

    /**
     * needToChangePawn
     * @param position - the position the pawn is in it.
     * @param value - the value of the pawn
     * @return true - If a pawn has got to the end of the board.
     *         false - otherwise
     */
    public boolean needToChangePawn(int position, int value) {
        if (value % Defines.NUMBER_OF_PIECES == 0 && (position < BOARD_ROWS || position > (BOARD_SIZE - BOARD_ROWS - 1))) {
            return true;
        }
        return false;
    }

    /**
     * replacePieceBoard
     * Replace the pawn with other piece in case the pawn is in the end of the board
     * @param position - the position the pawn is in it
     * @param team - the team of the pawn
     * @param type - the type of the piece the user would like to change the pawn to
     * @param value - the value of the pawn
     */
    private void replacePieceBoard(int position, char team, char type, int value) {
        Piece[] temp = new Piece[pieceBoard[value].length + 1];
        int i;
        for (i = 0; i < pieceBoard[value].length; i++) {
            temp[i] = pieceBoard[value][i];
        }
        switch (Character.toUpperCase(type)) {
            case 'Q':
                temp[i] = new Queen(position, type, team);
                break;
            case 'N':
                temp[i] = new Knight(position, type, team);
                break;
            case 'B':
                temp[i] = new Bishop(position, type, team);
                break;
            case 'R':
                temp[i] = new Rook(position, type, team);
                break;
            default:
                break;
        }
        pieceBoard[value] = temp;
        board[position] = value + 1;
    }

    /**
     * changePawn
     * changing the pawn in case it got to the end of the board
     * @param position - the position of the pawn
     * @param type - the piece we want to change the pawn to
     */
    public void changePawn(int position, char type) {
        int value = board[position];
        int index = 0;
        for (int i = 0; i < pieceBoard[value - 1].length; i++) {
            if (pieceBoard[value - 1][i].getPosition() == position &&
                    pieceBoard[value - 1][i].getAlive()) {
                index = i;
                break;
            }
        }
        pieceBoard[value - 1][index].setAlive();
        switch (type) {
            case 'Q':
                switch (this.turn) {
                    case 'W':
                        replacePieceBoard(position, this.turn, type, (Defines.WHITE_QUEEN - 1));
                        break;
                    case 'B':
                        replacePieceBoard(position, this.turn, Character.toLowerCase(type), (Defines.BLACK_QUEEN - 1));
                        break;
                    default:
                        break;
                }
                break;
            case 'N':
                switch (this.turn) {
                    case 'W':
                        replacePieceBoard(position, this.turn, type, (Defines.WHITE_KNIGHT - 1));
                        break;
                    case 'B':
                        replacePieceBoard(position, this.turn, Character.toLowerCase(type), (Defines.BLACK_KNIGHT - 1));
                        break;
                    default:
                        break;
                }
                break;
            case 'B':
                switch (this.turn) {
                    case 'W':
                        replacePieceBoard(position, this.turn, type, (Defines.WHITE_BISHOP - 1));
                        break;
                    case 'B':
                        replacePieceBoard(position, this.turn, Character.toLowerCase(type), (Defines.BLACK_BISHOP - 1));
                        break;
                    default:
                        break;
                }
                break;
            case 'R':
                switch (this.turn) {
                    case 'W':
                        replacePieceBoard(position, this.turn, type, (Defines.WHITE_ROOK - 1));
                        break;
                    case 'B':
                        replacePieceBoard(position, this.turn, Character.toLowerCase(type), (Defines.BLACK_ROOK - 1));
                        break;
                    default:
                        break;
                }
                break;
            default:
                break;
        }
    }

    /**
     * addMoveToList
     * Adding a move to the move list
     * @param value - the value of the piece that has moved
     * @param to - the position the piece has been moved to
     * @param from - the position the piece came from
     */
    abstract public void addMoveToList(int value, int to, int from);

    /**
     * getMoveItems
     * @return the moves that has been played so far in the game.
     */
    public List<MoveItem> getMoveItems() {
        return this.moveItems;
    }

    /**
     * convertingPosition
     * Converting a number to a position on the board (for example: 56 -> h8)
     * @param position - the position we want to convert
     * @return the converting position
     */
    protected String convertingPosition(int position) {
        String pos = "";
        switch (position % BOARD_ROWS) {
            case 0:
                pos += "h";
                break;
            case 1:
                pos += "g";
                break;
            case 2:
                pos += "f";
                break;
            case 3:
                pos += "e";
                break;
            case 4:
                pos += "d";
                break;
            case 5:
                pos += "c";
                break;
            case 6:
                pos += "b";
                break;
            case 7:
                pos += "a";
                break;
        }
        switch (position / BOARD_ROWS) {
            case 0:
                pos += "8";
                break;
            case 1:
                pos += "7";
                break;
            case 2:
                pos += "6";
                break;
            case 3:
                pos += "5";
                break;
            case 4:
                pos += "4";
                break;
            case 5:
                pos += "3";
                break;
            case 6:
                pos += "2";
                break;
            case 7:
                pos += "1";
                break;
        }
        return pos;
    }
}
