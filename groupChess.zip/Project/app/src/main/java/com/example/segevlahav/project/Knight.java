package com.example.segevlahav.project;

import java.util.ArrayList;

/**
 * Knight
 * The knight piece.
 */
public class Knight extends Piece {
    /**
     * Knight
     * constructor
     * @param position- the piece position
     * @param type - the piece type
     * @param team - the piece team
     */
    Knight(int position, char type, char team) {
        super();
        this.position = position;
        this.type = type;
        this.team = team;
    }

    /**
     * getPossibleMoves
     * @param position - the piece position
     * @param board - the board matrix
     * @param turn - the team the turn belongs to her
     * @return all the valid moves the piece can move.
     */
    public ArrayList<Integer> getPossibleMoves(final int position, final int[] board, char turn) {
        ArrayList<Integer> possibleMoves = new ArrayList<Integer>();
        if (!this.alive) {
            return possibleMoves;
        }
        if (position >= GameBoard.BOARD_ROWS) {
            int temp = position - GameBoard.BOARD_ROWS;
            if (temp % GameBoard.BOARD_ROWS > 1) {
                if (board[temp - 2] == GameBoard.EMPTY_PIECE || board[temp - 2] == GameBoard.EN_PASSANT
                        || !sameTeam(board[position], board[temp - 2])) {
                    possibleMoves.add(temp - 2);
                }
            }
            if (temp % GameBoard.BOARD_ROWS < (GameBoard.BOARD_ROWS - 2)) {
                if (board[temp + 2] == GameBoard.EMPTY_PIECE || board[temp + 2] == GameBoard.EN_PASSANT
                        || !sameTeam(board[position], board[temp + 2])) {
                    possibleMoves.add(temp + 2);
                }
            }
        }
        if (position >= (GameBoard.BOARD_ROWS * 2)) {
            int temp = position - (GameBoard.BOARD_ROWS * 2);
            if (temp % GameBoard.BOARD_ROWS != 0) {
                if (board[temp - 1] == GameBoard.EMPTY_PIECE || board[temp - 1] == GameBoard.EN_PASSANT
                        || !sameTeam(board[position], board[temp - 1])) {
                    possibleMoves.add(temp - 1);
                }
            }
            if (temp % GameBoard.BOARD_ROWS != (GameBoard.BOARD_ROWS - 1)) {
                if (board[temp + 1] == GameBoard.EMPTY_PIECE || board[temp + 1] == GameBoard.EN_PASSANT
                        || !sameTeam(board[position], board[temp + 1])) {
                    possibleMoves.add(temp + 1);
                }
            }
        }
        if (position <= (GameBoard.BOARD_SIZE - GameBoard.BOARD_ROWS - 1)) {
            int temp = position + GameBoard.BOARD_ROWS;
            if (temp % GameBoard.BOARD_ROWS > 1) {
                if (board[temp - 2] == GameBoard.EMPTY_PIECE || board[temp - 2] == GameBoard.EN_PASSANT
                        || !sameTeam(board[position], board[temp - 2])) {
                    possibleMoves.add(temp - 2);
                }
            }
            if (temp % GameBoard.BOARD_ROWS < (GameBoard.BOARD_ROWS - 2)) {
                if (board[temp + 2] == GameBoard.EMPTY_PIECE || board[temp + 2] == GameBoard.EN_PASSANT
                        || !sameTeam(board[position], board[temp + 2])) {
                    possibleMoves.add(temp + 2);
                }
            }
        }
        if (position <= (GameBoard.BOARD_SIZE - (GameBoard.BOARD_ROWS * 2) - 1)) {
            int temp = position + (GameBoard.BOARD_ROWS * 2);
            if (temp % GameBoard.BOARD_ROWS != 0) {
                if (board[temp - 1] == GameBoard.EMPTY_PIECE || board[temp - 1] == GameBoard.EN_PASSANT
                        || !sameTeam(board[position], board[temp - 1])) {
                    possibleMoves.add(temp - 1);
                }
            }
            if (temp % GameBoard.BOARD_ROWS != (GameBoard.BOARD_ROWS - 1)) {
                if (board[temp + 1] == GameBoard.EMPTY_PIECE || board[temp + 1] == GameBoard.EN_PASSANT
                        || !sameTeam(board[position], board[temp + 1])) {
                    possibleMoves.add(temp + 1);
                }
            }
        }
        return possibleMoves;
    }

    /**
     * getPossibleMovesFourDGame
     * @param position - the piece position
     * @param board - the board matrix
     * @param turn - the team the turn belongs to her
     * @return all the valid moves the piece can move for the 4D game.
     */
    @Override
    public ArrayList<Integer> getPossibleMovesFourDGame(int position, int[] board, char turn) {
        ArrayList<Integer> possibleMoves = new ArrayList<Integer>();
        if (!this.alive) {
            return possibleMoves;
        }
        if (position >= FourDGameBoard.BOARD_ROWS) {
            int temp = position - FourDGameBoard.BOARD_ROWS;
            if (temp % FourDGameBoard.BOARD_ROWS > 1) {
                if (board[temp - 2] != FourDGameBoard.BAD_PLACE &&
                        (board[temp - 2] == FourDGameBoard.EMPTY_PIECE
                        || board[temp - 2] == FourDGameBoard.EN_PASSANT
                        || !sameTeam(board[position], board[temp - 2]))) {
                    possibleMoves.add(temp - 2);
                }
            }
            if (temp % FourDGameBoard.BOARD_ROWS < (FourDGameBoard.BOARD_ROWS - 2)) {
                if (board[temp + 2] != FourDGameBoard.BAD_PLACE &&
                        (board[temp + 2] == FourDGameBoard.EMPTY_PIECE
                        || board[temp + 2] == FourDGameBoard.EN_PASSANT
                        || !sameTeam(board[position], board[temp + 2]))) {
                    possibleMoves.add(temp + 2);
                }
            }
        }
        if (position >= (FourDGameBoard.BOARD_ROWS * 2)) {
            int temp = position - (FourDGameBoard.BOARD_ROWS  * 2);
            if (temp % FourDGameBoard.BOARD_ROWS != 0) {
                if (board[temp - 1] != FourDGameBoard.BAD_PLACE &&
                        (board[temp - 1] == FourDGameBoard.EMPTY_PIECE
                        || board[temp - 1] == FourDGameBoard.EN_PASSANT
                        || !sameTeam(board[position], board[temp - 1]))) {
                    possibleMoves.add(temp - 1);
                }
            }
            if (temp % FourDGameBoard.BOARD_ROWS != (FourDGameBoard.BOARD_ROWS - 1)) {
                if (board[temp + 1] != FourDGameBoard.BAD_PLACE &&
                        (board[temp + 1] == FourDGameBoard.EMPTY_PIECE
                        || board[temp + 1] == FourDGameBoard.EN_PASSANT
                        || !sameTeam(board[position], board[temp + 1]))) {
                    possibleMoves.add(temp + 1);
                }
            }
        }
        if (position <= (FourDGameBoard.BOARD_SIZE - FourDGameBoard.BOARD_ROWS)) {
            int temp = position + FourDGameBoard.BOARD_ROWS;
            if (temp % FourDGameBoard.BOARD_ROWS > 1) {
                if (board[temp - 2] != FourDGameBoard.BAD_PLACE &&
                        (board[temp - 2] == FourDGameBoard.EMPTY_PIECE
                        || board[temp - 2] == FourDGameBoard.EN_PASSANT
                        || !sameTeam(board[position], board[temp - 2]))) {
                    possibleMoves.add(temp - 2);
                }
            }
            if (temp % FourDGameBoard.BOARD_ROWS < (FourDGameBoard.BOARD_ROWS - 2)) {
                if (board[temp + 2] != FourDGameBoard.BAD_PLACE  &&
                        (board[temp + 2] == FourDGameBoard.EMPTY_PIECE
                        || board[temp + 2] == FourDGameBoard.EN_PASSANT
                        || !sameTeam(board[position], board[temp + 2]))) {
                    possibleMoves.add(temp + 2);
                }
            }
        }
        if (position <= (FourDGameBoard.BOARD_SIZE - (FourDGameBoard.BOARD_ROWS * 2) - 1)) {
            int temp = position + (FourDGameBoard.BOARD_ROWS * 2);
            if (temp % FourDGameBoard.BOARD_ROWS != 0) {
                if (board[temp - 1] != FourDGameBoard.BAD_PLACE &&
                        (board[temp - 1] == FourDGameBoard.EMPTY_PIECE
                        || board[temp - 1] == FourDGameBoard.EN_PASSANT
                        || !sameTeam(board[position], board[temp - 1]))) {
                    possibleMoves.add(temp - 1);
                }
            }
            if (temp % FourDGameBoard.BOARD_ROWS != (FourDGameBoard.BOARD_ROWS - 1)) {
                if (board[temp + 1] != FourDGameBoard.BAD_PLACE &&
                        (board[temp + 1] == FourDGameBoard.EMPTY_PIECE
                        || board[temp + 1] == FourDGameBoard.EN_PASSANT
                        || !sameTeam(board[position], board[temp + 1]))) {
                    possibleMoves.add(temp + 1);
                }
            }
        }
        return possibleMoves;
    }
}
