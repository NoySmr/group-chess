package com.example.segevlahav.project;

import android.content.Context;
import android.support.v4.app.FragmentActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * GameAdapter
 * Adapt the game item list to the list.
 */
public class GameAdapter extends BaseAdapter {
    private FragmentActivity activity;
    private LayoutInflater inflater;
    private ArrayList<GameItem> items;

    /**
     * @param activity - the current activity
     * @param items - the list of item we want to display
     * this function is the constructor of this class.
     */
    public GameAdapter(FragmentActivity activity, ArrayList<GameItem> items) {
        this.activity = activity;
        this.items = items;
    }

    /**
     * this function
     * @return the number of items in the list of items we hold
     */
    @Override
    public int getCount() {
        return items.size();
    }

    /**
     * this function gets
     * @param location - of item in the list
     * and
     * @return the item in that location
     */
    @Override
    public Object getItem(int location) {
        return items.get(location);
    }


    /**
     * this function gets the
     * @param position - the position of the item.
     * and
     * @return the id of it - i chose the id to be its position
     */
    @Override
    public long getItemId(int position) {
        return position;
    }

    /**
     * this function return the view of element in the list in position
     * from the args, the items are friend thus each item has name, status
     * and image that we need to display
     * @param position
     * @param convertView
     * @param parent
     * @return the convertView from the args
     */
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        if (inflater == null) {
            inflater = (LayoutInflater) activity
                    .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        }
        if (convertView == null) {
            convertView = inflater.inflate(R.layout.list_item_game, null);
        }
        // get the image, name and status from the view
        ImageView imgIcon = (ImageView) convertView.findViewById(R.id.game_icon);
        TextView gameName = (TextView) convertView.findViewById(R.id.game_name);
        TextView gameCode = (TextView) convertView.findViewById(R.id.game_code);
        ImageView newIcon = (ImageView) convertView.findViewById(R.id.new_icon);
        RelativeLayout layout = (RelativeLayout) convertView.findViewById(R.id.game_item);

        GameItem item = items.get(position);
        // set the image, status, and name of the item in the position
        int t = item.getIcon();
        imgIcon.setImageResource(t);
        gameName.setText(item.getName().replace('=', ' '));
        gameCode.setText(item.getCode());
        if (item.getIsNew()) {
            newIcon.setImageResource(R.drawable.new_icon);
        } else {
            newIcon.setImageResource(R.drawable.empty);
        }
        // set the layout on click listener to be what the item holds
        layout.setOnClickListener(item.getListener());
        // set the layout on touch listener to be what the item holds
        layout.setOnTouchListener(item.getTouchListener());

        return convertView;
    }

    /**
     * setItemList
     * @param itemList - the list og the game items
     */
    public void setItemList(ArrayList<GameItem> itemList) {
        this.items = itemList;
        Collections.sort(this.items, new Comparator<GameItem>() {
            @Override
            public int compare(GameItem o1, GameItem o2) {
                return o1.getName().compareTo(o2.getName());
            }
        });
    }
}
