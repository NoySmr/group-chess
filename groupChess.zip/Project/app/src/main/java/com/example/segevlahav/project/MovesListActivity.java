package com.example.segevlahav.project;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.List;

/**
 * MovesListActivity
 * The log screen. In this screen the user can see all the moves that has been played.
 */
public class MovesListActivity extends AppCompatActivity {
    private MovesListAdapter adapter; // the moves list adapter
    private String gameCode; // the game code
    private String fileName; // the game details file name
    private List<MoveItem> moveItems = new ArrayList<MoveItem>(); // the list of the moves

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_moves_list);

        Bundle bundle = getIntent().getExtras();
        try {
            gameCode = bundle.getString("gameCode");
            fileName = bundle.getString("fileName");
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        if (fileName.equals("4DName")) {
            FourDGameBoard gameBoard = (FourDGameBoard) FileManager.getGameBoard(this, gameCode);
            if (gameBoard != null) {
                moveItems = new ArrayList<MoveItem>(gameBoard.getMoveItems());
            }
        } else {
            GameBoard gameBoard = FileManager.getGameBoard(this, gameCode);
            if (gameBoard != null) {
                moveItems = new ArrayList<MoveItem>(gameBoard.getMoveItems());
            }
        }

        adapter = new MovesListAdapter(this, moveItems);
        ListView listView = (ListView) findViewById(R.id.lstMove);
        // Assign adapter to ListView
        listView.setAdapter(adapter);
    }

    /**
     * MovesListAdapter
     * Adapt the moves list to the list view.
     */
    private class MovesListAdapter extends BaseAdapter {
        private Activity activity;
        private LayoutInflater inflater;
        private List<MoveItem> items; // the moves list

        /**
         * MovesListAdapter
         * constructor
         * @param activity
         * @param items - the moves list
         */
        public MovesListAdapter(Activity activity, List<MoveItem> items) {
            this.activity = activity;
            this.items = items;
        }
        /**
         * getCount
         * @return the number of items in the list of items we hold
         */
        @Override
        public int getCount() {
            return items.size();
        }

        /**
         * getItem
         * @param location - of item in the list
         * and
         * @return the item in that location
         */
        @Override
        public Object getItem(int location) {
            return items.get(location);
        }


        /**
         * getItemId
         * @param position - the position of the item.
         * and
         * @return the id of it - i chose the id to be its position
         */
        @Override
        public long getItemId(int position) {
            return position;
        }

        /**
         * getView
         * @param position
         * @param convertView
         * @param parent
         * @return the list view
         */
        @Override
        public View getView(int position, View convertView, ViewGroup parent) {

            if (inflater == null) {
                inflater = (LayoutInflater) activity
                        .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            }
            if (convertView == null) {
                convertView = inflater.inflate(R.layout.list_item_move, null);
            }
            // get the image, name and status from the view
            ImageView imgIcon = (ImageView) convertView.findViewById(R.id.piece_icon);
            TextView from = (TextView) convertView.findViewById(R.id.from);
            TextView to = (TextView) convertView.findViewById(R.id.to);
            RelativeLayout layout = (RelativeLayout) convertView.findViewById(R.id.move_item);

            MoveItem item = items.get(position);
            // set the image, status, and name of the item in the position
            int value = item.getIcon();
            if (fileName.equals(Defines.FOUR_D_GAME_FILE)) {
                imgIcon.setImageDrawable(FourDGameController.validIcons[value]);
            } else {
                imgIcon.setImageDrawable(GameController.validIcons[value]);
            }
            from.setText(item.getFrom());
            to.setText(item.getTo());

            return convertView;
        }

        public void setItemList(List<MoveItem> itemList) {
            this.items = itemList;
        }
    }

}
