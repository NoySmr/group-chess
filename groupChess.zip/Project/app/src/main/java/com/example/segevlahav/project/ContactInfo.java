package com.example.segevlahav.project;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * ContactInfo
 * This class contain the information about the contacts. there name and phone number and a field that
 * tell us if the contact was selected or not.
 */
public class ContactInfo implements Parcelable {
    String number = null; // the contact phone number
    String name = null; // the contact name
    boolean selected; // the cantact was chosen or not

    /**
     * ContactInfo
     * constructor
     * @param name - the contact name
     * @param number - the contact phone number
     */
    public ContactInfo (String name, String number) {
        super();
        this.number = number;
        this.name = name;
        this.selected = false;
    }

    /**
     * ContactInfo
     * constructor
     * @param in
     */
    protected ContactInfo(Parcel in) {
        number = in.readString();
        name = in.readString();
        selected = in.readByte() != 0;
    }

    public static final Creator<ContactInfo> CREATOR = new Creator<ContactInfo>() {
        @Override
        public ContactInfo createFromParcel(Parcel in) {
            return new ContactInfo(in);
        }

        @Override
        public ContactInfo[] newArray(int size) {
            return new ContactInfo[size];
        }
    };

    /**
     * getNumber
     * @return the contact phone nuber
     */
    public String getNumber() {
        return this.number;
    }

    /**
     * setNumber
     * @param number - the contact phone nuber
     */
    public void setNumber(String number) {
        this.number = number;
    }

    /**
     * getName
     * @return the contact phone nuber
     */
    public String getName() {
        return name;
    }

    /**
     * setName
     * @param name - the contact name
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * isSelected
     * @return true - if the contact was selected. false - otherwise.
     */
    public boolean isSelected() {
        return selected;
    }

    /**
     * setSelected
     * @param selected - true - if the contact was selected. false - otherwise.
     */
    public void setSelected(boolean selected) {
        this.selected = selected;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(number);
        dest.writeString(name);
        dest.writeByte((byte) (selected ? 1 : 0));
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        ContactInfo other = (ContactInfo) obj;
        if (SMSManager.convertPhone(this.number).equals(SMSManager.convertPhone(other.number))) {
            return true;
        }
        return false;
    }
}

