package com.example.segevlahav.project;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.List;

/**
 * ChooseTeamsActivity
 * This activity is showing when the user has chosen to add game to the Group Game. After the user chose
 * at least one player to play with he moving to this activity. In this activity the user need to
 * choose in which team each player will be. The user (who created this group) will always be in the
 * white team.
 */
public class ChooseTeamsActivity extends AppCompatActivity {

    private MyCustomAdapter dataAdapter = null; // adapter of the contacts list
    private String gameName = ""; // the name of the group
    private int gamePicture = 0; // the icon of the group
    private String fileName = ""; // the game details file
    private Parcelable[] contactInfos; // the info about the participants

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choose_teams);

        Bundle bundle = getIntent().getExtras();
        try {
            gamePicture = bundle.getInt("gamePicture");
            gameName = bundle.getString("gameName");
            fileName = bundle.getString("fileName");
            contactInfos = bundle.getParcelableArray("contacts");

        } catch (Exception ex) {
            ex.printStackTrace();
        }

        ArrayList<ContactItem> contactItemList = new ArrayList<ContactItem>();
        for (int i = 0; i < contactInfos.length; i++) { // initialize the contact item list.
            contactItemList.add(new ContactItem(((ContactInfo)contactInfos[i]).getName(), ((ContactInfo)contactInfos[i]).getNumber()));
        }

        //create an ArrayAdaptar from the String Array
        dataAdapter = new MyCustomAdapter(this,
                R.layout.contacts_info, contactItemList);
        ListView listView = (ListView) findViewById(R.id.contactList);
        // Assign adapter to ListView
        listView.setAdapter(dataAdapter);

        checkButtonClick();
    }

    /**
     * MyCustomAdapter
     * To fit the contacts info to the list.
     */
    private class MyCustomAdapter extends ArrayAdapter<ContactItem> {
        private ArrayList<ContactItem> contactItemList;
        public MyCustomAdapter(Context context, int resource, ArrayList<ContactItem> contactItemList) {
            super(context, resource,contactItemList);
            this.contactItemList = new ArrayList<ContactItem>();
            this.contactItemList.addAll(contactItemList);
        }

        private class ViewHolder {
            TextView name; // the name of the participant
            RadioGroup radioGroup; // a radio button to choose the team of the other participants
        }

        public View getView(final int position, View convertView, ViewGroup parent) {
            ViewHolder viewHolder = null;
            if (convertView == null) {
                LayoutInflater vi = (LayoutInflater)getSystemService(
                        Context.LAYOUT_INFLATER_SERVICE);
                convertView = vi.inflate(R.layout.choose_contact_team, null);
                viewHolder = new ViewHolder();
                convertView.setTag(viewHolder);
            } else {
                viewHolder = (ViewHolder) convertView.getTag();
                convertView.setTag(viewHolder);
            }
            viewHolder.name = (TextView) convertView.findViewById(R.id.chosenContactName);
            viewHolder.radioGroup = (RadioGroup)convertView.findViewById(R.id.twoTeamsRadioGroup);
            if (this.contactItemList.get(position).isTeamWhite()) {
                viewHolder.radioGroup.check(R.id.whiteTeam);
            } else {
              viewHolder.radioGroup.check(R.id.blackTeam);
            }
            viewHolder.radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
                public void onCheckedChanged(RadioGroup group, int checkedId) {
                    switch (checkedId) {  // The team the user clicked on
                        case R.id.whiteTeam:
                            contactItemList.get(position).setTeam('W');
                            break;
                        case R.id.blackTeam:
                            contactItemList.get(position).setTeam('B');
                            break;
                    }
                }
            });
            ContactItem contactItem = this.contactItemList.get(position);
            viewHolder.name.setText(contactItem.getName());
            return convertView;
        }
    }

    /**
     * checkButtonClick
     * Check if the user chose at least one player for the black team (because the user is in the
     * white team we dont need to check it). If the user chose player/s for the black team he get back
     * to the previous activity (the game list).
     * Otherwise, a toast with the information about the problem is appears.
     */
    private void checkButtonClick() {
        Button myButton = (Button) findViewById(R.id.findSelectedTeam);
        myButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ArrayList<ContactItem> contactItemList = dataAdapter.contactItemList;
                List<ContactItem> whiteTeam = new ArrayList<ContactItem>();
                List<ContactItem> blackTeam = new ArrayList<ContactItem>();

                // initialize the teams
                for (int i = 0; i < contactItemList.size(); i++) {
                    ContactItem contactItem = contactItemList.get(i);
                    if (contactItem.isTeamWhite()) {
                        whiteTeam.add(contactItem);
                    } else {
                        blackTeam.add(contactItem);
                    }
                }

                if (!blackTeam.isEmpty()) { // In case the user chose at least one player for the black team
                    GameDetails gameDetails = FileManager.getGameDetails(ChooseTeamsActivity.this, fileName);
                    String gameId = FileManager.createId();
                    List<String> phoneNumbers = getNumbers(blackTeam);
                    phoneNumbers.addAll(getNumbers(whiteTeam));

                    if (gameDetails == null) { // In case the game details hasn't created yet, we need to create one.
                        gameDetails = new GameDetails();
                    }

                    gameDetails.addCodeAndNameAndPhoneNumbersAndPicture(gameId, gameName, phoneNumbers, gamePicture, "manager");
                    gameDetails.setCodeAndTeams(gameId, getNumbers(whiteTeam), getNumbers(blackTeam));
                    gameDetails.setCodeAndNew(gameId, true);
                    FileManager.saveGameDetails(ChooseTeamsActivity.this, gameDetails, fileName);
                    FileManager.saveGameBoard(ChooseTeamsActivity.this, gameId, new GroupGameBoard(true));
                    smsCreateGame(gameId, getNumbers(whiteTeam), getNumbers(blackTeam));
                    Intent intent = new Intent(ChooseTeamsActivity.this, GameListActivity.class);
                    intent.putExtra("fileName", fileName);
                    startActivity(intent);
                } else {  // In case the user didn't choose at least on player for the black team.
                    Toast.makeText(getApplicationContext(), "The black team is empty", Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    /**
     * getNumbers
     * @param contactItems - contact item list
     * @return list that contains only the phone numbers of the players.
     */
    public List<String> getNumbers(List<ContactItem> contactItems) {
        List<String> numbers = new ArrayList<String>();
        for (ContactItem c : contactItems) {
            numbers.add(SMSManager.convertPhone(c.getPhone()));
        }
        return numbers;
    }

    private void smsCreateGame(String code, List<String> whiteTeam, List<String> blackTeam) {
        SMSManager smsManager = new SMSManager();
        String smsMessage = SMSManager.messageIdentifier + " c " + code +
                Defines.SPACE + gameName + Defines.SPACE + Integer.toString(gamePicture);

        for (String whiteNum : whiteTeam) { // Sending sms to the members in the white team
            String tempSms = smsMessage + " W~";
            for (String white : whiteTeam) {
                if (!whiteNum.equals(white)) {
                    tempSms += SMSManager.convertPhone(white);
                }
                tempSms += Defines.COLON;
            }

            tempSms += Defines.SEMICOLON;

            for (String black : blackTeam) {
                if (!whiteNum.equals(black)) {
                    tempSms += SMSManager.convertPhone(black);
                }
                tempSms += Defines.COLON;
            }
            smsManager.sendSMS(whiteNum, tempSms);
        }

        for (String blackNum : blackTeam) { // Sending sms to the members in the black team
            String tempSms = smsMessage + " B~";
            for (String white : whiteTeam) {
                if (!blackNum.equals(white)) {
                    tempSms += SMSManager.convertPhone(white);
                }
                tempSms += Defines.COLON;
            }

            tempSms += Defines.SEMICOLON;

            for (String black : blackTeam) {
                if (!blackNum.equals(black)) {
                    tempSms += SMSManager.convertPhone(black);
                }
                tempSms += Defines.COLON;
            }

            smsManager.sendSMS(blackNum, tempSms);
        }
    }
}
