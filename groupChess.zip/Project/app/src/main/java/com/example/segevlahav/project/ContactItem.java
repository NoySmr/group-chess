package com.example.segevlahav.project;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by Segev on 05/05/2016.
 */
public class ContactItem  {
    private String name = null;
    private String phone = null;
    private char team;
    public ContactItem (String name, String phone) {
        super();
        this.name = name;
        this.phone = phone;
        this.team = 'W';
    }

    public String getName() {
        return this.name;
    }

    public String getPhone() {
        return this.phone;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public boolean isTeamWhite() {
        return team == 'W';
    }

    public char getTeam() {
        return this.team;
    }

    public void setTeam(char selected) {
        this.team = selected;
    }
    }
