package com.example.segevlahav.project;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * GameListActivityFragment
 * The fragment that handle the list of the games.
 */
public class GameListActivityFragment extends Fragment {

    /**
     * GameListActivityFragment
     * empty constructor
     */
    public GameListActivityFragment() {}

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_game_list, container, false);

        // initialize list view of options
        ListView lstMenu = (ListView) view.findViewById(R.id.lstMenu);
        // initialize options list
        final ArrayList<GameItem> gameItems = new ArrayList<GameItem>();
        Bundle bundle = this.getActivity().getIntent().getExtras();
        final String fileName = bundle.getString("fileName");
        final GameAdapter gameAdapter = new GameAdapter((FragmentActivity) getActivity(), gameItems);
        final GameDetails details = FileManager.getGameDetails(this.getActivity(), fileName);
        if (details != null) {
            // If the game details is already exist
            Map<String, String> codeAndName = details.getCodeAndName();
            Map<String, Integer> codeAndPicture = details.getCodeAndPicture();
            for (final String code: codeAndName.keySet()) {
                final String nameGame = codeAndName.get(code);
                final Integer picture = codeAndPicture.get(code);
                gameItems.add(new GameItem(nameGame, code, picture, details.getIsNew(code), new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        details.setCodeAndNew(code, false);
                        Intent mIntent;
                        if (fileName.equals(Defines.COMMON_GAME_FILE)) {
                            mIntent = new Intent(getActivity(), CommonGameActivity.class);
                        } else if (fileName.equals(Defines.GROUP_GAME_FILE)) {
                            mIntent = new Intent(getActivity(), GroupGameActivity.class);
                        } else {
                            mIntent = new Intent(getActivity(), FourDGameActivity.class);
                        }
                        mIntent.putExtra("gameName",nameGame);
                        mIntent.putExtra("gamePicture",(int)picture);
                        mIntent.putExtra("gameCode", code);
                        startActivity(mIntent);
                    }
                }, new OnSwipeTouchListener(getActivity()){
                    @Override
                    public void onSwipeRight() { // swipe right. open the participants screen
                        Intent mIntent;
                        mIntent = new Intent(getActivity(), ParticipantsActivity.class);
                        mIntent.putExtra("fileName", fileName);
                        mIntent.putExtra("gameCode", code);
                        startActivity(mIntent);
                    }
                    @Override
                    public void onSwipeLeft() { // swipe left. open the delete game dialog
                        AlertDialog.Builder alertDialog = new AlertDialog.Builder(getActivity());
                        alertDialog.setTitle("Delete Game");
                        alertDialog.setMessage("Are you sure you want delete this game ?");
                        alertDialog.setIcon(R.drawable.piece_think);

                        alertDialog.setNegativeButton("NO",
                                new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int which) { // the user decided not delete the game
                                        dialog.cancel();
                                    }
                                });
                        alertDialog.setPositiveButton("YES",
                                new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int which) { // the user decided to delete the game anyway
                                        smsDeleteGame(code, details.getPhoneNumbersByCode(code), fileName);
                                        details.deleteGame(code);
                                        FileManager.saveGameDetails(getActivity(), details, fileName);
                                        getActivity().finish();
                                        startActivity(getActivity().getIntent());
                                    }
                                });

                        alertDialog.show();
                    }
                    @Override
                    public void onClick() {
                        details.setCodeAndNew(code, false);
                        FileManager.saveGameDetails(getActivity(), details, fileName);
                        Intent mIntent;
                        if (fileName.equals(Defines.COMMON_GAME_FILE)) {
                            mIntent = new Intent(getActivity(), CommonGameActivity.class);
                        } else if(fileName.equals(Defines.GROUP_GAME_FILE)) {
                            mIntent = new Intent(getActivity(), GroupGameActivity.class);
                        } else {
                            mIntent = new Intent(getActivity(), FourDGameActivity.class);
                        }
                        mIntent.putExtra("gameName",nameGame);
                        mIntent.putExtra("gamePicture",(int)picture);
                        mIntent.putExtra("gameCode", code);
                        mIntent.putExtra("fileName", fileName);
                        getActivity().finish();
                        startActivity(mIntent);
                    }
                }));
            }
        }
        gameAdapter.setItemList(gameItems);
        lstMenu.setAdapter(gameAdapter);

        return view;

    }

    /**
     * smsDeleteGame
     * In case the user decided to delete a specific game he need to send a message to the other
     * players about it so they will remove him from the game.
     * @param code - the code of the game the user wants to delete
     * @param numbers - the numbers of the players in the game
     * @param fileName - the game details file name
     */
    private void smsDeleteGame(String code, List<String> numbers, String fileName) {
        SMSManager smsManager = new SMSManager();
        String smsMessage = "";
        if (fileName.equals(Defines.COMMON_GAME_FILE)) {
            smsMessage = SMSManager.messageIdentifier + " D " + code + Defines.TILDA;
        } else if (fileName.equals(Defines.GROUP_GAME_FILE)) {
            smsMessage = SMSManager.messageIdentifier + " d " + code + Defines.TILDA;
        } else if(fileName.equals(Defines.FOUR_D_GAME_FILE)) {
            smsMessage = SMSManager.messageIdentifier + " r " + code + Defines.TILDA;
        }
        for (String smsNum : numbers) {
            smsManager.sendSMS(smsNum, smsMessage);
        }
    }
}
