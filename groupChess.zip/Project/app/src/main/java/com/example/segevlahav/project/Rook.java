package com.example.segevlahav.project;

import java.util.ArrayList;

/**
 * Rook
 * The rook piece
 */
public class Rook extends Piece {

    /**
     * Rook
     * constructor
     * @param position- the piece position
     * @param type - the piece type
     * @param team - the piece team
     */
    Rook(int position, char type, char team) {
        super();
        this.position = position;
        this.type = type;
        this.team = team;
    }

    /**
     * getPossibleMoves
     * @param position - the piece position
     * @param board - the board matrix
     * @param turn - the team the turn belongs to her
     * @return all the valid moves the piece can move.
     */
    public ArrayList<Integer> getPossibleMoves(final int position, final int[] board, char turn) {
        ArrayList<Integer> possibleMoves = new ArrayList<Integer>();
        if (!this.alive) {
            return possibleMoves;
        }
        int temp = position;
        while (temp >= GameBoard.BOARD_ROWS) {
            if (board[temp - GameBoard.BOARD_ROWS] == GameBoard.EMPTY_PIECE || board[temp - GameBoard.BOARD_ROWS] == GameBoard.EN_PASSANT) {
                possibleMoves.add(temp - GameBoard.BOARD_ROWS);
            } else if (!sameTeam(board[position], board[temp - GameBoard.BOARD_ROWS])) {
                possibleMoves.add(temp - GameBoard.BOARD_ROWS);
                break;
            } else {
                break;
            }
            temp -= GameBoard.BOARD_ROWS;
        }
        temp = position;
        while (temp <= (GameBoard.BOARD_SIZE - GameBoard.BOARD_ROWS - 1)) {
            if (board[temp + GameBoard.BOARD_ROWS] == GameBoard.EMPTY_PIECE || board[temp + GameBoard.BOARD_ROWS] == GameBoard.EN_PASSANT) {
                possibleMoves.add(temp + GameBoard.BOARD_ROWS);
            } else if (!sameTeam(board[position], board[temp + GameBoard.BOARD_ROWS])) {
                possibleMoves.add(temp + GameBoard.BOARD_ROWS);
                break;
            } else {
                break;
            }
            temp += GameBoard.BOARD_ROWS;
        }
        temp = position;
        while (temp % GameBoard.BOARD_ROWS != 0) {
            if (board[temp - 1] == GameBoard.EMPTY_PIECE || board[temp - 1] == GameBoard.EN_PASSANT) {
                possibleMoves.add(temp - 1);
            } else if (!sameTeam(board[position], board[temp - 1])){
                possibleMoves.add(temp - 1);
                break;
            } else {
                break;
            }
            temp--;
        }
        temp = position;
        while (temp % GameBoard.BOARD_ROWS != (GameBoard.BOARD_ROWS - 1)) {
            if (board[temp + 1] == GameBoard.EMPTY_PIECE || board[temp + 1] == GameBoard.EN_PASSANT) {
                possibleMoves.add(temp + 1);
            } else if (!sameTeam(board[position], board[temp + 1])){
                possibleMoves.add(temp + 1);
                break;
            } else {
                break;
            }
            temp++;
        }

        return possibleMoves;
    }

    /**
     * getPossibleMovesFourDGame
     * @param position - the piece position
     * @param board - the board matrix
     * @param turn - the team the turn belongs to her
     * @return all the valid moves the piece can move for the 4D game.
     */
    @Override
    public ArrayList<Integer> getPossibleMovesFourDGame(int position, int[] board, char turn) {
        ArrayList<Integer> possibleMoves = new ArrayList<Integer>();
        if (!this.alive) {
            return possibleMoves;
        }
        int temp = position;
        while (temp >= FourDGameBoard.BOARD_ROWS) {
            if (board[temp - FourDGameBoard.BOARD_ROWS] == FourDGameBoard.EMPTY_PIECE || board[temp - FourDGameBoard.BOARD_ROWS] == FourDGameBoard.EN_PASSANT) {
                possibleMoves.add(temp - FourDGameBoard.BOARD_ROWS);
            }else if (board[temp - FourDGameBoard.BOARD_ROWS] == FourDGameBoard.BAD_PLACE) {
                break;
            } else if (!sameTeam(board[position], board[temp - FourDGameBoard.BOARD_ROWS])) {
                possibleMoves.add(temp - FourDGameBoard.BOARD_ROWS);
                break;
            } else {
                break;
            }
            temp -= FourDGameBoard.BOARD_ROWS;
        }
        temp = position;
        while (temp <= (FourDGameBoard.BOARD_SIZE - FourDGameBoard.BOARD_ROWS - 1)) {
            if (board[temp + FourDGameBoard.BOARD_ROWS] == FourDGameBoard.EMPTY_PIECE || board[temp + FourDGameBoard.BOARD_ROWS] == FourDGameBoard.EN_PASSANT) {
                possibleMoves.add(temp + FourDGameBoard.BOARD_ROWS);
            } else if (board[temp + FourDGameBoard.BOARD_ROWS] == FourDGameBoard.BAD_PLACE) {
                break;
            } else if (!sameTeam(board[position], board[temp + FourDGameBoard.BOARD_ROWS])) {
                possibleMoves.add(temp + FourDGameBoard.BOARD_ROWS);
                break;
            } else {
                break;
            }
            temp += FourDGameBoard.BOARD_ROWS;
        }
        temp = position;
        while (temp % FourDGameBoard.BOARD_ROWS != 0) {
            if (board[temp - 1] == FourDGameBoard.EMPTY_PIECE || board[temp - 1] == FourDGameBoard.EN_PASSANT) {
                possibleMoves.add(temp - 1);
            } else if (board[temp - 1] == FourDGameBoard.BAD_PLACE) {
                break;
            } else if (!sameTeam(board[position], board[temp - 1])){
                possibleMoves.add(temp - 1);
                break;
            } else {
                break;
            }
            temp--;
        }
        temp = position;
        while (temp % FourDGameBoard.BOARD_ROWS != (FourDGameBoard.BOARD_ROWS - 1)) {
            if (board[temp + 1] == FourDGameBoard.EMPTY_PIECE || board[temp + 1] == FourDGameBoard.EN_PASSANT) {
                possibleMoves.add(temp + 1);
            } else if (board[temp + 1] == FourDGameBoard.BAD_PLACE) {
                break;
            } else if (!sameTeam(board[position], board[temp + 1])){
                possibleMoves.add(temp + 1);
                break;
            } else {
                break;
            }
            temp++;
        }
        return possibleMoves;
    }
}
