package com.example.segevlahav.project;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;
import java.io.File;

/**
 * SettingsActivity
 * The screen where the user can choose the settings of the game.
 */
public class SettingsActivity extends AppCompatActivity {

    private Settings settings;
    private ImageView tilesImageView;
    private ImageView piecesImageView;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        tilesImageView = (ImageView) findViewById(R.id.tiles);
        piecesImageView = (ImageView) findViewById(R.id.pieces);
        File file = new File(getFilesDir() + "/" + Defines.SETTINGS_FILE);
        if(file.exists()) {
            this.settings = FileManager.getSettings(this);
        } else {
            this.settings = new Settings();
        }
        tilesImageView.setImageResource(this.settings.getCurrentTiles());
        piecesImageView.setImageResource(this.settings.getCurrentPieces());
    }

    /**
     * onSwitchRightTiles
     * @return the next tiles images
     */
    public void onSwitchRightTiles(View view) {
        tilesImageView.setImageResource(settings.onSwitchRightTiles());
        FileManager.saveSettings(this, this.settings);
    }

    /**
     * onSwitchLeftTiles
     * @return the previous tiles images
     */
    public void onSwitchLeftTiles(View view) {
        tilesImageView.setImageResource(settings.onSwitchLeftTiles());
        FileManager.saveSettings(this, this.settings);
    }

    /**
     * onSwitchRightPieces
     * @return the new pieces images
     */
    public void onSwitchRightPieces(View view) {
        piecesImageView.setImageResource(settings.onSwitchRightPieces());
        FileManager.saveSettings(this, this.settings);
    }

    /**
     * onSwitchLeftPieces
     * @return the previous pieces images
     */
    public void onSwitchLeftPieces(View view) {
        piecesImageView.setImageResource(settings.onSwitchLeftPieces());
        FileManager.saveSettings(this, this.settings);
    }

    @Override
    public void onBackPressed() { // return to the menu activity
        Intent intent = new Intent(SettingsActivity.this, MenuActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        super.onBackPressed();
    }
}
