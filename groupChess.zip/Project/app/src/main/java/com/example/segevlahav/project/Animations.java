package com.example.segevlahav.project;

import android.view.animation.AccelerateInterpolator;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.DecelerateInterpolator;

/**
 * Animations
 * Animations factory
 */
public class Animations {

    /**
     * fadeInAnimation
     * @return fade in animation
     */
    public static Animation fadeInAnimation() {
        Animation fadeIn = new AlphaAnimation(0, 1);
        fadeIn.setInterpolator(new DecelerateInterpolator()); //add this
        fadeIn.setDuration(1000);
        return fadeIn;
    }

    /**
     * fadeOutAnimation
     * @return fade out animation
     */
    public static Animation fadeOutAnimation() {
        Animation fadeOut = new AlphaAnimation(1, 0);
        fadeOut.setInterpolator(new AccelerateInterpolator()); //and this
        fadeOut.setStartOffset(1000);
        fadeOut.setDuration(1000);
        return fadeOut;
    }
}
