package com.example.segevlahav.project;

import java.util.ArrayList;

/**
 * Pawn
 * The pawn piece.
 */
public class Pawn extends Piece {

    /**
     * Piece
     * constructor
     * @param position- the piece position
     * @param type - the piece type
     * @param team - the piece team
     */
    Pawn(int position, char type, char team) {
        super();
        this.position = position;
        this.type = type;
        this.team = team;
    }

    /**
     * getPossibleMoves
     * @param position - the piece position
     * @param board - the board matrix
     * @param turn - the team the turn belongs to her
     * @return all the valid moves the piece can move.
     */
    public ArrayList<Integer> getPossibleMoves(final int position, final int[] board, char turn) {
        ArrayList<Integer> possibleMoves = new ArrayList<Integer>();
        if (!this.alive) {
            return possibleMoves;
        }
        boolean canMove = true;

        if (turn == this.team) {
            if (position >= GameBoard.BOARD_ROWS && board[position - GameBoard.BOARD_ROWS] == GameBoard.EMPTY_PIECE) {
                possibleMoves.add(position - GameBoard.BOARD_ROWS);
            } else {
                canMove = false;
            }
            if (this.moves == 0 && canMove) {
                if (position >= (GameBoard.BOARD_ROWS * 2) && board[position - (GameBoard.BOARD_ROWS * 2)] == GameBoard.EMPTY_PIECE) {
                    possibleMoves.add(position - (GameBoard.BOARD_ROWS * 2));
                }
            }
            if (position >= (GameBoard.BOARD_ROWS - 1) && (position - (GameBoard.BOARD_ROWS - 1)) % GameBoard.BOARD_ROWS != GameBoard.EMPTY_PIECE) {
                if (board[position - (GameBoard.BOARD_ROWS - 1)] != 0 && !sameTeam(board[position], board[position - (GameBoard.BOARD_ROWS - 1)])) {
                    possibleMoves.add(position - (GameBoard.BOARD_ROWS - 1));
                }
                if (board[position - (GameBoard.BOARD_ROWS - 1)] == GameBoard.EN_PASSANT) {
                    possibleMoves.add(position - (GameBoard.BOARD_ROWS - 1));
                }
            }
            if (position >= (GameBoard.BOARD_ROWS + 1) && (position - (GameBoard.BOARD_ROWS + 1)) % GameBoard.BOARD_ROWS != (GameBoard.BOARD_ROWS - 1)) {
                if (board[position - (GameBoard.BOARD_ROWS + 1)] != 0 && !sameTeam(board[position], board[position - (GameBoard.BOARD_ROWS + 1)])) {
                    possibleMoves.add(position - (GameBoard.BOARD_ROWS + 1));
                }
                if (board[position - (GameBoard.BOARD_ROWS + 1)] == GameBoard.EN_PASSANT) {
                    possibleMoves.add(position - (GameBoard.BOARD_ROWS + 1));
                }
            }
        } else {
            if (position <= (GameBoard.BOARD_SIZE - GameBoard.BOARD_ROWS - 1) && board[position + GameBoard.BOARD_ROWS] == GameBoard.EMPTY_PIECE) {
                possibleMoves.add(position + GameBoard.BOARD_ROWS);
            } else {
                canMove = false;
            }
            if (this.moves == 0 && canMove) {
                if (position <= (GameBoard.BOARD_SIZE - (GameBoard.BOARD_ROWS * 2) - 1) && board[position + (GameBoard.BOARD_ROWS * 2)] == GameBoard.EMPTY_PIECE) {
                    possibleMoves.add(position + (GameBoard.BOARD_ROWS * 2));
                }
            }
            if (position <= (GameBoard.BOARD_SIZE - GameBoard.BOARD_ROWS) && (position + (GameBoard.BOARD_ROWS - 1)) % GameBoard.BOARD_ROWS != (GameBoard.BOARD_ROWS - 1)) {
                if (board[position + (GameBoard.BOARD_ROWS - 1)] != 0 && !sameTeam(board[position], board[position + (GameBoard.BOARD_ROWS - 1)])) {
                    possibleMoves.add(position + (GameBoard.BOARD_ROWS - 1));
                }
            }
            if (position <= (GameBoard.BOARD_SIZE - GameBoard.BOARD_ROWS - 2) && (position + (GameBoard.BOARD_ROWS + 1)) % GameBoard.BOARD_ROWS != 0) {
                if (board[position + (GameBoard.BOARD_ROWS + 1)] != 0 && !sameTeam(board[position], board[position + (GameBoard.BOARD_ROWS + 1)])) {
                    possibleMoves.add(position + (GameBoard.BOARD_ROWS + 1));
                }
            }
        }
        return possibleMoves;
    }

    /**
     * getPossibleMovesFourDGame
     * @param position - the piece position
     * @param board - the board matrix
     * @param turn - the team the turn belongs to her
     * @return all the valid moves the piece can move for the 4D game.
     */
    @Override
    public ArrayList<Integer> getPossibleMovesFourDGame(int position, int[] board, char turn) {
        switch (turn) {
            case 'W':
                switch (this.team) {
                    case 'W':
                        return this.getPossibleMovesUp(position, board, turn);
                    case 'B':
                        return this.getPossibleMovesDown(position, board, turn);
                    case 'R':
                        return this.getPossibleMovesLeft(position, board, turn);
                    case 'G':
                        return this.getPossibleMovesRight(position, board, turn);
                    default:
                        return null;
                }
            case 'B':
                switch (this.team) {
                    case 'W':
                        return this.getPossibleMovesDown(position, board, turn);
                    case 'B':
                        return this.getPossibleMovesUp(position, board, turn);
                    case 'R':
                        return this.getPossibleMovesRight(position, board, turn);
                    case 'G':
                        return this.getPossibleMovesLeft(position, board, turn);
                    default:
                        return null;
                }
            case 'R':
                switch (this.team) {
                    case 'W':
                        return this.getPossibleMovesRight(position, board, turn);
                    case 'B':
                        return this.getPossibleMovesLeft(position, board, turn);
                    case 'R':
                        return this.getPossibleMovesUp(position, board, turn);
                    case 'G':
                        return this.getPossibleMovesDown(position, board, turn);
                    default:
                        return null;
                }
            case 'G':
                switch (this.team) {
                    case 'W':
                        return this.getPossibleMovesLeft(position, board, turn);
                    case 'B':
                        return this.getPossibleMovesRight(position, board, turn);
                    case 'R':
                        return this.getPossibleMovesDown(position, board, turn);
                    case 'G':
                        return this.getPossibleMovesUp(position, board, turn);
                    default:
                        return null;
                }
            default:
                return null;
        }
    }

    /**
     * get getPossibleMovesRight
     * @param position - the pawn position
     * @param board - the game board
     * @param turn - the team the turn belongs to it
     * @return all the valid moves the pawn can make to the right
     */
    private ArrayList<Integer> getPossibleMovesRight(int position, int[] board, char turn) {
        ArrayList<Integer> possibleMoves = new ArrayList<Integer>();
        if (!this.alive) {
            return possibleMoves;
        }
        boolean canMove = true;

        if (position >= 1 && board[position - 1] == FourDGameBoard.EMPTY_PIECE) {
            possibleMoves.add(position - 1);
        } else {
            canMove = false;
        }
        if (this.moves == 0 && canMove) {
            if (position >= 2 && board[position - 2] == FourDGameBoard.EMPTY_PIECE) {
                possibleMoves.add(position - 2);
            }
        }
        if (position >= (FourDGameBoard.BOARD_ROWS + 1) && (position - (FourDGameBoard.BOARD_ROWS + 1)) % FourDGameBoard.BOARD_ROWS != 10) {
            if (board[position - (FourDGameBoard.BOARD_ROWS + 1)] != FourDGameBoard.BAD_PLACE && board[position - (FourDGameBoard.BOARD_ROWS + 1)] != FourDGameBoard.EMPTY_PIECE
                    && !sameTeam(board[position], board[position - (FourDGameBoard.BOARD_ROWS + 1)])) {
                possibleMoves.add(position - (FourDGameBoard.BOARD_ROWS + 1));
            }
            if (board[position - (FourDGameBoard.BOARD_ROWS + 1)] == FourDGameBoard.EN_PASSANT) {
                possibleMoves.add(position - (FourDGameBoard.BOARD_ROWS + 1));
            }
        }
        if (position <= (FourDGameBoard.BOARD_SIZE - FourDGameBoard.BOARD_ROWS) && (position + (FourDGameBoard.BOARD_ROWS - 1)) % FourDGameBoard.BOARD_ROWS != 10) {
            if (board[position + (FourDGameBoard.BOARD_ROWS - 1)] != FourDGameBoard.BAD_PLACE && board[position + (FourDGameBoard.BOARD_ROWS - 1)] != FourDGameBoard.EMPTY_PIECE &&
                    !sameTeam(board[position], board[position + 13])) {
                possibleMoves.add(position + (FourDGameBoard.BOARD_ROWS - 1));
            }
            if (board[position + (FourDGameBoard.BOARD_ROWS - 1)] == FourDGameBoard.EN_PASSANT) {
                possibleMoves.add(position + (FourDGameBoard.BOARD_ROWS - 1));
            }
        }

        return possibleMoves;
    }

    /**
     * getPossibleMovesLeft
     * @param position - the pawn position
     * @param board - the game board
     * @param turn - the team the turn belongs to it
     * @return all the valid moves the pawn can make to the left
     */
    private ArrayList<Integer> getPossibleMovesLeft(int position, int[] board, char turn) {
        ArrayList<Integer> possibleMoves = new ArrayList<Integer>();
        if (!this.alive) {
            return possibleMoves;
        }
        boolean canMove = true;

        if (position <= (FourDGameBoard.BOARD_SIZE - 2) && board[position + 1] == FourDGameBoard.EMPTY_PIECE) {
            possibleMoves.add(position + 1);
        } else {
            canMove = false;
        }
        if (this.moves == 0 && canMove) {
            if (position <= (FourDGameBoard.BOARD_SIZE - 3) && board[position + 2] == FourDGameBoard.EMPTY_PIECE) {
                possibleMoves.add(position + 2);
            }
        }
        if (position >= (FourDGameBoard.BOARD_ROWS - 1) && (position - (FourDGameBoard.BOARD_ROWS - 1)) % FourDGameBoard.BOARD_ROWS != 3) {
            if (board[position - (FourDGameBoard.BOARD_ROWS - 1)] != FourDGameBoard.BAD_PLACE && board[position - (FourDGameBoard.BOARD_ROWS - 1)] != FourDGameBoard.EMPTY_PIECE &&
                    !sameTeam(board[position], board[position - (FourDGameBoard.BOARD_ROWS - 1)])) {
                possibleMoves.add(position - (FourDGameBoard.BOARD_ROWS - 1));
            }
            if (board[position - (FourDGameBoard.BOARD_ROWS - 1)] == FourDGameBoard.EN_PASSANT) {
                possibleMoves.add(position - (FourDGameBoard.BOARD_ROWS - 1));
            }
        }
        if (position <= (FourDGameBoard.BOARD_SIZE - FourDGameBoard.BOARD_ROWS - 2) && (position + (FourDGameBoard.BOARD_ROWS + 1)) % FourDGameBoard.BOARD_ROWS != 3) {
            if (board[position + (FourDGameBoard.BOARD_ROWS + 1)] != FourDGameBoard.BAD_PLACE && board[position + (FourDGameBoard.BOARD_ROWS + 1)] != FourDGameBoard.EMPTY_PIECE &&
                    !sameTeam(board[position], board[position + (FourDGameBoard.BOARD_ROWS + 1)])) {
                possibleMoves.add(position + (FourDGameBoard.BOARD_ROWS + 1));
            }
            if (board[position + (FourDGameBoard.BOARD_ROWS + 1)] == FourDGameBoard.EN_PASSANT) {
                possibleMoves.add(position + (FourDGameBoard.BOARD_ROWS + 1));
            }
        }

        return possibleMoves;
    }

    /**
     * getPossibleMovesDown
     * @param position - the pawn position
     * @param board - the game board
     * @param turn - the team the turn belongs to it
     * @return all the valid moves the pawn can make down
     */
    private ArrayList<Integer> getPossibleMovesDown(int position, int[] board, char turn) {
        ArrayList<Integer> possibleMoves = new ArrayList<Integer>();
        if (!this.alive) {
            return possibleMoves;
        }
        boolean canMove = true;

        if (position <= (FourDGameBoard.BOARD_SIZE - FourDGameBoard.BOARD_ROWS - 1) && board[position + FourDGameBoard.BOARD_ROWS] == FourDGameBoard.EMPTY_PIECE) {
            possibleMoves.add(position + FourDGameBoard.BOARD_ROWS);
        } else {
            canMove = false;
        }
        if (this.moves == 0 && canMove) {
            if (position <= (FourDGameBoard.BOARD_SIZE - (FourDGameBoard.BOARD_ROWS * 2) - 1) && board[position + (FourDGameBoard.BOARD_ROWS * 2)] == FourDGameBoard.EMPTY_PIECE) {
                possibleMoves.add(position + (FourDGameBoard.BOARD_ROWS * 2));
            }
        }
        if (position <= (FourDGameBoard.BOARD_SIZE - FourDGameBoard.BOARD_ROWS) && (position + (FourDGameBoard.BOARD_ROWS - 1)) % FourDGameBoard.BOARD_ROWS != 10) {
            if (board[position + (FourDGameBoard.BOARD_ROWS - 1)] != FourDGameBoard.BAD_PLACE && board[position + (FourDGameBoard.BOARD_ROWS - 1)] != FourDGameBoard.EMPTY_PIECE &&
                    !sameTeam(board[position], board[position + (FourDGameBoard.BOARD_ROWS - 1)])) {
                possibleMoves.add(position + (FourDGameBoard.BOARD_ROWS - 1));
            }
            if (board[position + (FourDGameBoard.BOARD_ROWS - 1)] == FourDGameBoard.EN_PASSANT) {
                possibleMoves.add(position + (FourDGameBoard.BOARD_ROWS - 1));
            }
        }
        if (position <= (FourDGameBoard.BOARD_SIZE - FourDGameBoard.BOARD_ROWS - 2) && (position + (FourDGameBoard.BOARD_ROWS + 1)) % FourDGameBoard.BOARD_ROWS != 3) {
            if (board[position + (FourDGameBoard.BOARD_ROWS + 1)] != FourDGameBoard.BAD_PLACE && board[position + (FourDGameBoard.BOARD_ROWS + 1)] != FourDGameBoard.EMPTY_PIECE &&
                    !sameTeam(board[position], board[position + (FourDGameBoard.BOARD_ROWS + 1)])) {
                possibleMoves.add(position + (FourDGameBoard.BOARD_ROWS + 1));
            }
            if (board[position + (FourDGameBoard.BOARD_ROWS + 1)] == FourDGameBoard.EN_PASSANT) {
                possibleMoves.add(position + (FourDGameBoard.BOARD_ROWS + 1));
            }
        }

        return possibleMoves;
    }

    /**
     * getPossibleMovesUp
     * @param position - the pawn position
     * @param board - the game board
     * @param turn - the team the turn belongs to it
     * @return all the valid moves the pawn can make up
     */
    private ArrayList<Integer> getPossibleMovesUp(int position, int[] board, char turn) {
        ArrayList<Integer> possibleMoves = new ArrayList<Integer>();
        if (!this.alive) {
            return possibleMoves;
        }
        boolean canMove = true;

        if (position >= FourDGameBoard.BOARD_ROWS && board[position - FourDGameBoard.BOARD_ROWS] == FourDGameBoard.EMPTY_PIECE) {
            possibleMoves.add(position - FourDGameBoard.BOARD_ROWS);
        } else {
            canMove = false;
        }
        if (this.moves == 0 && canMove) {
            if (position >= (FourDGameBoard.BOARD_ROWS * 2) && board[position - (FourDGameBoard.BOARD_ROWS * 2)] == FourDGameBoard.EMPTY_PIECE) {
                possibleMoves.add(position - (FourDGameBoard.BOARD_ROWS * 2));
            }
        }
        if (position >= (FourDGameBoard.BOARD_ROWS - 1) && (position - (FourDGameBoard.BOARD_ROWS - 1)) % FourDGameBoard.BOARD_ROWS != 3) {
            if (board[position - (FourDGameBoard.BOARD_ROWS - 1)] != FourDGameBoard.BAD_PLACE && board[position - (FourDGameBoard.BOARD_ROWS - 1)] != FourDGameBoard.EMPTY_PIECE &&
                    !sameTeam(board[position], board[position - (FourDGameBoard.BOARD_ROWS - 1)])) {
                possibleMoves.add(position - (FourDGameBoard.BOARD_ROWS - 1));
            }
            if (board[position - (FourDGameBoard.BOARD_ROWS - 1)] == FourDGameBoard.EN_PASSANT) {
                possibleMoves.add(position - (FourDGameBoard.BOARD_ROWS - 1));
            }
        }
        if (position >= (FourDGameBoard.BOARD_ROWS + 1) && (position - (FourDGameBoard.BOARD_ROWS + 1)) % FourDGameBoard.BOARD_ROWS != 10) {
            if (board[position - (FourDGameBoard.BOARD_ROWS + 1)] != FourDGameBoard.BAD_PLACE && board[position - (FourDGameBoard.BOARD_ROWS + 1)] != FourDGameBoard.EMPTY_PIECE &&
                    !sameTeam(board[position], board[position - (FourDGameBoard.BOARD_ROWS + 1)])) {
                possibleMoves.add(position - (FourDGameBoard.BOARD_ROWS + 1));
            }
            if (board[position - (FourDGameBoard.BOARD_ROWS + 1)] == FourDGameBoard.EN_PASSANT) {
                possibleMoves.add(position - (FourDGameBoard.BOARD_ROWS + 1));
            }
        }

        return possibleMoves;
    }
}
