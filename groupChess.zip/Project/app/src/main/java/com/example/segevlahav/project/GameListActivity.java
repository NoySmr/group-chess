package com.example.segevlahav.project;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

/**
 * GameListActivity
 * This activity is the screen with all the games in a certain game.
 */
public class GameListActivity extends AppCompatActivity {

    private String fileName; // the file name of the game details
    private BroadcastReceiver receiver = new Receiver();

    @Override
    protected void onResume() {
        IntentFilter filter = new IntentFilter();
        filter.addAction("com.biu.gamelist.message.DONE");
        registerReceiver(receiver, filter);
        super.onResume();
    }

    @Override
    protected void onPause() {
        unregisterReceiver(receiver);
        super.onPause();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game_list);

        Bundle bundle = getIntent().getExtras();
        fileName = bundle.getString("fileName");
        Button addGameButton = (Button) findViewById(R.id.addGameButton);
        addGameButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(GameListActivity.this, AddGameActivity.class);
                intent.putExtra("fileName", fileName);
                startActivity(intent);
            }
        });
    }

    @Override
    public void onBackPressed() {
        Intent intent = new Intent(GameListActivity.this, MenuActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        super.onBackPressed();
    }

    /**
     * refresh
     * Refreshing the screen if data has changed
     * @param file - the file of the game details we need to reload
     */
    private void refresh(String file) {
        if(file.equals(fileName)) {
            this.finish();
            startActivity(this.getIntent());
        }
    }

    /**
     * Receiver
     * When the activity gets new data behind the scenes the receiver let the activity the ability
     * to see it and do with it what it needs.
     */
    private class Receiver extends BroadcastReceiver {

        @Override
        public void onReceive(Context context, Intent intent) {
            Bundle bundle;
            if(intent.getAction().equals("com.biu.gamelist.message.DONE")) {
                bundle = intent.getExtras();
                refresh(bundle.getString("fileName"));
            }
        }
    }

}
