package com.example.segevlahav.project;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;

/**
 * MenuActivity
 * The activity of the main menu.
 */
public class MenuActivity extends AppCompatActivity {
    private Button commonButton; // first button
    private Button groupButton; // second button
    private Button fourDButton; // third button
    private Button settingButton; // fourth button
    private Button statisticsButton; // fifth button
    private ImageView logo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        // set the logo
        this.logo = (ImageView) findViewById(R.id.logo);

        // set the buttons
        this.commonButton = (Button) findViewById(R.id.commonGameButton);
        this.groupButton = (Button) findViewById(R.id.groupGameButton);
        this.fourDButton = (Button) findViewById(R.id.fourDGameButton);
        this.settingButton = (Button) findViewById(R.id.settings_button);
        this.statisticsButton = (Button) findViewById(R.id.statistics_button);

        // set the animations
        final Animation leftAnim = AnimationUtils.loadAnimation(getApplicationContext(),
                R.anim.from_left);
        final Animation rightAnim = AnimationUtils.loadAnimation(getApplicationContext(),
                R.anim.from_right);
        final Animation upAnim = AnimationUtils.loadAnimation(getApplicationContext(),
                R.anim.from_up);
        this.commonButton.startAnimation(leftAnim);
        this.fourDButton.startAnimation(leftAnim);
        this.groupButton.startAnimation(rightAnim);
        this.settingButton.startAnimation(rightAnim);
        this.statisticsButton.startAnimation(leftAnim);
        logo.startAnimation(upAnim);

        // set on click listeners
        this.commonButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MenuActivity.this, GameListActivity.class);
                intent.putExtra("fileName", Defines.COMMON_GAME_FILE);
                startActivity(intent);
            }
        });
        this.groupButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MenuActivity.this, GameListActivity.class);
                intent.putExtra("fileName", Defines.GROUP_GAME_FILE);
                startActivity(intent);
            }
        });
        this.fourDButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MenuActivity.this, GameListActivity.class);
                intent.putExtra("fileName", Defines.FOUR_D_GAME_FILE);
                startActivity(intent);
            }
        });
        this.settingButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MenuActivity.this, SettingsActivity.class));
            }
        });
        this.statisticsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MenuActivity.this, StatisticsActivity.class));
            }
        });

    }
}
