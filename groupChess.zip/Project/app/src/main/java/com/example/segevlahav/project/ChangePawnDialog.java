package com.example.segevlahav.project;

import android.app.Activity;
import android.app.DialogFragment;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;

/**
 * ChangePawnDialog
 * This dialog fragment is show up when a pawn has got to the end of the board. This dialog contain
 * photos of a rook, a knight, a bishop and a queen which the user can choose one of them to switch
 * the pawn.
 */
public class ChangePawnDialog extends DialogFragment implements View.OnClickListener {
    private Button queen, knight, bishop, rook;
    private Communicator communicator; // to communicate with the activity the dialog is in it
    private int position; // the position of the pawn
    private char team; // the team of the pawn

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        communicator = (Communicator) activity; // initialize the communicator
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        team = getArguments().getChar("team");
        position = getArguments().getInt("position");
        View view;
        switch (team) { // to know which layout we need to show the user.
            case 'W':
                view = inflater.inflate(R.layout.change_pawn_white, null);
                break;
            case 'B':
                view = inflater.inflate(R.layout.change_pawn_black, null);
                break;
            case 'R':
                view = inflater.inflate(R.layout.change_pawn_red, null);
                break;
            case 'G':
                view = inflater.inflate(R.layout.change_pawn_green, null);
                break;
            default:
                view = inflater.inflate(R.layout.change_pawn_white, null);
        }

        queen = (Button) view.findViewById(R.id.queenButton);
        knight = (Button) view.findViewById(R.id.knightButton);
        bishop = (Button) view.findViewById(R.id.bishopButton);
        rook = (Button) view.findViewById(R.id.rookButton);

        queen.setOnClickListener(this);
        knight.setOnClickListener(this);
        bishop.setOnClickListener(this);
        rook.setOnClickListener(this);

        setCancelable(false); // to not let the user to get out of the dialog without choosing piece
        getDialog().getWindow().requestFeature(Window.FEATURE_NO_TITLE); // remove the dialog title
        getDialog().getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT)); // to make the dialog transpert
        return view;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.queenButton: // user clicked on the queen
                communicator.onDialogMessage('Q', position);
                dismiss(); // close the dialog
                break;
            case R.id.knightButton: // user clicked on the knight
                communicator.onDialogMessage('N', position);
                dismiss(); // close the dialog
                break;
            case R.id.bishopButton: // user clicked on the bishop
                communicator.onDialogMessage('B', position);
                dismiss(); // close the dialog
                break;
            case R.id.rookButton: // user clicked on the rook
                communicator.onDialogMessage('R', position);
                dismiss(); // close the dialog
                break;
        }
    }

    interface Communicator {
        public void onDialogMessage(char team, int position);
    }
}

