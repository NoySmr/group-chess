package com.example.segevlahav.project;

import android.view.View;

/**
 * Created by Segev on 03/04/2016.
 */
public class GameItem {
    private String name; // name of the game
    private String code; // code of the game
    private int icon; // the image of the game
    private boolean isNew; // if the game is new
    private View.OnClickListener listener; // the listener for touch
    private View.OnTouchListener touchListener;

    /**
     * this function is the constructor of this class
     * @param name - the name of the game
     * @param code - the code of the game
     * @param icon - the icon of the game
     * @param listener - the on touch listener of the game
     */
    public GameItem(String name, String code, int icon, boolean isNew, View.OnClickListener listener,View.OnTouchListener touchListener){
        this.name = name;
        this.icon = icon;
        this.code = code;
        this.isNew = isNew;
        this.listener = listener;
        this.touchListener = touchListener;

    }

    /**
     * this function
     * @return the name of the game
     */
    public String getName(){
        return this.name;
    }

    /**
     * this function
     * @return the code of the game
     */
    public String getCode(){
        return this.code;
    }

    /**
     * this function
     * @return the icon of the game
     */
    public int getIcon(){
        return this.icon;
    }

    public boolean getIsNew() {
        return this.isNew;
    }

    /**
     * this function
     * @return the on touch listener.
     */
    public View.OnClickListener getListener(){
        return this.listener;
    }
    /**
     * this function
     * @return the on touch listener.
     */
    public View.OnTouchListener getTouchListener(){
        return this.touchListener;
    }

}
