package com.example.segevlahav.project;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;

/**
 * CommonGameActivity
 * The activity of the common game (the first option in the menu activity). This activity is the
 * screen with the chess board which the player sees when he play.
 */
public class CommonGameActivity extends AppCompatActivity implements ChangePawnDialog.Communicator {
    private GridView board; // the chess board
    private CommonGameController gameController;
    private String gameCode; // the game code
    private String gameName; // the name of the group/game
    private String fileName; // the name of the game details file
    private int picture; // the icon of the game
    private BroadcastReceiver receiver = new Receiver();
    private static boolean afterRefresh = false;

    @Override
    protected void onResume() {
        IntentFilter filter = new IntentFilter();
        filter.addAction("com.biu.common.message.DONE");
        registerReceiver(receiver, filter);
        super.onResume();
    }

    @Override
    protected void onPause() {
        unregisterReceiver(receiver);
        super.onPause();
    }

    @Override
    public void onBackPressed() { // getting back to the list of the games
        Intent intent = new Intent(CommonGameActivity.this, GameListActivity.class);
        intent.putExtra("fileName", fileName);
        startActivity(intent);
        super.onBackPressed();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_common_game);

        Bundle bundle = getIntent().getExtras();
        try {
            gameCode = bundle.getString("gameCode");
            gameName = bundle.getString("gameName");
            gameName = gameName.replace('=', ' ');
            picture = bundle.getInt("gamePicture");
            fileName = bundle.getString("fileName");
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        ImageView img = (ImageView) findViewById(R.id.pictureGroup);
        img.setImageResource(picture);
        TextView textElement = (TextView) findViewById(R.id.nameGroup);
        textElement.setText(gameName);
        gameController = new CommonGameController(this, gameCode, fileName);
        board = (GridView) findViewById(R.id.board);
        gameController.setBoardView(board);

        AnimationSet animation = new AnimationSet(false); //change to false
        animation.addAnimation(Animations.fadeInAnimation());
        //animation.addAnimation(Animations.fadeOutAnimation());
        board.setAnimation(animation);


        Button hintButton = (Button) findViewById(R.id.hintButton); // the button that send the player to a web site with the "best next move"
        hintButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("http://www.nextchessmove.com/?fen=" + gameController.createFEN() + "+0+1&flipped=false")));
            }
        });

        Button movesButton = (Button) findViewById(R.id.movesButton); // the button that show the game log (all the moves that as been played)
        movesButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(CommonGameActivity.this, MovesListActivity.class);
                intent.putExtra("gameCode", gameCode);
                intent.putExtra("fileName", fileName);
                startActivity(intent);
            }
        });

        // more animations
        if (!afterRefresh) {
            final Animation downAnim = AnimationUtils.loadAnimation(getApplicationContext(),
                    R.anim.from_down);
            final Animation upAnim = AnimationUtils.loadAnimation(getApplicationContext(),
                    R.anim.from_up);
            hintButton.startAnimation(downAnim);
            movesButton.startAnimation(downAnim);

            ImageView logo = (ImageView) findViewById(R.id.logo);
            logo.startAnimation(upAnim);
        }
        afterRefresh = false;
    }

    /**
     * refresh
     * Refreshing the screen if data has changed
     * @param code - the code of the game we need to refresh
     */
    private void refresh(String code) {
        if(code.equals(gameCode)) {
            this.finish();
            startActivity(this.getIntent());
            this.afterRefresh = true;
            MediaPlayer mediaPlayer = MediaPlayer.create(this, R.raw.hitmarker_sound);
            mediaPlayer.start();
        }
    }

    /**
     * Receiver
     * When the activity gets new data behind the scenes the receiver let the activity the ability
     * to see it and do with it what it needs.
     */
    private class Receiver extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            Bundle bundle;
            if(intent.getAction().equals("com.biu.common.message.DONE")) {
                bundle = intent.getExtras();
                refresh(bundle.getString("gameCode"));
            }
        }
    }

    /**
     * onDialogMessage
     * The dialog that appears when a pawn has gotten to end of the board.
     * @param team - the team of the pawn
     * @param position - the position the pawn in it
     */
    @Override
    public void onDialogMessage(char team, int position) {
        gameController.handleChangePawn(team, position);
    }
}