package com.example.segevlahav.project;

import android.app.Activity;
import android.content.Context;
import android.graphics.drawable.Drawable;
import android.media.MediaPlayer;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;
import java.io.File;
import java.util.ArrayList;

/**
 * GameController
 * This class is responsible of managing the game. It also responsible for the display of the game.
 */
public abstract class GameController {
    public static boolean iconsInitialized = false;
    public static Drawable[] validIcons = new Drawable[14];
    protected ArrayList<Drawable> squaresColors;
    protected Context context;
    protected GridView boardView;
    protected BoardAdapter boardAdapter;
    protected GameBoard board;
    protected int selectedNum; // the value of the piece that were selected
    protected int positionNum; // the position of the piece that were selected
    protected ArrayList<Integer> possibleMoves;
    protected char turn;
    protected String gameCode; // the game board code
    protected MediaPlayer mediaPlayer; // for the move sound
    protected String fileName; // the game details file name
    protected Statistics statistics;

    /**
     * GameController
     * @param context
     * @param gameCode - the game board code
     * @param fileName - the game details file name
     */
    public GameController(final Context context, String gameCode, String fileName) {
        this.context = context;
        this.gameCode = gameCode;
        initializeIcons();
        this.selectedNum = 0;
        this.positionNum = 0;
        this.possibleMoves = new ArrayList<Integer>();
        this.squaresColors = new ArrayList<Drawable>();
        this.turn = 'W';
        this.mediaPlayer = MediaPlayer.create(this.context, R.raw.hitmarker_sound);
        this.fileName = fileName;

        File file = new File(context.getFilesDir() + "/" + Defines.STATISTICS_FILE);
        if(file.exists()) {
            this.statistics = FileManager.getStatistics(context);
        } else {
            this.statistics = new Statistics();
        }
    }

    /**
     * checkMyTurn
     * Checks if the piece the player clicked on belongs to the team that own the turn now
     * @param pieceNum - the piece the user clicked on
     * @return true - if the piece the played clicked on belongs to the team that own the turn now.
     *         false - otherwise.
     */
    protected boolean checkMyTurn(int pieceNum) {
        if ((pieceNum >= Defines.BLACK_ROOK && pieceNum <= Defines.BLACK_PAWN && this.turn == 'B')
                || (pieceNum >= Defines.WHITE_ROOK && pieceNum <= Defines.WHITE_PAWN && this.turn == 'W')) {
            return true;
        }
        return false;
    }

    /**
     * changeTurn
     * Changing the game turn by order
     */
    protected void changeTurn() {
        if (this.turn == 'W') {
            this.turn = 'B';
        } else {
            this.turn = 'W';
        }
    }

    /**
     * checkGameState
     * Checking if there was a check/mate/draw, and changing the picture of the game state (below the
     * board) accordingly.
     */
    protected void checkGameState() {
        switch (board.calculateGameState(turn)) {
            case 'C':
                ImageView imageView = (ImageView) ((Activity) context).findViewById(R.id.gameState);
                imageView.setImageResource(R.drawable.check);
                break;
            case 'M':
                imageView = (ImageView) ((Activity) context).findViewById(R.id.gameState);
                imageView.setImageResource(R.drawable.mate);
                break;
            case 'P':
                imageView = (ImageView) ((Activity) context).findViewById(R.id.gameState);
                imageView.setImageResource(R.drawable.draw);
                break;
            case 'K':
                imageView = (ImageView) ((Activity) context).findViewById(R.id.gameState);
                imageView.setImageResource(R.drawable.empty);
                break;
            default:
                imageView = (ImageView) ((Activity) context).findViewById(R.id.gameState);
                imageView.setImageResource(R.drawable.empty);
                break;
        }
    }

    /**
     * createFEN
     * @return the FEN string that describe the current board
     */
    public String createFEN() {
        return this.board.createFEN();
    }

    /**
     * handleChangePawn
     * This function is called when the user has chose to which piece he would like to change his
     * pawn to when his pawn got to the end of the board.
     * @param type - the type of the piece the user want to change his pawn to
     * @param position - the position the pawn is in it when we need to change him
     */
    abstract public void handleChangePawn(char type, int position);

    /**
     * setBoardView
     * This function is responsible for communicate with the user. The function checks if the user can
     * make a move (if it is turn or not, if he won't be in check if he will make this move, if the
     * game is not ove and etc.)
     * @param boardView - the chess board
     */
    abstract public void setBoardView(final GridView boardView);

    /**
     * dataSetChanged
     * To notify the adapter that some data ha changed so it can show the new data on the screen.
     */
    protected void dataSetChanged() {
        if (boardAdapter != null) {
            boardAdapter.notifyDataSetChanged();
        }
    }

    /**
     * initializeIcons
     * Initialize the icons of pieces.
     */
    protected synchronized void initializeIcons() {
        if (iconsInitialized) {
            return;
        }

        Settings settings;
        File file = new File(context.getFilesDir() + "/" + Defines.SETTINGS_FILE);
        if(file.exists()) {
            settings = FileManager.getSettings(context);
        } else {
            settings = new Settings();
        }
        char black = settings.getBlackPiece();
        char white = settings.getWhitePiece();

        validIcons[GameBoard.EMPTY_PIECE] = context.getResources().getDrawable(R.drawable.empty);

        switch (black) {
            case 'b':
                validIcons[Defines.BLACK_ROOK] = context.getResources().getDrawable(R.drawable.black_rook);
                validIcons[Defines.BLACK_KNIGHT] = context.getResources().getDrawable(R.drawable.black_horse);
                validIcons[Defines.BLACK_BISHOP] = context.getResources().getDrawable(R.drawable.black_bishop);
                validIcons[Defines.BLACK_QUEEN] = context.getResources().getDrawable(R.drawable.black_queen);
                validIcons[Defines.BLACK_KING] = context.getResources().getDrawable(R.drawable.black_king);
                validIcons[Defines.BLACK_PAWN] = context.getResources().getDrawable(R.drawable.black_pawn);
                break;
            case 'k':
                validIcons[Defines.BLACK_ROOK] = context.getResources().getDrawable(R.drawable.blue_rook);
                validIcons[Defines.BLACK_KNIGHT] = context.getResources().getDrawable(R.drawable.blue_horse);
                validIcons[Defines.BLACK_BISHOP] = context.getResources().getDrawable(R.drawable.blue_bishop);
                validIcons[Defines.BLACK_QUEEN] = context.getResources().getDrawable(R.drawable.blue_queen);
                validIcons[Defines.BLACK_KING] = context.getResources().getDrawable(R.drawable.blue_king);
                validIcons[Defines.BLACK_PAWN] = context.getResources().getDrawable(R.drawable.blue_pawn);
                break;
            case 'r':
                validIcons[Defines.BLACK_ROOK] = context.getResources().getDrawable(R.drawable.red_rook);
                validIcons[Defines.BLACK_KNIGHT] = context.getResources().getDrawable(R.drawable.red_horse);
                validIcons[Defines.BLACK_BISHOP] = context.getResources().getDrawable(R.drawable.red_bishop);
                validIcons[Defines.BLACK_QUEEN] = context.getResources().getDrawable(R.drawable.red_queen);
                validIcons[Defines.BLACK_KING] = context.getResources().getDrawable(R.drawable.red_king);
                validIcons[Defines.BLACK_PAWN] = context.getResources().getDrawable(R.drawable.red_pawn);
                break;
            default:
                validIcons[Defines.BLACK_ROOK] = context.getResources().getDrawable(R.drawable.black_rook);
                validIcons[Defines.BLACK_KNIGHT] = context.getResources().getDrawable(R.drawable.black_horse);
                validIcons[Defines.BLACK_BISHOP] = context.getResources().getDrawable(R.drawable.black_bishop);
                validIcons[Defines.BLACK_QUEEN] = context.getResources().getDrawable(R.drawable.black_queen);
                validIcons[Defines.BLACK_KING] = context.getResources().getDrawable(R.drawable.black_king);
                validIcons[Defines.BLACK_PAWN] = context.getResources().getDrawable(R.drawable.black_pawn);
                break;
        }

        switch (white) {
            case 'w':
                validIcons[Defines.WHITE_ROOK] = context.getResources().getDrawable(R.drawable.white_rook);
                validIcons[Defines.WHITE_KNIGHT] = context.getResources().getDrawable(R.drawable.white_horse);
                validIcons[Defines.WHITE_BISHOP] = context.getResources().getDrawable(R.drawable.white_bishop);
                validIcons[Defines.WHITE_QUEEN] = context.getResources().getDrawable(R.drawable.white_queen);
                validIcons[Defines.WHITE_KING] = context.getResources().getDrawable(R.drawable.white_king);
                validIcons[Defines.WHITE_PAWN] = context.getResources().getDrawable(R.drawable.white_pawn);
                break;
            case 'g':
                validIcons[Defines.WHITE_ROOK] = context.getResources().getDrawable(R.drawable.green_rook);
                validIcons[Defines.WHITE_KNIGHT] = context.getResources().getDrawable(R.drawable.green_horse);
                validIcons[Defines.WHITE_BISHOP] = context.getResources().getDrawable(R.drawable.green_bishop);
                validIcons[Defines.WHITE_QUEEN] = context.getResources().getDrawable(R.drawable.green_queen);
                validIcons[Defines.WHITE_KING] = context.getResources().getDrawable(R.drawable.green_king);
                validIcons[Defines.WHITE_PAWN] = context.getResources().getDrawable(R.drawable.green_pawn);
                break;
            default:
                validIcons[Defines.WHITE_ROOK] = context.getResources().getDrawable(R.drawable.white_rook);
                validIcons[Defines.WHITE_KNIGHT] = context.getResources().getDrawable(R.drawable.white_horse);
                validIcons[Defines.WHITE_BISHOP] = context.getResources().getDrawable(R.drawable.white_bishop);
                validIcons[Defines.WHITE_QUEEN] = context.getResources().getDrawable(R.drawable.white_queen);
                validIcons[Defines.WHITE_KING] = context.getResources().getDrawable(R.drawable.white_king);
                validIcons[Defines.WHITE_PAWN] = context.getResources().getDrawable(R.drawable.white_pawn);
                break;
        }

        validIcons[GameBoard.EN_PASSANT] = context.getResources().getDrawable(R.drawable.x_pic);
        iconsInitialized = true;
    }

    /**
     * updateCell
     * Changing the picture in a specific cell in the greed view.
     * @param imageView - the image in the celll
     * @param position - the position of the cell
     */
    protected void updateCell(final ImageView imageView, final int position) {
        imageView.setImageDrawable(validIcons[board.getValue(position)]);
    }

    /**
     * sendSmsMove
     * If the manager has made a move he send sms to the other players about the move so they will
     * commit it in their game.
     * @param lastPosition - the position the piece moved from.
     * @param newPosition - the position the piece is moving to.
     * @param turn - the turn of the game.
     * @param moves - the moves that has been played so far (for synchronized).
     * @param changePawn - let the other players know if there were a pawn changing.
     */
    abstract protected void sendSmsMove(int lastPosition, int newPosition, char turn, int moves, char changePawn);

    /**
     * sendToManager
     * If the user is not the manager of the game he need to send message to the manager with the
     * play he want to do and wait fot the manager approval.
     * @param lastPosition - the position the piece moved from.
     * @param newPosition - the position the piece is moving to.
     * @param turn - the turn of the game.
     * @param moves - the moves that has been played so far (for synchronized).
     * @param changePawn - let the other players know if there were a pawn changing.
     */
    abstract protected void sendToManager(int lastPosition, int newPosition, char turn, int moves, char changePawn);

    /**
     * checkTurnMatch
     * Make the turn of the game controller and the board game turn equal.
     */
    protected void checkTurnMatch(){
        if(this.turn != board.getTurn()){
            this.turn = board.getTurn();
        }
    }

    /**
     * changeBoardFrame
     * Changing the letters and numbers around the board according to the team that the turn is it.
     * @param team - the team that this is it turn.
     */
    protected void changeBoardFrame (char team) {
        TextView a = (TextView) ((Activity) context).findViewById(R.id.a);
        TextView b = (TextView) ((Activity) context).findViewById(R.id.b);
        TextView c = (TextView) ((Activity) context).findViewById(R.id.c);
        TextView d = (TextView) ((Activity) context).findViewById(R.id.d);
        TextView e = (TextView) ((Activity) context).findViewById(R.id.e);
        TextView f = (TextView) ((Activity) context).findViewById(R.id.f);
        TextView g = (TextView) ((Activity) context).findViewById(R.id.g);
        TextView h = (TextView) ((Activity) context).findViewById(R.id.h);
        TextView one = (TextView) ((Activity) context).findViewById(R.id.one);
        TextView two = (TextView) ((Activity) context).findViewById(R.id.two);
        TextView three = (TextView) ((Activity) context).findViewById(R.id.three);
        TextView four = (TextView) ((Activity) context).findViewById(R.id.four);
        TextView five = (TextView) ((Activity) context).findViewById(R.id.five);
        TextView six = (TextView) ((Activity) context).findViewById(R.id.six);
        TextView seven = (TextView) ((Activity) context).findViewById(R.id.seven);
        TextView eight = (TextView) ((Activity) context).findViewById(R.id.eight);
        if (team == 'W') {
            a.setText("a");
            b.setText("b");
            c.setText("c");
            d.setText("d");
            e.setText("e");
            f.setText("f");
            g.setText("g");
            h.setText("h");
            one.setText("1");
            two.setText("2");
            three.setText("3");
            four.setText("4");
            five.setText("5");
            six.setText("6");
            seven.setText("7");
            eight.setText("8");
        } else {
            a.setText("h");
            b.setText("g");
            c.setText("f");
            d.setText("e");
            e.setText("d");
            f.setText("c");
            g.setText("b");
            h.setText("a");
            one.setText("8");
            two.setText("7");
            three.setText("6");
            four.setText("5");
            five.setText("4");
            six.setText("3");
            seven.setText("2");
            eight.setText("1");
        }
    }

    /**
     * BoardAdapter
     * Adapt the chess board to the grid view.
     */
    protected class BoardAdapter extends BaseAdapter {
        private char black; // black squares
        private char white; // white squares

        /**
         * BoardAdapter
         * constructor
         */
        BoardAdapter () {
            // reading from the settings file the colors of the squares.
            Settings settings;
            File file = new File(context.getFilesDir() + "/" + Defines.SETTINGS_FILE);
            if(file.exists()) {
                settings = FileManager.getSettings(context);
            } else {
                settings = new Settings();
            }
            black = settings.getBlackTile();
            white = settings.getWhiteTile();
        }

        /**
         * getCount
         * @return the size of the board
         */
        @Override
        public int getCount() {
            return GameBoard.BOARD_SIZE;
        }

        /**
         * getItem
         * @param position - the square the user clicked on in the board
         * @return the value in the square the user clicked on
         */
        @Override
        public Object getItem(final int position) {
            return board.getValue(position);
        }

        /**
         * getItemId
         * @param position - the square the user clicked on in the board
         * @return the position the user clicked on
         */
        @Override
        public long getItemId(final int position) {
            return position;
        }

        /**
         * getView
         * @param position
         * @param convertView
         * @param parent
         * @return the grid view with all the pieces and the squares
         */
        @Override
        public View getView(final int position, final View convertView, final ViewGroup parent) {
            if (convertView != null) {
                updateCell((ImageView) convertView, position);
                return convertView;
            }
            ImageView view;
            view = (ImageView) View.inflate(context, R.layout.brown, null);
            if(position % (GameBoard.BOARD_ROWS * 2) < GameBoard.BOARD_ROWS) {
                if (position % 2 == 0) {
                    switch (black) {
                        case 'b':
                            view = (ImageView) View.inflate(context, R.layout.brown, null);
                            break;
                        case 'r':
                            view = (ImageView) View.inflate(context, R.layout.red, null);
                            break;
                        case 'g':
                            view = (ImageView) View.inflate(context, R.layout.green, null);
                            break;
                        default:
                            view = (ImageView) View.inflate(context, R.layout.brown, null);
                    }
                } else {
                    switch (white) {
                        case 'w':
                            view = (ImageView) View.inflate(context, R.layout.white, null);
                            break;
                        case 'y':
                            view = (ImageView) View.inflate(context, R.layout.yellow, null);
                            break;
                        default:
                            view = (ImageView) View.inflate(context, R.layout.white, null);
                    }
                }
            }else{
                if (position % 2 == 0){
                    switch (white) {
                        case 'w':
                            view = (ImageView) View.inflate(context, R.layout.white, null);
                            break;
                        case 'y':
                            view = (ImageView) View.inflate(context, R.layout.yellow, null);
                            break;
                        default:
                            view = (ImageView) View.inflate(context, R.layout.white, null);
                    }
                }else{
                    switch (black) {
                        case 'b':
                            view = (ImageView) View.inflate(context, R.layout.brown, null);
                            break;
                        case 'r':
                            view = (ImageView) View.inflate(context, R.layout.red, null);
                            break;
                        case 'g':
                            view = (ImageView) View.inflate(context, R.layout.green, null);
                            break;
                        default:
                            view = (ImageView) View.inflate(context, R.layout.brown, null);
                    }
                }
            }

            updateCell(view, position);

            return view;
        }
    }
}
