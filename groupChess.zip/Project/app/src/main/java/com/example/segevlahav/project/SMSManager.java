package com.example.segevlahav.project;


import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.telephony.SmsMessage;
import android.util.Log;
import android.widget.Toast;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * SMSManager
 * This class responsible for all the incoming messages.
 */
public class SMSManager extends BroadcastReceiver {
    public static final String messageIdentifier = "#GroupChess#"; // the app identifier
    private final int gameCodeIndex = 2;
    private final int gameNameIndex = 3;
    private final int gamePictureIndex = 4;
    private final int createGameFeatureNumber = 5;
    private final int teamIndex = 5;
    private String TAG = SMSManager.class.getSimpleName();

    /**
     * SMSManager
     * empty constructor
     */
    public SMSManager() {}

    /**
     * sendSMS
     * sending "message" to "phoneNumber" by sms
     * @param phoneNumber - the phone number we want to send "message" to
     * @param message - the message we want to send.
     */
    public void sendSMS(String phoneNumber, String message) {
        SmsManager sms = SmsManager.getDefault();
        sms.sendTextMessage(phoneNumber, null, message, null, null);
    }

    /**
     * convertPhone
     * converting "number" from "+972..." to "05..."
     * @param number - the number we want to convert
     * @return the converted number
     */
    public static String convertPhone(String number) {
        String newNumber = "";
        newNumber = number;
        newNumber = newNumber.replace("+972", "0");
        newNumber = newNumber.replace("-", "");
        newNumber = newNumber.replace(" ", "");
        return newNumber;
    }

    /**
     * onReceive
     * when a message is arrived to the phone.
     * @param context
     * @param intent
     */
    @Override
    public void onReceive(Context context, Intent intent) {
        // Get the data (SMS data) bound to intent
        Bundle bundle = intent.getExtras();

        SmsMessage[] msgs = null;

        String str = "";

        if (bundle != null) {
            // Retrieve the SMS Messages received
            Object[] pdus = (Object[]) bundle.get("pdus");
            msgs = new SmsMessage[pdus.length];
            String messageBody = "";
            String sender = "";
            // For every SMS message received
            for (int i=0; i < msgs.length; i++) {
                // Convert Object array
                msgs[i] = SmsMessage.createFromPdu((byte[]) pdus[i]);
                // Sender's phone number
                sender = msgs[i].getOriginatingAddress();
                str += "SMS from " + sender + " : ";
                // Fetch the text message
                messageBody = msgs[i].getMessageBody().toString();
                str += messageBody;
                // Newline <img src="http://codetheory.in/wp-includes/images/smilies/simple-smile.png" alt=":-)" class="wp-smiley" style="height: 1em; max-height: 1em;">
                str += "\n";
            }

            // Display the entire SMS Message
            Log.d(TAG, str);

            // Display the new SMS Message
            //Toast.makeText(context, str, Toast.LENGTH_SHORT).show();

            // commands
            if (messageBody.startsWith(messageIdentifier)) {
                sender = convertPhone(sender);
                String[] tildaSplited = messageBody.split("~");
                String[] splitedSms = tildaSplited[0].split(" ");
                char command = splitedSms[1].toCharArray()[0];
                String code = splitedSms[gameCodeIndex];
                switch (command) {
                    case 'C': // create common game
                        if (splitedSms.length == createGameFeatureNumber) {
                            List<String> numbers = new ArrayList<String>();
                            numbers.add(sender);
                            if (!tildaSplited[1].equals(":")) {
                                String[] numbersSms = tildaSplited[1].split(":");
                                for (int i = 0; i < numbersSms.length; i++) {
                                    if(!numbersSms[i].isEmpty()) {
                                        numbers.add(numbersSms[i]);
                                    }
                                }
                            }
                            addCommonGame(context, splitedSms[gameNameIndex], code,
                                    splitedSms[gamePictureIndex], numbers, Defines.COMMON_GAME_FILE, sender);
                            FileManager.saveGameBoard(context, splitedSms[gameCodeIndex], new CommonGameBoard(false));
                            Intent broadcast = new Intent();
                            broadcast.putExtra("fileName", Defines.COMMON_GAME_FILE);
                            broadcast.setAction("com.biu.gamelist.message.DONE");
                            context.sendBroadcast(broadcast);
                        } else {
                            Toast.makeText(context, "miss field", Toast.LENGTH_SHORT).show();
                        }
                        break;
                    case 'D': // delete player from common game
                        deleteNumberFromGame(context, code, sender, Defines.COMMON_GAME_FILE);
                        Intent broadcast = new Intent();
                        broadcast.putExtra("fileName", Defines.COMMON_GAME_FILE);
                        broadcast.setAction("com.biu.gamelist.message.DONE");
                        context.sendBroadcast(broadcast);
                        break;
                    case 'M': // make a move in common game
                        int from = Integer.parseInt(splitedSms[3]);
                        int to = Integer.parseInt(splitedSms[4]);
                        String turn = splitedSms[5];
                        int moves = Integer.parseInt(splitedSms[6]);
                        char changePawn = splitedSms[7].charAt(0);
                        handleCommonMoveMessage(context, code, from, to, moves, turn, Defines.COMMON_GAME_FILE, changePawn);
                        broadcast = new Intent();
                        broadcast.putExtra("gameCode",code);
                        broadcast.setAction("com.biu.common.message.DONE");
                        context.sendBroadcast(broadcast);
                        break;
                    case 'c': // create group game
                        if (splitedSms.length == createGameFeatureNumber + 1) {
                            List<String> whiteNumbers = new ArrayList<String>();
                            List<String> blackNumbers = new ArrayList<String>();
                            whiteNumbers.add(sender);
                            String[] whiteAndBlack = tildaSplited[1].split(";");
                            if (!whiteAndBlack[0].equals(":")) {
                                String[] white = whiteAndBlack[0].split(":");
                                for (int i = 0; i < white.length; i++) {
                                    if(!white[i].isEmpty()) {
                                        whiteNumbers.add(white[i]);
                                    }
                                }
                            }
                            if (!whiteAndBlack[1].equals(":")) {
                                String[] black = whiteAndBlack[1].split(":");
                                for (int i = 0; i < black.length; i++) {
                                    if(!black[i].isEmpty()) {
                                        blackNumbers.add(black[i]);
                                    }
                                }
                            }
                            addGroupGame(context, splitedSms[gameNameIndex], splitedSms[gameCodeIndex],
                                    splitedSms[gamePictureIndex], whiteNumbers, blackNumbers, Defines.GROUP_GAME_FILE, sender);
                            GameBoard gameBoard = new GroupGameBoard(splitedSms[teamIndex].charAt(0), false);
                            FileManager.saveGameBoard(context, splitedSms[gameCodeIndex], gameBoard);
                            broadcast = new Intent();
                            broadcast.putExtra("fileName",Defines.GROUP_GAME_FILE);
                            broadcast.setAction("com.biu.gamelist.message.DONE");
                            context.sendBroadcast(broadcast);
                        } else {
                            Toast.makeText(context, "miss field", Toast.LENGTH_SHORT).show();
                        }
                        break;
                    case 'm': // make a move in group game
                        from = Integer.parseInt(splitedSms[3]);
                        to = Integer.parseInt(splitedSms[4]);
                        turn = splitedSms[5];
                        moves = Integer.parseInt(splitedSms[6]);
                        changePawn = splitedSms[7].charAt(0);
                        handleGroupMoveMessage(context, code, from, to, moves, turn, Defines.GROUP_GAME_FILE, changePawn);
                        broadcast = new Intent();
                        broadcast.putExtra("gameCode",code);
                        broadcast.setAction("com.biu.group.message.DONE");
                        context.sendBroadcast(broadcast);
                        break;
                    case 'd': // delete a player from group game
                        deleteNumberFromGame(context, code, sender, Defines.GROUP_GAME_FILE);
                        broadcast = new Intent();
                        broadcast.putExtra("fileName", Defines.GROUP_GAME_FILE);
                        broadcast.setAction("com.biu.gamelist.message.DONE");
                        context.sendBroadcast(broadcast);
                        break;
                    case 'n': // create 4D game
                        if (splitedSms.length == createGameFeatureNumber + 1) {
                            List<String> whiteNumbers = new ArrayList<String>();
                            List<String> blackNumbers = new ArrayList<String>();
                            List<String> redNumbers = new ArrayList<String>();
                            List<String> greenNumbers = new ArrayList<String>();
                            whiteNumbers.add(sender);
                            String[] wbrg = tildaSplited[1].split(";");
                            if (!wbrg[0].equals(":")) {
                                String[] white = wbrg[0].split(":");
                                for (int i = 0; i < white.length; i++) {
                                    if(!white[i].isEmpty()) {
                                        whiteNumbers.add(white[i]);
                                    }
                                }
                            }
                            if (!wbrg[1].equals(":")) {
                                String[] black = wbrg[1].split(":");
                                for (int i = 0; i < black.length; i++) {
                                    if(!black[i].isEmpty()) {
                                        blackNumbers.add(black[i]);
                                    }
                                }
                            }
                            if (!wbrg[2].equals(":")) {
                                String[] red = wbrg[2].split(":");
                                for (int i = 0; i < red.length; i++) {
                                    if(!red[i].isEmpty()) {
                                        redNumbers.add(red[i]);
                                    }
                                }
                            }
                            if (!wbrg[3].equals(":")) {
                                String[] green = wbrg[3].split(":");
                                for (int i = 0; i < green.length; i++) {
                                    if(!green[i].isEmpty()) {
                                        greenNumbers.add(green[i]);
                                    }
                                }
                            }
                            addFourDGame(context, splitedSms[gameNameIndex], splitedSms[gameCodeIndex],
                                    splitedSms[gamePictureIndex], whiteNumbers, blackNumbers,
                                    redNumbers, greenNumbers, Defines.FOUR_D_GAME_FILE, sender);
                            FourDGameBoard gameBoard = new FourDGameBoard(splitedSms[teamIndex].charAt(0), false);
                            FileManager.saveGameBoard(context, splitedSms[gameCodeIndex], gameBoard);
                            broadcast = new Intent();
                            broadcast.putExtra("fileName",Defines.FOUR_D_GAME_FILE);
                            broadcast.setAction("com.biu.gamelist.message.DONE");
                            context.sendBroadcast(broadcast);
                        } else {
                            Toast.makeText(context, "miss field", Toast.LENGTH_SHORT).show();
                        }
                        break;
                    case 'o': // make a move in 4D game
                        from = Integer.parseInt(splitedSms[3]);
                        to = Integer.parseInt(splitedSms[4]);
                        turn = splitedSms[5];
                        moves = Integer.parseInt(splitedSms[6]);
                        changePawn = splitedSms[7].charAt(0);
                        handleFourDMoveMessage(context, code, from, to, moves, turn, Defines.FOUR_D_GAME_FILE, changePawn);
                        broadcast = new Intent();
                        broadcast.putExtra("gameCode",code);
                        broadcast.setAction("com.biu.four.message.DONE");
                        context.sendBroadcast(broadcast);
                        break;
                    case 'r': // delete a player from 4D game
                        deleteNumberFromGame(context, code, sender, Defines.FOUR_D_GAME_FILE);
                        broadcast = new Intent();
                        broadcast.putExtra("fileName", Defines.FOUR_D_GAME_FILE);
                        broadcast.setAction("com.biu.gamelist.message.DONE");
                        context.sendBroadcast(broadcast);
                        break;
                    default:
                        Toast.makeText(context, "Error", Toast.LENGTH_SHORT).show();
                        break;
                }
            }
        }
    }

    /**
     * addGroupGame
     * adding new game to the group games list
     * @param context - the context
     * @param name - the game name
     * @param code - the game code
     * @param picture - the game icon
     * @param whiteNumbers - the white team phone numbers
     * @param blackNumbers - the black team phone numbers
     * @param fileName - the game details file name
     * @param manager - the manager of the game phones number
     */
    private void addGroupGame(Context context, String name, String code, String picture,
                              List<String> whiteNumbers, List<String> blackNumbers, String fileName, String manager) {
        GameDetails gameDetails = FileManager.getGameDetails(context, fileName);
        if (gameDetails == null) {
            Toast.makeText(context, "GvGName not found, let's create one", Toast.LENGTH_SHORT).show();
            gameDetails = new GameDetails();
        }
        List<String> numbers = new ArrayList<>(whiteNumbers);
        numbers.addAll(blackNumbers);
        gameDetails.addCodeAndNameAndPhoneNumbersAndPicture(code, name, numbers, Integer.parseInt(picture), manager);
        gameDetails.setCodeAndTeams(code, whiteNumbers, blackNumbers);
        gameDetails.setCodeAndNew(code, true);
        FileManager.saveGameDetails(context, gameDetails, fileName);
    }

    /**
     * addFourDGame
     * adding new game to the 4D games list
     * @param context - the context
     * @param name - the game name
     * @param code - the game code
     * @param picture - the game icon
     * @param whiteNumbers - the white team phone numbers
     * @param blackNumbers - the black team phone numbers
     * @param redNumbers - the red team phone numbers
     * @param greenNumbers - the green team phone numbers
     * @param fileName - the game details file name
     * @param manager - the manager of the game phones number
     */
    private void addFourDGame(Context context, String name, String code, String picture,
                              List<String> whiteNumbers, List<String> blackNumbers,
                              List<String> redNumbers, List<String> greenNumbers,
                              String fileName, String manager) {
        GameDetails gameDetails = FileManager.getGameDetails(context, fileName);
        if (gameDetails == null) {
            Toast.makeText(context, "4DName not found, let's create one", Toast.LENGTH_SHORT).show();
            gameDetails = new GameDetails();
        }
        List<String> numbers = new ArrayList<>(whiteNumbers);
        numbers.addAll(blackNumbers);
        numbers.addAll(redNumbers);
        numbers.addAll(greenNumbers);
        gameDetails.addCodeAndNameAndPhoneNumbersAndPicture(code, name, numbers, Integer.parseInt(picture), manager);
        gameDetails.setCodeAndTeams(code, whiteNumbers, blackNumbers, redNumbers, greenNumbers);
        gameDetails.setCodeAndNew(code, true);
        FileManager.saveGameDetails(context, gameDetails, fileName);
    }

    /**
     * addCommthe manager of the game phones number
     * @param context - the context
     * @param name - the game name
     * @param code - the game code
     * @param picture - the game icon
     * @param numbers - all the players numbers
     * @param fileName - the game details file name
     * @param manager - the manager of the game phones number
     */
    private void addCommonGame(Context context, String name, String code, String picture, List<String> numbers, String fileName, String manager) {
        GameDetails gameDetails = FileManager.getGameDetails(context, fileName);
        if (gameDetails == null) {
            Toast.makeText(context, "GamesName not found, let's create one", Toast.LENGTH_SHORT).show();
            gameDetails = new GameDetails();
        }
        gameDetails.addCodeAndNameAndPhoneNumbersAndPicture(code, name, numbers, Integer.parseInt(picture), manager);
        gameDetails.setCodeAndNew(code, true);
        FileManager.saveGameDetails(context, gameDetails, fileName);
    }

    /**
     * deleteNumberFromGame
     * @param context - the context
     * @param code - the game code
     * @param number - the number of the player we want to remove from the game
     * @param fileName - the game details file name
     */
    private void deleteNumberFromGame(Context context, String code, String number, String fileName) {
        GameDetails gameDetails = FileManager.getGameDetails(context, fileName);
        if (gameDetails == null) {
            Toast.makeText(context, "GamesName not found, let's create one", Toast.LENGTH_SHORT).show();
            gameDetails = new GameDetails();
        }
        if (gameDetails.isExist(code)) {
            if (gameDetails.getManager(code).equals(number)) {
                gameDetails.deleteGame(code);
            } else {
                gameDetails.removeNumber(code, number, fileName);
            }
            FileManager.saveGameDetails(context, gameDetails, fileName);
        }
    }

    /**
     * makeAMoveCommon
     * making a move in the common game
     * @param context - the context
     * @param code - the game code
     * @param from - the last position of the piece
     * @param to - the new position of the piece
     * @param changePawn - char that tell us if there was a pawn changing
     * @param turn - the game turn
     */
    private void makeAMoveCommon(Context context, String code, int from, int to, char changePawn, char turn) {
        GameBoard gameBoard = FileManager.getGameBoard(context, code);
        if (gameBoard != null) {
            int value = gameBoard.getValue(from);
            gameBoard.setValue(value, to, from);
            gameBoard.addMoveToList(value, to, from);
            gameBoard.checkEnPassant(value, to, from);
            if (gameBoard.needToChangePawn(to, value)) {
                gameBoard.changePawn(to, changePawn);
            }
            gameBoard.turnHasChanged();
            gameBoard.calculateGameState(turn);
            if (gameBoard.getGameState() == 'M' || gameBoard.getGameState() == 'P') {
                Statistics statistics;
                File file = new File(context + "/" + Defines.STATISTICS_FILE);
                if(file.exists()) {
                    statistics = FileManager.getStatistics(context);
                } else {
                    statistics = new Statistics();
                }
                statistics.getCommonGames();
            }
            gameBoard.setWaitingForPermission(false);
            FileManager.saveGameBoard(context, code, gameBoard);
        }
    }

    /**
     * makeAMoveGroup
     * making a move in the group game
     * @param context - the context
     * @param code - the game code
     * @param from - the last position of the piece
     * @param to - the new position of the piece
     * @param changePawn - char that tell us if there was a pawn changing
     * @param turn - the game turn
     */
    private void makeAMoveGroup(Context context, String code, int from, int to, char changePawn, char turn) {
        GameBoard gameBoard = FileManager.getGameBoard(context, code);
        if (gameBoard != null) {
            int value = gameBoard.getValue(from);
            gameBoard.setValue(value, to, from);
            gameBoard.addMoveToList(value, to, from);
            gameBoard.checkEnPassant(value, to, from);
            if (gameBoard.needToChangePawn(to, value)) {
                gameBoard.changePawn(to, changePawn);
            }
            gameBoard.turnHasChanged();
            gameBoard.calculateGameState(gameBoard.getRivalTeam(turn));
            switch (gameBoard.getGameState()) {
                case 'M':
                    Statistics statistics;
                    File file = new File(context.getFilesDir() + "/" + Defines.STATISTICS_FILE);
                    if(file.exists()) {
                        statistics = FileManager.getStatistics(context);
                    } else {
                        statistics = new Statistics();
                    }
                    if (gameBoard.turn == ((GroupGameBoard)gameBoard).getMyTeam()) {
                        statistics.incrementGroupLose();
                    } else {
                        statistics.incrementGroupWin();
                    }
                    FileManager.saveStatistics(context, statistics);
                    break;
                case 'P':
                    file = new File(context.getFilesDir() + "/" + Defines.STATISTICS_FILE);
                    if(file.exists()) {
                        statistics = FileManager.getStatistics(context);
                    } else {
                        statistics = new Statistics();
                    }
                    statistics.incrementGroupDraw();
                    FileManager.saveStatistics(context, statistics);
                    break;
                default:
                    break;
            }
            gameBoard.setWaitingForPermission(false);
            FileManager.saveGameBoard(context, code, gameBoard);
        }
    }

    /**
     * makeAMoveFourD
     * @param context - the context
     * @param code - the game code
     * @param from - the last position of the piece
     * @param to - the new position of the piece
     * @param changePawn - char that tell us if there was a pawn changing
\     */
    private void makeAMoveFourD(Context context, String code, int from, int to, char changePawn, char turn) {
        FourDGameBoard gameBoard = (FourDGameBoard) FileManager.getGameBoard(context, code);
        if (gameBoard != null) {
            int value = gameBoard.getValue(from);
            gameBoard.setValue(value, to, from);
            gameBoard.addMoveToList(value, to, from);
            gameBoard.checkEnPassant(value, to, from);
            if (gameBoard.needToChangePawn(to, value)) {
                gameBoard.changePawn(to, changePawn);
            }
            gameBoard.turnHasChanged();
            gameBoard.calculateGameState(gameBoard.getNextTeam(turn));
            switch (gameBoard.getGameState()) {
                case 'M':
                    Statistics statistics;
                    File file = new File(context.getFilesDir() + "/" + Defines.STATISTICS_FILE);
                    if(file.exists()) {
                        statistics = FileManager.getStatistics(context);
                    } else {
                        statistics = new Statistics();
                    }
                    if (gameBoard.turn == (gameBoard).getMyTeam()) {
                        statistics.incrementFourDLose();
                    } else {
                        statistics.incrementFourDWin();
                    }
                    FileManager.saveStatistics(context, statistics);
                    break;
                case 'P':
                    file = new File(context.getFilesDir() + "/" + Defines.STATISTICS_FILE);
                    if(file.exists()) {
                        statistics = FileManager.getStatistics(context);
                    } else {
                        statistics = new Statistics();
                    }
                    statistics.incrementFourDDraw();
                    FileManager.saveStatistics(context, statistics);
                    break;
                default:
                    break;
            }
            gameBoard.setWaitingForPermission(false);
            FileManager.saveGameBoard(context, code, gameBoard);
        }
    }

    /**
     * handleCommonMoveMessage
     * handle making a move message in the common game board
     * @param context - the context
     * @param code - the game code
     * @param from - the last position of the piece
     * @param to - the new position of the piece
     * @param moves - the number of moves that has been played in the game
     * @param turn - the game turn
     * @param fileName - the game details file name
     * @param changePawn - char that tell us if there was a pawn changing
     */
    private void handleCommonMoveMessage(Context context, String code, int from, int to,
                                         int moves, String turn, String fileName, char changePawn) {
        GameBoard gameBoard = FileManager.getGameBoard(context, code);
        if (gameBoard != null) {
            if (gameBoard.getMoves() == moves) {
                if (gameBoard.getIsManager()) {
                    GameDetails gameDetails = FileManager.getGameDetails(context, fileName);
                    List<String> numbers = gameDetails.getPhoneNumbersByCode(code);
                    String smsMessage = SMSManager.messageIdentifier + " M " + code;
                    smsMessage += Defines.SPACE + Integer.toString(from);
                    smsMessage += Defines.SPACE + Integer.toString(to);
                    smsMessage += Defines.SPACE + turn;
                    smsMessage += Defines.SPACE + Integer.toString(moves);
                    smsMessage += Defines.SPACE + changePawn;
                    smsMessage += Defines.TILDA;
                    for (String smsNum : numbers) {
                        sendSMS(smsNum, smsMessage);
                    }
                }
                makeAMoveCommon(context, code, from, to, changePawn, turn.charAt(0));
            } else if (gameBoard.getMoves() < moves) {
                if (!gameBoard.getIsManager()) {
                    GameDetails gameDetails = FileManager.getGameDetails(context, fileName);
                    smsDeleteGame(code, gameDetails.getPhoneNumbersByCode(code), fileName);
                    gameDetails.deleteGame(code);
                    FileManager.saveGameDetails(context, gameDetails, fileName);
                }
            }
        }
    }

    /**
     * handleGroupMoveMessage
     * handle making a move message in the group game board
     * @param context - the context
     * @param code - the game code
     * @param from - the last position of the piece
     * @param to - the new position of the piece
     * @param moves - the number of moves that has been played in the game
     * @param turn - the game turn
     * @param fileName - the game details file name
     * @param changePawn - char that tell us if there was a pawn changing
     */
    private void handleGroupMoveMessage(Context context, String code, int from, int to,
                                        int moves, String turn, String fileName, char changePawn) {
        GameBoard gameBoard = FileManager.getGameBoard(context, code);
        if (gameBoard != null) {
            if (gameBoard.getMoves() == moves) {
                if (gameBoard.getIsManager()) {
                    GameDetails gameDetails = FileManager.getGameDetails(context, fileName);
                    List<String> whiteNumbers = gameDetails.getTeamByCode(code, 'W');
                    List<String> blackNumbers = gameDetails.getTeamByCode(code, 'B');
                    String whiteMessage = SMSManager.messageIdentifier + " m " + code;
                    String blackMessage = SMSManager.messageIdentifier + " m " + code;
                    if (turn.equals("B")) {
                        if (((GroupGameBoard)gameBoard).getMyTeam() == 'B') {
                            blackMessage += Defines.SPACE + Integer.toString(from);
                            blackMessage += Defines.SPACE + Integer.toString(to);
                            whiteMessage += Defines.SPACE + Integer.toString((GameBoard.BOARD_SIZE - 1) - from);
                            whiteMessage += Defines.SPACE + Integer.toString((GameBoard.BOARD_SIZE - 1) - to);
                        } else {
                            whiteMessage += Defines.SPACE + Integer.toString(from);
                            whiteMessage += Defines.SPACE + Integer.toString(to);
                            blackMessage += Defines.SPACE + Integer.toString((GameBoard.BOARD_SIZE - 1) - from);
                            blackMessage += Defines.SPACE + Integer.toString((GameBoard.BOARD_SIZE - 1) - to);
                        }
                    } else {
                        if (((GroupGameBoard)gameBoard).getMyTeam() == 'W') {
                            whiteMessage += Defines.SPACE + Integer.toString(from);
                            whiteMessage += Defines.SPACE + Integer.toString(to);
                            blackMessage += Defines.SPACE + Integer.toString((GameBoard.BOARD_SIZE - 1) - from);
                            blackMessage += Defines.SPACE + Integer.toString((GameBoard.BOARD_SIZE - 1) - to);
                        } else {
                            blackMessage += Defines.SPACE + Integer.toString(from);
                            blackMessage += Defines.SPACE + Integer.toString(to);
                            whiteMessage += Defines.SPACE + Integer.toString((GameBoard.BOARD_SIZE - 1) - from);
                            whiteMessage += Defines.SPACE + Integer.toString((GameBoard.BOARD_SIZE - 1) - to);
                        }
                    }
                    whiteMessage += Defines.SPACE + turn;
                    blackMessage += Defines.SPACE + turn;
                    whiteMessage += Defines.SPACE + Integer.toString(moves);
                    blackMessage += Defines.SPACE + Integer.toString(moves);
                    whiteMessage += Defines.SPACE + changePawn;
                    blackMessage += Defines.SPACE + changePawn;
                    whiteMessage += Defines.TILDA;
                    blackMessage += Defines.TILDA;
                    for (String smsNum : whiteNumbers) {
                        sendSMS(smsNum, whiteMessage);
                    }
                    for (String smsNum : blackNumbers) {
                        sendSMS(smsNum, blackMessage);
                    }
                }
                makeAMoveGroup(context, code, from, to, changePawn, turn.charAt(0));
            } else if (gameBoard.getMoves() < moves) {
                if (!gameBoard.getIsManager()) {
                    GameDetails gameDetails = FileManager.getGameDetails(context, fileName);
                    smsDeleteGame(code, gameDetails.getPhoneNumbersByCode(code), fileName);
                    gameDetails.deleteGame(code);
                    FileManager.saveGameDetails(context, gameDetails, fileName);
                }
            }
        }
    }

    /**
     * handleFourDMoveMessage
     * handle making a move message in the 4D game board
     * @param context - the context
     * @param code - the game code
     * @param from - the last position of the piece
     * @param to - the new position of the piece
     * @param moves - the number of moves that has been played in the game
     * @param turn - the game turn
     * @param fileName - the game details file name
     * @param changePawn - char that tell us if there was a pawn changing
     */
    private void handleFourDMoveMessage(Context context, String code, int from, int to,
                                        int moves, String turn, String fileName, char changePawn) {
        FourDGameBoard gameBoard = (FourDGameBoard) FileManager.getGameBoard(context, code);
        if (gameBoard != null) {
            if (gameBoard.getMoves() == moves) {
                if (gameBoard.getIsManager()) {
                    GameDetails gameDetails = FileManager.getGameDetails(context, fileName);
                    List<String> whiteNumbers = gameDetails.getTeamByCode(code, 'W');
                    List<String> blackNumbers = gameDetails.getTeamByCode(code, 'B');
                    List<String> redNumbers = gameDetails.getTeamByCode(code, 'R');
                    List<String> greenNumbers = gameDetails.getTeamByCode(code, 'G');

                    String whiteMessage = SMSManager.messageIdentifier + " o " + code;
                    String blackMessage = SMSManager.messageIdentifier + " o " + code;
                    String redMessage = SMSManager.messageIdentifier + " o " + code;
                    String greenMessage = SMSManager.messageIdentifier + " o " + code;
                    int x = from / FourDGameBoard.BOARD_ROWS;
                    int y = from % FourDGameBoard.BOARD_ROWS;
                    int r = to / FourDGameBoard.BOARD_ROWS;
                    int z = to % FourDGameBoard.BOARD_ROWS;
                    switch (turn.toCharArray()[0]) {
                        case 'W':
                            whiteMessage += Defines.SPACE + Integer.toString(from);
                            whiteMessage += Defines.SPACE + Integer.toString(to);
                            blackMessage += Defines.SPACE + Integer.toString((FourDGameBoard.BOARD_SIZE - 1) - from);
                            blackMessage += Defines.SPACE + Integer.toString((FourDGameBoard.BOARD_SIZE - 1) - to);
                            redMessage += Defines.SPACE + Integer.toString(((FourDGameBoard.BOARD_ROWS-y-1)*FourDGameBoard.BOARD_ROWS+x));
                            redMessage += Defines.SPACE + Integer.toString(((FourDGameBoard.BOARD_ROWS-z-1)*FourDGameBoard.BOARD_ROWS+r));
                            greenMessage += Defines.SPACE + Integer.toString(((y*FourDGameBoard.BOARD_ROWS)+FourDGameBoard.BOARD_ROWS-1-x));
                            greenMessage += Defines.SPACE + Integer.toString(((z*FourDGameBoard.BOARD_ROWS)+FourDGameBoard.BOARD_ROWS-1-r));
                            break;
                        case 'B':
                            whiteMessage += Defines.SPACE + Integer.toString(from);
                            whiteMessage += Defines.SPACE + Integer.toString(to);
                            blackMessage += Defines.SPACE + Integer.toString((FourDGameBoard.BOARD_SIZE - 1) - from);
                            blackMessage += Defines.SPACE + Integer.toString((FourDGameBoard.BOARD_SIZE - 1) - to);
                            redMessage += Defines.SPACE + Integer.toString(((FourDGameBoard.BOARD_ROWS-1-y)*FourDGameBoard.BOARD_ROWS+x));
                            redMessage += Defines.SPACE + Integer.toString(((FourDGameBoard.BOARD_ROWS-1-z)*FourDGameBoard.BOARD_ROWS+r));
                            greenMessage += Defines.SPACE + Integer.toString(((y*FourDGameBoard.BOARD_ROWS)+FourDGameBoard.BOARD_ROWS-x-1));
                            greenMessage += Defines.SPACE + Integer.toString(((z*FourDGameBoard.BOARD_ROWS)+FourDGameBoard.BOARD_ROWS-r-1));
                            break;
                        case 'R':
                            whiteMessage += Defines.SPACE + Integer.toString(from);
                            whiteMessage += Defines.SPACE + Integer.toString(to);
                            blackMessage += Defines.SPACE + Integer.toString((FourDGameBoard.BOARD_SIZE - 1) - from);
                            blackMessage += Defines.SPACE + Integer.toString((FourDGameBoard.BOARD_SIZE - 1) - to);
                            redMessage += Defines.SPACE + Integer.toString(((FourDGameBoard.BOARD_ROWS-1-y)*FourDGameBoard.BOARD_ROWS+x));
                            redMessage += Defines.SPACE + Integer.toString(((FourDGameBoard.BOARD_ROWS-1-z)*FourDGameBoard.BOARD_ROWS+r));
                            greenMessage += Defines.SPACE + Integer.toString(((y*FourDGameBoard.BOARD_ROWS)+FourDGameBoard.BOARD_ROWS-x-1));
                            greenMessage += Defines.SPACE + Integer.toString(((z*FourDGameBoard.BOARD_ROWS)+FourDGameBoard.BOARD_ROWS-r-1));
                            break;
                        case 'G':
                            whiteMessage += Defines.SPACE + Integer.toString(from);
                            whiteMessage += Defines.SPACE + Integer.toString(to);
                            blackMessage += Defines.SPACE + Integer.toString((FourDGameBoard.BOARD_SIZE - 1) - from);
                            blackMessage += Defines.SPACE + Integer.toString((FourDGameBoard.BOARD_SIZE - 1) - to);
                            redMessage += Defines.SPACE + Integer.toString(((FourDGameBoard.BOARD_ROWS-1-y)*FourDGameBoard.BOARD_ROWS+x));
                            redMessage += Defines.SPACE + Integer.toString(((FourDGameBoard.BOARD_ROWS-1-z)*FourDGameBoard.BOARD_ROWS+r));
                            greenMessage += Defines.SPACE + Integer.toString(((y*FourDGameBoard.BOARD_ROWS)+FourDGameBoard.BOARD_ROWS-1-x));
                            greenMessage += Defines.SPACE + Integer.toString(((z*FourDGameBoard.BOARD_ROWS)+FourDGameBoard.BOARD_ROWS-1-r));
                            break;
                    }
                    whiteMessage += Defines.SPACE + turn;
                    blackMessage += Defines.SPACE + turn;
                    redMessage += Defines.SPACE + turn;
                    greenMessage += Defines.SPACE + turn;
                    whiteMessage += Defines.SPACE + Integer.toString(moves);
                    blackMessage += Defines.SPACE + Integer.toString(moves);
                    redMessage += Defines.SPACE + Integer.toString(moves);
                    greenMessage += Defines.SPACE + Integer.toString(moves);
                    whiteMessage += Defines.SPACE + changePawn;
                    blackMessage += Defines.SPACE + changePawn;
                    redMessage += Defines.SPACE + changePawn;
                    greenMessage += Defines.SPACE + changePawn;
                    whiteMessage += Defines.TILDA;
                    blackMessage += Defines.TILDA;
                    redMessage += Defines.TILDA;
                    greenMessage += Defines.TILDA;
                    for (String smsNum : whiteNumbers) {
                        sendSMS(smsNum, whiteMessage);
                    }
                    for (String smsNum : blackNumbers) {
                        sendSMS(smsNum, blackMessage);
                    }
                    for (String smsNum : redNumbers) {
                        sendSMS(smsNum, redMessage);
                    }
                    for (String smsNum : greenNumbers) {
                        sendSMS(smsNum, greenMessage);
                    }
                }
                makeAMoveFourD(context, code, from, to, changePawn, turn.charAt(0));
            } else if (gameBoard.getMoves() < moves) {
                if (!gameBoard.getIsManager()) {
                    GameDetails gameDetails = FileManager.getGameDetails(context, fileName);
                    smsDeleteGame(code, gameDetails.getPhoneNumbersByCode(code), fileName);
                    gameDetails.deleteGame(code);
                    FileManager.saveGameDetails(context, gameDetails, fileName);
                }
            }
        }
    }

    /**
     * smsDeleteGame
     * sending sms message of deleting a game if the user has left the game
     * @param code
     * @param numbers
     * @param fileName
     */
    private void smsDeleteGame(String code, List<String> numbers, String fileName) {
        String smsMessage = "";
        if (fileName.equals(Defines.COMMON_GAME_FILE)) {
            smsMessage = SMSManager.messageIdentifier + " D " + code + Defines.TILDA;
        } else if (fileName.equals(Defines.GROUP_GAME_FILE)) {
            smsMessage = SMSManager.messageIdentifier + " d " + code + Defines.TILDA;
        } else if(fileName.equals(Defines.FOUR_D_GAME_FILE)) {
            smsMessage = SMSManager.messageIdentifier + " r " + code + Defines.TILDA;
        }
        for (String smsNum : numbers) {
            sendSMS(smsNum, smsMessage);
        }
    }
}
