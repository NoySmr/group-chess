package com.example.segevlahav.project;

import android.content.Context;
import android.util.Log;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Random;

/**
 * FileManager
 * This class is responsible for reading and writing objects to the phone memory so we can save
 * the user games.
 */
public class FileManager {

    /**
     * saveGameBoard
     * Writing the game board to the phone memory.
     * @param context
     * @param code - the code of the game
     * @param gameBoard - the specific game board we want to save
     */
    public static void saveGameBoard(Context context, String code, GameBoard gameBoard) {
        try
        {
            FileOutputStream fos = context.openFileOutput(code, Context.MODE_PRIVATE);
            ObjectOutputStream os = new ObjectOutputStream(fos);
            os.writeObject(gameBoard);
            os.close();
            fos.close();
        }
        catch(Exception ex)
        {
            Log.v("Game Board", ex.getMessage());
            ex.printStackTrace();
        }
    }

    /**
     * getGameBoard
     * Reading the game board from the phone memory.
     * @param context
     * @param code - the code of the game we want to read from the phone memory.
     * @return the game board of this code
     */
    public static GameBoard getGameBoard(Context context, String code) {
        try {
            FileInputStream fis = context.openFileInput(code);
            ObjectInputStream is = new ObjectInputStream(fis);
            Object readObject = is.readObject();
            is.close();

            if(readObject != null && readObject instanceof GameBoard) {
                return (GameBoard) readObject;
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

        return null;
    }

    /**
     * saveGameDetails
     * Saving the game details file of a specific kind of game (common/group/4D)
     * @param context
     * @param gameDetails - the game details we want to save
     * @param fileName - the name of the file we want to write the game details to
     */
    public static void saveGameDetails(Context context, GameDetails gameDetails, String fileName) {
        try
        {
            FileOutputStream fos = context.openFileOutput(fileName, Context.MODE_PRIVATE);
            ObjectOutputStream os = new ObjectOutputStream(fos);
            os.writeObject(gameDetails);
            os.close();
            fos.close();
        }
        catch(Exception ex)
        {
            Log.v("Game Details", ex.getMessage());
            ex.printStackTrace();
        }
    }

    /**
     * getGameDetails
     * Reading the game details from the phone memory
     * @param context
     * @param fileName - the name of the game details file
     * @return the game details with this file name
     */
    public static GameDetails getGameDetails(Context context, String fileName){
        GameDetails details = null;
        File file = new File(context.getFilesDir() + "/" + fileName);
        if(file.exists()) {
            try {
                FileInputStream fis = context.openFileInput(fileName);
                ObjectInputStream is = new ObjectInputStream(fis);
                Object readObject = is.readObject();
                is.close();

                if(readObject != null && readObject instanceof GameDetails) {
                    details = (GameDetails) readObject;
                }
            } catch (IOException e) {
                e.printStackTrace();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }
        }
        return details;
    }

    /**
     * saveSettings
     * Writing the settings file to the phone memory to save the user settings.
     * @param context
     * @param settings - the settings
     */
    public static void saveSettings(Context context, Settings settings) {
        try
        {
            FileOutputStream fos = context.openFileOutput(Defines.SETTINGS_FILE, Context.MODE_PRIVATE);
            ObjectOutputStream os = new ObjectOutputStream(fos);
            os.writeObject(settings);
            os.close();
            fos.close();
        }
        catch(Exception ex)
        {
            Log.v("Settings", ex.getMessage());
            ex.printStackTrace();
        }
    }

    /**
     * getSettings
     * Reading the settings file from the phone memory
     * @param context
     * @return the settings object
     */
    public static Settings getSettings(Context context) {
        try {
            FileInputStream fis = context.openFileInput(Defines.SETTINGS_FILE);
            ObjectInputStream is = new ObjectInputStream(fis);
            Object readObject = is.readObject();
            is.close();

            if(readObject != null && readObject instanceof Settings) {
                return (Settings) readObject;
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * saveStatistics
     * Writing the user statistics to the phone memory
     * @param context
     * @param statistics - the user games statistics
     */
    public static void saveStatistics(Context context, Statistics statistics) {
        try
        {
            FileOutputStream fos = context.openFileOutput(Defines.STATISTICS_FILE, Context.MODE_PRIVATE);
            ObjectOutputStream os = new ObjectOutputStream(fos);
            os.writeObject(statistics);
            os.close();
            fos.close();
        }
        catch(Exception ex)
        {
            Log.v("Statistics", ex.getMessage());
            ex.printStackTrace();
        }
    }

    /**
     * getStatistics
     * Reading the user games statistics from the phone memory
     * @param context
     * @return the user games statistics
     */
    public static Statistics getStatistics(Context context) {
        try {
            FileInputStream fis = context.openFileInput(Defines.STATISTICS_FILE);
            ObjectInputStream is = new ObjectInputStream(fis);
            Object readObject = is.readObject();
            is.close();

            if(readObject != null && readObject instanceof Statistics) {
                return (Statistics) readObject;
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * createId
     * Creating id for the game boards so each one will have his own file
     * @return a new random id
     */
    public static String createId() {
        Random rand = new Random();
        int  n = rand.nextInt(900) + 100;
        String s = Character.toString((char) (rand.nextInt(26) + 65));
        String e = Character.toString((char) (rand.nextInt(26) + 97));
        return s + Integer.toString(n) + e;
    }
}
