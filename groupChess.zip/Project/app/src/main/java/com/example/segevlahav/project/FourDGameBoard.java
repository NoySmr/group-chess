package com.example.segevlahav.project;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 * FourDGameBoard
 * This class contains all the information about the state of the 4D game board. The pieces positions,
 * the team that the turn is its, the number of the moves that has been played, the manager of the game
 * and etc.
 */
public class FourDGameBoard extends GameBoard implements Serializable {

    private static final long serialVersionUID = 3L;
    public static final int BOARD_ROWS = 14; // 14x14 board
    public static final int BOARD_SIZE = BOARD_ROWS * BOARD_ROWS; // 14x14 board
    public static final int EMPTY_PIECE = 0;
    public static final int MIN_VALUE = 1;
    public static final int MAX_VALUE = 24;
    public static final int EN_PASSANT = 25;
    public static final int BAD_PLACE = 26;
    private static final int [] SEED_GRID = { // The board of the 4D game
            BAD_PLACE,BAD_PLACE,BAD_PLACE,Defines.BLACK_ROOK,Defines.BLACK_KNIGHT,Defines.BLACK_BISHOP,Defines.BLACK_QUEEN,Defines.BLACK_KING,Defines.BLACK_BISHOP,Defines.BLACK_KNIGHT,Defines.BLACK_ROOK,BAD_PLACE,BAD_PLACE,BAD_PLACE,
            BAD_PLACE,BAD_PLACE,BAD_PLACE,Defines.BLACK_PAWN,Defines.BLACK_PAWN,Defines.BLACK_PAWN,Defines.BLACK_PAWN,Defines.BLACK_PAWN,Defines.BLACK_PAWN,Defines.BLACK_PAWN,Defines.BLACK_PAWN,BAD_PLACE,BAD_PLACE,BAD_PLACE,
            BAD_PLACE,BAD_PLACE,BAD_PLACE,EMPTY_PIECE,EMPTY_PIECE,EMPTY_PIECE,EMPTY_PIECE,EMPTY_PIECE,EMPTY_PIECE,EMPTY_PIECE,EMPTY_PIECE,BAD_PLACE,BAD_PLACE,BAD_PLACE,
            Defines.RED_ROOK,Defines.RED_PAWN,EMPTY_PIECE,EMPTY_PIECE,EMPTY_PIECE,EMPTY_PIECE,EMPTY_PIECE,EMPTY_PIECE,EMPTY_PIECE,EMPTY_PIECE,EMPTY_PIECE,EMPTY_PIECE,Defines.GREEN_PAWN,Defines.GREEN_ROOK,
            Defines.RED_KNIGHT,Defines.RED_PAWN,EMPTY_PIECE,EMPTY_PIECE,EMPTY_PIECE,EMPTY_PIECE,EMPTY_PIECE,EMPTY_PIECE,EMPTY_PIECE,EMPTY_PIECE,EMPTY_PIECE,EMPTY_PIECE,Defines.GREEN_PAWN,Defines.GREEN_KNIGHT,
            Defines.RED_BISHOP,Defines.RED_PAWN,EMPTY_PIECE,EMPTY_PIECE,EMPTY_PIECE,EMPTY_PIECE,EMPTY_PIECE,EMPTY_PIECE,EMPTY_PIECE,EMPTY_PIECE,EMPTY_PIECE,EMPTY_PIECE,Defines.GREEN_PAWN,Defines.GREEN_BISHOP,
            Defines.RED_QUEEN,Defines.RED_PAWN,EMPTY_PIECE,EMPTY_PIECE,EMPTY_PIECE,EMPTY_PIECE,EMPTY_PIECE,EMPTY_PIECE,EMPTY_PIECE,EMPTY_PIECE,EMPTY_PIECE,EMPTY_PIECE,Defines.GREEN_PAWN,Defines.GREEN_KING,
            Defines.RED_KING,Defines.RED_PAWN,EMPTY_PIECE,EMPTY_PIECE,EMPTY_PIECE,EMPTY_PIECE,EMPTY_PIECE,EMPTY_PIECE,EMPTY_PIECE,EMPTY_PIECE,EMPTY_PIECE,EMPTY_PIECE,Defines.GREEN_PAWN,Defines.GREEN_QUEEN,
            Defines.RED_BISHOP,Defines.RED_PAWN,EMPTY_PIECE,EMPTY_PIECE,EMPTY_PIECE,EMPTY_PIECE,EMPTY_PIECE,EMPTY_PIECE,EMPTY_PIECE,EMPTY_PIECE,EMPTY_PIECE,EMPTY_PIECE,Defines.GREEN_PAWN,Defines.GREEN_BISHOP,
            Defines.RED_KNIGHT,Defines.RED_PAWN,EMPTY_PIECE,EMPTY_PIECE,EMPTY_PIECE,EMPTY_PIECE,EMPTY_PIECE,EMPTY_PIECE,EMPTY_PIECE,EMPTY_PIECE,EMPTY_PIECE,EMPTY_PIECE,Defines.GREEN_PAWN,Defines.GREEN_KNIGHT,
            Defines.RED_ROOK,Defines.RED_PAWN,EMPTY_PIECE,EMPTY_PIECE,EMPTY_PIECE,EMPTY_PIECE,EMPTY_PIECE,EMPTY_PIECE,EMPTY_PIECE,EMPTY_PIECE,EMPTY_PIECE,EMPTY_PIECE,Defines.GREEN_PAWN,Defines.GREEN_ROOK,
            BAD_PLACE,BAD_PLACE,BAD_PLACE,EMPTY_PIECE,EMPTY_PIECE,EMPTY_PIECE,EMPTY_PIECE,EMPTY_PIECE,EMPTY_PIECE,EMPTY_PIECE,EMPTY_PIECE,BAD_PLACE,BAD_PLACE,BAD_PLACE,
            BAD_PLACE,BAD_PLACE,BAD_PLACE,Defines.WHITE_PAWN,Defines.WHITE_PAWN,Defines.WHITE_PAWN,Defines.WHITE_PAWN,Defines.WHITE_PAWN,Defines.WHITE_PAWN,Defines.WHITE_PAWN,Defines.WHITE_PAWN,BAD_PLACE,BAD_PLACE,BAD_PLACE,
            BAD_PLACE,BAD_PLACE,BAD_PLACE,Defines.WHITE_ROOK,Defines.WHITE_KNIGHT,Defines.WHITE_BISHOP,Defines.WHITE_KING,Defines.WHITE_QUEEN,Defines.WHITE_BISHOP,Defines.WHITE_KNIGHT,Defines.WHITE_ROOK,BAD_PLACE,BAD_PLACE,BAD_PLACE
    };
    private int[] board = new int[BOARD_SIZE];
    private Piece[][] pieceBoard = new Piece[MAX_VALUE][];
    private char myTeam;

    /**
     * FourDGameBoard
     * constructor
     * @param isManger - if the user is waiting to message from the manager
     */
    public FourDGameBoard(boolean isManger) {
        super(isManger);
        this.board = new int[BOARD_SIZE];
        System.arraycopy(SEED_GRID, 0, board, 0, BOARD_SIZE);
        this.initializePieceBoard();
        myTeam = 'W';
    }

    /**
     * FourDGameBoard
     * constructor
     * @param team - the team of the user
     * @param isManger - if the user is waiting to message from the manager
     */
    public FourDGameBoard(char team, boolean isManger){
        super(isManger);
        this.board = new int[BOARD_SIZE];
        System.arraycopy(SEED_GRID, 0, board, 0, BOARD_SIZE);
        this.initializePieceBoard();
        this.myTeam = team;
        switch (team) { // we need to let each player of each team to see the board like it is his side
            case 'B':
                this.reverseBoard();
                break;
            case 'R':
                this.rotateBoard();
                break;
            case 'G':
                this.rotateBoard();
                this.reverseBoard();
                break;
            default:
                break;
        }
    }

    /**
     * initializePieceBoard
     * Initialize the piece board so each piece will have: 1. team
     *                                                     2. type
     *                                                     3. position
     */
    private void initializePieceBoard() {
        pieceBoard[Defines.BLACK_ROOK - 1] = new Piece[2];
        pieceBoard[Defines.BLACK_KNIGHT - 1] = new Piece[2];
        pieceBoard[Defines.BLACK_BISHOP - 1] = new Piece[2];
        pieceBoard[Defines.BLACK_QUEEN - 1] = new Piece[1];
        pieceBoard[Defines.BLACK_KING - 1] = new Piece[1];
        pieceBoard[Defines.BLACK_PAWN - 1] = new Piece[8];
        pieceBoard[Defines.WHITE_ROOK - 1] = new Piece[2];
        pieceBoard[Defines.WHITE_KNIGHT - 1] = new Piece[2];
        pieceBoard[Defines.WHITE_BISHOP - 1] = new Piece[2];
        pieceBoard[Defines.WHITE_QUEEN - 1] = new Piece[1];
        pieceBoard[Defines.WHITE_KING - 1] = new Piece[1];
        pieceBoard[Defines.WHITE_PAWN - 1] = new Piece[8];
        pieceBoard[Defines.RED_ROOK - 1] = new Piece[2];
        pieceBoard[Defines.RED_KNIGHT - 1] = new Piece[2];
        pieceBoard[Defines.RED_BISHOP - 1] = new Piece[2];
        pieceBoard[Defines.RED_QUEEN - 1] = new Piece[1];
        pieceBoard[Defines.RED_KING - 1] = new Piece[1];
        pieceBoard[Defines.RED_PAWN - 1] = new Piece[8];
        pieceBoard[Defines.GREEN_ROOK - 1] = new Piece[2];
        pieceBoard[Defines.GREEN_KNIGHT - 1] = new Piece[2];
        pieceBoard[Defines.GREEN_BISHOP - 1] = new Piece[2];
        pieceBoard[Defines.GREEN_QUEEN - 1] = new Piece[1];
        pieceBoard[Defines.GREEN_KING - 1] = new Piece[1];
        pieceBoard[Defines.GREEN_PAWN - 1] = new Piece[8];
        pieceBoard[Defines.BLACK_ROOK - 1][0] = new Rook(3, 'r', 'B');
        pieceBoard[Defines.BLACK_ROOK - 1][1] = new Rook(10, 'r', 'B');
        pieceBoard[Defines.BLACK_KNIGHT - 1][0] = new Knight(4, 'n', 'B');
        pieceBoard[Defines.BLACK_KNIGHT - 1][1] = new Knight(9, 'n', 'B');
        pieceBoard[Defines.BLACK_BISHOP - 1][0] = new Bishop(5, 'b', 'B');
        pieceBoard[Defines.BLACK_BISHOP - 1][1] = new Bishop(8, 'b', 'B');
        pieceBoard[Defines.BLACK_QUEEN - 1][0] = new Queen(6, 'q', 'B');
        pieceBoard[Defines.BLACK_KING - 1][0] = new King(7, 'k', 'B');
        pieceBoard[Defines.BLACK_PAWN - 1][0] = new Pawn(17, 'p', 'B');
        pieceBoard[Defines.BLACK_PAWN - 1][1] = new Pawn(18, 'p', 'B');
        pieceBoard[Defines.BLACK_PAWN - 1][2] = new Pawn(19, 'p', 'B');
        pieceBoard[Defines.BLACK_PAWN - 1][3] = new Pawn(20, 'p', 'B');
        pieceBoard[Defines.BLACK_PAWN - 1][4] = new Pawn(21, 'p', 'B');
        pieceBoard[Defines.BLACK_PAWN - 1][5] = new Pawn(22, 'p', 'B');
        pieceBoard[Defines.BLACK_PAWN - 1][6] = new Pawn(23, 'p', 'B');
        pieceBoard[Defines.BLACK_PAWN - 1][7] = new Pawn(24, 'p', 'B');
        pieceBoard[Defines.WHITE_ROOK - 1][0] = new Rook(185, 'R', 'W');
        pieceBoard[Defines.WHITE_ROOK - 1][1] = new Rook(192, 'R', 'W');
        pieceBoard[Defines.WHITE_KNIGHT - 1][0] = new Knight(186, 'N', 'W');
        pieceBoard[Defines.WHITE_KNIGHT - 1][1] = new Knight(191, 'N', 'W');
        pieceBoard[Defines.WHITE_BISHOP - 1][0] = new Bishop(187, 'B', 'W');
        pieceBoard[Defines.WHITE_BISHOP - 1][1] = new Bishop(190, 'B', 'W');
        pieceBoard[Defines.WHITE_QUEEN - 1][0] = new Queen(189, 'Q', 'W');
        pieceBoard[Defines.WHITE_KING - 1][0] = new King(188, 'K', 'W');
        pieceBoard[Defines.WHITE_PAWN - 1][0] = new Pawn(171, 'P', 'W');
        pieceBoard[Defines.WHITE_PAWN - 1][1] = new Pawn(172, 'P', 'W');
        pieceBoard[Defines.WHITE_PAWN - 1][2] = new Pawn(173, 'P', 'W');
        pieceBoard[Defines.WHITE_PAWN - 1][3] = new Pawn(174, 'P', 'W');
        pieceBoard[Defines.WHITE_PAWN - 1][4] = new Pawn(175, 'P', 'W');
        pieceBoard[Defines.WHITE_PAWN - 1][5] = new Pawn(176, 'P', 'W');
        pieceBoard[Defines.WHITE_PAWN - 1][6] = new Pawn(177, 'P', 'W');
        pieceBoard[Defines.WHITE_PAWN - 1][7] = new Pawn(178, 'P', 'W');
        pieceBoard[Defines.RED_ROOK - 1][0] = new Rook(42, 'r', 'R');
        pieceBoard[Defines.RED_ROOK - 1][1] = new Rook(140, 'r', 'R');
        pieceBoard[Defines.RED_KNIGHT - 1][0] = new Knight(56, 'n', 'R');
        pieceBoard[Defines.RED_KNIGHT - 1][1] = new Knight(126, 'n', 'R');
        pieceBoard[Defines.RED_BISHOP - 1][0] = new Bishop(70, 'b', 'R');
        pieceBoard[Defines.RED_BISHOP - 1][1] = new Bishop(112, 'b', 'R');
        pieceBoard[Defines.RED_QUEEN - 1][0] = new Queen(84, 'q', 'R');
        pieceBoard[Defines.RED_KING - 1][0] = new King(98, 'k', 'R');
        pieceBoard[Defines.RED_PAWN - 1][0] = new Pawn(43, 'p', 'R');
        pieceBoard[Defines.RED_PAWN - 1][1] = new Pawn(57, 'p', 'R');
        pieceBoard[Defines.RED_PAWN - 1][2] = new Pawn(71, 'p', 'R');
        pieceBoard[Defines.RED_PAWN - 1][3] = new Pawn(85, 'p', 'R');
        pieceBoard[Defines.RED_PAWN - 1][4] = new Pawn(99, 'p', 'R');
        pieceBoard[Defines.RED_PAWN - 1][5] = new Pawn(113, 'p', 'R');
        pieceBoard[Defines.RED_PAWN - 1][6] = new Pawn(127, 'p', 'R');
        pieceBoard[Defines.RED_PAWN - 1][7] = new Pawn(141, 'p', 'R');
        pieceBoard[Defines.GREEN_ROOK - 1][0] = new Rook(55, 'R', 'G');
        pieceBoard[Defines.GREEN_ROOK - 1][1] = new Rook(153, 'R', 'G');
        pieceBoard[Defines.GREEN_KNIGHT - 1][0] = new Knight(69, 'N', 'G');
        pieceBoard[Defines.GREEN_KNIGHT - 1][1] = new Knight(139, 'N', 'G');
        pieceBoard[Defines.GREEN_BISHOP - 1][0] = new Bishop(83, 'B', 'G');
        pieceBoard[Defines.GREEN_BISHOP - 1][1] = new Bishop(125, 'B', 'G');
        pieceBoard[Defines.GREEN_QUEEN - 1][0] = new Queen(111, 'Q', 'G');
        pieceBoard[Defines.GREEN_KING - 1][0] = new King(97, 'K', 'G');
        pieceBoard[Defines.GREEN_PAWN - 1][0] = new Pawn(54, 'P', 'G');
        pieceBoard[Defines.GREEN_PAWN - 1][1] = new Pawn(68, 'P', 'G');
        pieceBoard[Defines.GREEN_PAWN - 1][2] = new Pawn(82, 'P', 'G');
        pieceBoard[Defines.GREEN_PAWN - 1][3] = new Pawn(96, 'P', 'G');
        pieceBoard[Defines.GREEN_PAWN - 1][4] = new Pawn(110, 'P', 'G');
        pieceBoard[Defines.GREEN_PAWN - 1][5] = new Pawn(124, 'P', 'G');
        pieceBoard[Defines.GREEN_PAWN - 1][6] = new Pawn(138, 'P', 'G');
        pieceBoard[Defines.GREEN_PAWN - 1][7] = new Pawn(152, 'P', 'G');
    }

    /**
     * setValue
     * Change the piece position after making a move
     * @param value - the value of the position (1 - Black Rook, 2 - Black Knight...)
     * @param newPosition - the position the piece is moving to
     * @param lastPosition - the position the piece came from
     */
    public void setValue(final int value, final int newPosition, final int lastPosition) {
        int rivalPieceValue = board[newPosition];
        if (rivalPieceValue != EMPTY_PIECE && rivalPieceValue != EN_PASSANT && rivalPieceValue != BAD_PLACE) {
            // In case we kill rival piece
            for (Piece p : pieceBoard[rivalPieceValue - 1]) {
                if (p.getPosition() == newPosition && p.getAlive()) {
                    p.setAlive();
                    break;
                }
            }
        } else if (rivalPieceValue == EN_PASSANT && value % Defines.NUMBER_OF_PIECES == 0) {
            // In case we kill rival pawn by en passant
            char pTurn = getPreviousTeam(turn);
            char ppTurn = getPreviousTeam(pTurn);
            if (this.myTeam == this.turn) {
                rivalPieceValue = board[this.enPassant + 1];
                board[this.enPassant + 1] = 0;
                for (Piece p : pieceBoard[rivalPieceValue - 1]) {
                    if (p.getPosition() == newPosition && p.getAlive()) {
                        p.setAlive();
                        break;
                    }
                }
            } else if (this.myTeam == pTurn) {
                rivalPieceValue = board[this.enPassant - BOARD_ROWS];
                board[this.enPassant - BOARD_ROWS] = 0;
                for (Piece p : pieceBoard[rivalPieceValue - 1]) {
                    if (p.getPosition() == newPosition && p.getAlive()) {
                        p.setAlive();
                        break;
                    }
                }
            } else if (this.myTeam == ppTurn) {
                rivalPieceValue = board[this.enPassant - 1];
                board[this.enPassant - 1] = 0;
                for (Piece p : pieceBoard[rivalPieceValue - 1]) {
                    if (p.getPosition() == newPosition && p.getAlive()) {
                        p.setAlive();
                        break;
                    }
                }
            } else {
                rivalPieceValue = board[this.enPassant + BOARD_ROWS];
                board[this.enPassant + BOARD_ROWS] = 0;
                for (Piece p : pieceBoard[rivalPieceValue - 1]) {
                    if (p.getPosition() == newPosition && p.getAlive()) {
                        p.setAlive();
                        break;
                    }
                }
            }
        }
        if (value == Defines.BLACK_KING || value == Defines.WHITE_KING ||
                value == Defines.RED_KING || value == Defines.GREEN_KING) {
            // In case the user has moved the king we need to check for castling
            this.setRookForCastling(value, lastPosition, newPosition);
        }
        board[newPosition] = value;
        board[lastPosition] = EMPTY_PIECE;
        for (Piece p : pieceBoard[value - 1]) {
            // In case the user has move his piece to an empty position
            if (p.getPosition() == lastPosition && p.getAlive()) {
                p.setPosition(newPosition);
                p.incrementMoves();
                break;
            }
        }
    }

    /**
     * setWaitingForPermission
     * @param waiting - true - if the user is waiting for manager approval on his move.
     *                  false - otherwise.
     */
    public void setWaitingForPermission(boolean waiting) {
        this.waitingForPermission = waiting;
    }

    /**
     * isWaitingForPermission
     * @return true - if the user is waiting for manager approval on his move.
     *         false - otherwise.
     */
    public boolean isWaitingForPermission() {
        return this.waitingForPermission;
    }

    /**
     * moveRook
     * Moving rook after castling to his new position
     * @param rookValue - the value of the rook so we can know to which team it belong
     * @param rookSide - left rook or right rook
     * @param newPosition - the new position of the rook after the castling
     */
    private void moveRook(int rookValue, int rookSide, int newPosition) {
        int RookLastPosition = this.pieceBoard[rookValue - 1][rookSide].getPosition();
        this.pieceBoard[rookValue - 1][rookSide].setPosition(newPosition);
        this.pieceBoard[rookValue - 1][rookSide].incrementMoves();
        this.board[newPosition] = this.board[RookLastPosition];
        this.board[RookLastPosition] = EMPTY_PIECE;
    }

    /**
     * setRookForCastling
     * @param value - the value of the king so we can know to which team it belong
     * @param lastPosition - the last position of the king before the castling
     * @param newPosition - the new position of the king after the castling
     */
    protected void setRookForCastling(int value, int lastPosition, int newPosition) {
        switch (value) {
            case Defines.BLACK_KING:
                switch (myTeam) {
                    case 'B':
                        if (lastPosition > newPosition) {
                            if (lastPosition - newPosition == 2) {
                                moveRook(Defines.BLACK_ROOK, 1, newPosition + 1);
                            }
                        } else if (newPosition - lastPosition == 2) {
                            moveRook(Defines.BLACK_ROOK, 0, newPosition - 1);
                        }
                        break;
                    case 'W':
                        if (lastPosition > newPosition) {
                            if (lastPosition - newPosition == 2) {
                                moveRook(Defines.BLACK_ROOK, 0, newPosition + 1);
                            }
                        } else if (newPosition - lastPosition == 2) {
                            moveRook(Defines.BLACK_ROOK, 1, newPosition - 1);
                        }
                        break;
                    case 'R':
                        //up
                        if (lastPosition > newPosition) {
                            if (lastPosition - newPosition == (2 * BOARD_ROWS)) {
                                moveRook(Defines.BLACK_ROOK, 1, newPosition + BOARD_ROWS);
                            }
                        } else if (newPosition - lastPosition == (2 * BOARD_ROWS)) {
                            moveRook(Defines.BLACK_ROOK, 0, newPosition - BOARD_ROWS);
                        }
                        break;
                    case 'G':
                        if (lastPosition > newPosition) {
                            if (lastPosition - newPosition == (2 * BOARD_ROWS)) {
                                moveRook(Defines.BLACK_ROOK, 0, newPosition + BOARD_ROWS);
                            }
                        } else if (newPosition - lastPosition == (2 * BOARD_ROWS)) {
                            moveRook(Defines.BLACK_ROOK, 1, newPosition - BOARD_ROWS);
                        }
                        break;
                }
                break;
            case Defines.WHITE_KING:
                switch (myTeam) {
                    case 'W':
                        if (lastPosition > newPosition) {
                            if (lastPosition - newPosition == 2) {
                                moveRook(Defines.WHITE_ROOK, 0, newPosition + 1);
                            }
                        } else if (newPosition - lastPosition == 2) {
                            moveRook(Defines.WHITE_ROOK, 1, newPosition - 1);
                        }
                        break;
                    case 'B':
                        if (lastPosition > newPosition) {
                            if (lastPosition - newPosition == 2) {
                                moveRook(Defines.WHITE_ROOK, 1, newPosition + 1);
                            }
                        } else if (newPosition - lastPosition == 2) {
                            moveRook(Defines.WHITE_ROOK, 0, newPosition - 1);
                        }
                        break;
                    case 'R':
                        if (lastPosition > newPosition) {
                            if (lastPosition - newPosition == (2 * BOARD_ROWS)) {
                                moveRook(Defines.WHITE_ROOK, 1, newPosition + BOARD_ROWS);
                            }
                        } else if (newPosition - lastPosition == (2 * BOARD_ROWS)) {
                            moveRook(Defines.WHITE_ROOK, 0, newPosition - BOARD_ROWS);
                        }
                        break;
                    case 'G':
                        if (lastPosition > newPosition) {
                            if (lastPosition - newPosition == (2 * BOARD_ROWS)) {
                                moveRook(Defines.WHITE_ROOK, 0, newPosition + BOARD_ROWS);
                            }
                        } else if (newPosition - lastPosition == (2 * BOARD_ROWS)) {
                            moveRook(Defines.WHITE_ROOK, 1, newPosition - BOARD_ROWS);
                        }
                        break;
                }
                break;
            case Defines.RED_KING:
                switch (myTeam) {
                    case 'R':
                        if (lastPosition > newPosition) {
                            if (lastPosition - newPosition == 2) {
                                moveRook(Defines.RED_ROOK, 0, newPosition + 1);
                            }
                        } else if (newPosition - lastPosition == 2) {
                            moveRook(Defines.RED_ROOK, 1, newPosition - 1);
                        }
                        break;
                    case 'B':
                        if (lastPosition > newPosition) {
                            if (lastPosition - newPosition == (2 * BOARD_ROWS)) {
                                moveRook(Defines.RED_ROOK, 1, newPosition + BOARD_ROWS);
                            }
                        } else if (newPosition - lastPosition == (2 * BOARD_ROWS)) {
                            moveRook(Defines.RED_ROOK, 0, newPosition - BOARD_ROWS);
                        }
                        break;
                    case 'W':
                        if (lastPosition > newPosition) {
                            if (lastPosition - newPosition == (2 * BOARD_ROWS)) {
                                moveRook(Defines.RED_ROOK, 0, newPosition + BOARD_ROWS);
                            }
                        } else if (newPosition - lastPosition == (2 * BOARD_ROWS)) {
                            moveRook(Defines.RED_ROOK, 1, newPosition - BOARD_ROWS);
                        }
                        break;
                    case 'G':
                        if (lastPosition > newPosition) {
                            if (lastPosition - newPosition == 2) {
                                moveRook(Defines.RED_ROOK, 1, newPosition + 1);
                            }
                        } else if (newPosition - lastPosition == 2) {
                            moveRook(Defines.RED_ROOK, 0, newPosition - 1);
                        }
                        break;
                }
                break;
            case Defines.GREEN_KING:
                switch (myTeam) {
                    case 'G':
                        if (lastPosition > newPosition) {
                            if (lastPosition - newPosition == 2) {
                                moveRook(Defines.GREEN_ROOK, 1, newPosition + 1);
                            }
                        } else if (newPosition - lastPosition == 2) {
                            moveRook(Defines.GREEN_ROOK, 0, newPosition - 1);
                        }
                        break;
                    case 'R':
                        if (lastPosition > newPosition) {
                            if (lastPosition - newPosition == 2) {
                                moveRook(Defines.GREEN_ROOK, 0, newPosition + 1);
                            }
                        } else if (newPosition - lastPosition == 2) {
                            moveRook(Defines.GREEN_ROOK, 1, newPosition - 1);
                        }
                        break;
                    case 'W':
                        if (lastPosition > newPosition) {
                            if (lastPosition - newPosition == (2 * BOARD_ROWS)) {
                                moveRook(Defines.GREEN_ROOK, 0, newPosition + BOARD_ROWS);
                            }
                        } else if (newPosition - lastPosition == (2 * BOARD_ROWS)) {
                            moveRook(Defines.GREEN_ROOK, 1, newPosition - BOARD_ROWS);
                        }
                        break;
                    case 'B':
                        if (lastPosition > newPosition) {
                            if (lastPosition - newPosition == (2 * BOARD_ROWS)) {
                                moveRook(Defines.GREEN_ROOK, 1, newPosition + BOARD_ROWS);
                            }
                        } else if (newPosition - lastPosition == (2 * BOARD_ROWS)) {
                            moveRook(Defines.GREEN_ROOK, 0, newPosition - BOARD_ROWS);
                        }
                        break;
                }
                break;
            default:
                return;
        }
    }

    /**
     * getValue
     * @param position - the position in the board we want to get its value
     * @return the value of a specific position in the board
     */
    public int getValue(final int position) {
        if (position < 0 || position >= BOARD_SIZE) {
            return EMPTY_PIECE;
        }
        return board[position];
    }

    /**
     * getMoves
     * @return - the number of moves that has been played in this game so far
     */
    public int getMoves() {
        return this.moves;
    }

    /**
     * reverseBoard
     * Rotate the board and the piece board in 180 degrees
     */
    protected void reverseBoard() {
        int[] tempBoard = new int[BOARD_SIZE];
        int j = 0;
        for (int i = BOARD_SIZE - 1; i >= 0; i--) {
            tempBoard[j] = board[i];
            j++;
        }
        board = tempBoard;

        for (int i = 0; i < MAX_VALUE; i++) {
            for(Piece piece : this.pieceBoard[i]) {
                piece.setPosition(BOARD_SIZE - 1 - piece.getPosition());
            }
        }
    }

    /**
     * rotateBoard
     * Rotate the board and the piece board in 90 degrees
     */
    private void rotateBoard() {
        int temp;
        for (int i = 0; i < BOARD_ROWS/2; i++) {
            for (int j = 0; j < BOARD_ROWS/2; j++) {
                temp = this.board[(i*BOARD_ROWS) + j];
                this.board[(i*BOARD_ROWS) + j] = this.board[(j * BOARD_ROWS) + (BOARD_ROWS - 1 - i)];
                this.board[(j * BOARD_ROWS) + (BOARD_ROWS - 1 - i)] = this.board[(BOARD_ROWS - 1 - i) * BOARD_ROWS +(BOARD_ROWS - 1 -j)];
                this.board[(BOARD_ROWS - 1 - i) * BOARD_ROWS +(BOARD_ROWS - 1 -j)] = this.board[(BOARD_ROWS - 1 - j)*BOARD_ROWS + i];
                this.board[(BOARD_ROWS - 1 - j)*BOARD_ROWS + i] = temp;
            }
        }
        for (int i = 0; i < MAX_VALUE; i++) {
            for(Piece piece : this.pieceBoard[i]) {
                int x = piece.getPosition() / BOARD_ROWS;
                int y = piece.getPosition() % BOARD_ROWS;
                piece.setPosition((BOARD_ROWS - 1 - y) * BOARD_ROWS + x);
            }
        }
    }

    /**
     * changeTurn
     * Changing the turn of the game according to teams position in the board
     */
    protected void changeTurn() {
        switch (this.turn) {
            case 'W':
                this.turn = 'G';
                this.calculatedMoves = 'W';
                break;
            case 'G':
                this.turn = 'B';
                this.calculatedMoves = 'G';
                break;
            case 'B':
                this.turn = 'R';
                this.calculatedMoves = 'B';
                break;
            case 'R':
                this.turn = 'W';
                this.calculatedMoves = 'R';
                break;
            default:
                break;
        }
    }

    /**
     * getIsManager
     * @return true - if the user is the manager of this game.
     *         false - otherwise.
     */
    public boolean getIsManager() {
        return this.isManager;
    }

    /**
     * turnHasChanged
     * Handle the game after a move has been played by any player. This function changing the game turn,
     * calculate the moves for the next team and increment the number of moves that has been played so far.
     */
    public void turnHasChanged() {
        this.changeTurn();
        this.calculateValidMoves();
        this.moves++;
    }

    /**
     * getMyTeam
     * @return the team of the user
     */
    public char getMyTeam() {
        return this.myTeam;
    }

    /**
     * checkIfChess
     * @param team - 'W', 'B', 'R', 'G'
     * @return true - if "team" is treated by other team.
     *         false - otherwise.
     */
    protected Boolean checkIfChess(char team) {
        ArrayList<Integer> possibleMoves = new ArrayList<Integer>();
        switch (team) {
            case 'B':
                for (int i = 0; i < MAX_VALUE; i++) {
                    for (Piece piece : pieceBoard[i]) {
                        if (piece.getTeam() != 'B') {
                            possibleMoves.addAll(piece.getPossibleMovesFourDGame(piece.getPosition(), board, this.turn));
                        }
                    }
                }
                if (possibleMoves.contains(pieceBoard[Defines.BLACK_KING - 1][0].getPosition())) {
                    return true;
                }
                break;
            case 'W':
                for (int i = 0; i < MAX_VALUE; i++) {
                    for (Piece piece : pieceBoard[i]) {
                        if (piece.getTeam() != 'W') {
                            possibleMoves.addAll(piece.getPossibleMovesFourDGame(piece.getPosition(), board, this.turn));
                        }
                    }
                }
                if (possibleMoves.contains(pieceBoard[Defines.WHITE_KING - 1][0].getPosition())) {
                    return true;
                }
                break;
            case 'R':
                for (int i = 0; i < MAX_VALUE; i++) {
                    for (Piece piece : pieceBoard[i]) {
                        if (piece.getTeam() != 'R') {
                            possibleMoves.addAll(piece.getPossibleMovesFourDGame(piece.getPosition(), board, this.turn));
                        }
                    }
                }
                if (possibleMoves.contains(pieceBoard[Defines.RED_KING - 1][0].getPosition())) {
                    return true;
                }
                break;
            case 'G':
                for (int i = 0; i < MAX_VALUE; i++) {
                    for (Piece piece : pieceBoard[i]) {
                        if (piece.getTeam() != 'G') {
                            possibleMoves.addAll(piece.getPossibleMovesFourDGame(piece.getPosition(), board, this.turn));
                        }
                    }
                }
                if (possibleMoves.contains(pieceBoard[Defines.GREEN_KING - 1][0].getPosition())) {
                    return true;
                }
                break;
            default:
                break;
        }
        return false;
    }

    /**
     * checkIfCreateChess
     * @param team - 'W', 'B', 'R', 'G'
     * @return true - if "team" is treating the other team (the other team is in chess).
     *         false - otherwise.
     */
    private Boolean checkIfCreateChess(char team) {
        ArrayList<Integer> possibleMoves = new ArrayList<Integer>();
        switch (team) {
            case 'B':
                for (int i = 0; i < MAX_VALUE; i++) {
                    for (Piece piece : pieceBoard[i]) {
                        if (piece.getTeam() == 'B') {
                            possibleMoves.addAll(piece.getPossibleMovesFourDGame(piece.getPosition(), board, this.turn));
                        }
                    }
                }
                if (possibleMoves.contains(pieceBoard[Defines.WHITE_KING - 1][0].getPosition()) ||
                        possibleMoves.contains(pieceBoard[Defines.RED_KING - 1][0].getPosition()) ||
                        possibleMoves.contains(pieceBoard[Defines.GREEN_KING - 1][0].getPosition())) {
                    return true;
                }
                break;
            case 'W':
                for (int i = 0; i < MAX_VALUE; i++) {
                    for (Piece piece : pieceBoard[i]) {
                        if (piece.getTeam() == 'W') {
                            possibleMoves.addAll(piece.getPossibleMovesFourDGame(piece.getPosition(), board, this.turn));
                        }
                    }
                }
                if (possibleMoves.contains(pieceBoard[Defines.BLACK_KING - 1][0].getPosition()) ||
                        possibleMoves.contains(pieceBoard[Defines.RED_KING - 1][0].getPosition()) ||
                        possibleMoves.contains(pieceBoard[Defines.GREEN_KING - 1][0].getPosition())) {
                    return true;
                }
                break;
            case 'R':
                for (int i = 0; i < MAX_VALUE; i++) {
                    for (Piece piece : pieceBoard[i]) {
                        if (piece.getTeam() == 'R') {
                            possibleMoves.addAll(piece.getPossibleMovesFourDGame(piece.getPosition(), board, this.turn));
                        }
                    }
                }
                if (possibleMoves.contains(pieceBoard[Defines.BLACK_KING - 1][0].getPosition()) ||
                        possibleMoves.contains(pieceBoard[Defines.WHITE_KING - 1][0].getPosition()) ||
                        possibleMoves.contains(pieceBoard[Defines.GREEN_KING - 1][0].getPosition())) {
                    return true;
                }
                break;
            case 'G':
                for (int i = 0; i < MAX_VALUE; i++) {
                    for (Piece piece : pieceBoard[i]) {
                        if (piece.getTeam() != 'G') {
                            possibleMoves.addAll(piece.getPossibleMovesFourDGame(piece.getPosition(), board, this.turn));
                        }
                    }
                }
                if (possibleMoves.contains(pieceBoard[Defines.BLACK_KING - 1][0].getPosition()) ||
                        possibleMoves.contains(pieceBoard[Defines.WHITE_KING - 1][0].getPosition()) ||
                        possibleMoves.contains(pieceBoard[Defines.RED_KING - 1][0].getPosition())) {
                    return true;
                }
                break;
            default:
                break;
        }
        return false;
    }

    /**
     * setValueForCheck
     * Make a move to check if this move is valid or not (if move will make the user to be in check
     * after commit it - the move is not valid). and than return the board to current state.
     * @param value - the value of the piece
     * @param newPosition - the position the piece is moving to
     * @param lastPosition - the position the piece has moved from
     * @param team - the team of the piece
     * @return true - if the move is valid.
     *         false - otherwise.
     */
    protected boolean setValueForCheck(final int value, final int newPosition, final int lastPosition, char team) {
        if (value >= MIN_VALUE && value <= MAX_VALUE) {
            int temp = board[newPosition];
            board[newPosition] = value;
            board[lastPosition] = EMPTY_PIECE;
            for (Piece p : pieceBoard[value - 1]) {
                if (p.getPosition() == lastPosition && p.getAlive()) {
                    p.setPosition(newPosition);
                    break;
                }
            }
            boolean inChess = checkIfChess(team);
            for (Piece p : pieceBoard[value - 1]) {
                if (p.getPosition() == newPosition && p.getAlive()) {
                    p.setPosition(lastPosition);
                    break;
                }
            }
            board[newPosition] = temp;
            board[lastPosition] = value;
            return inChess;
        }
        return false;
    }

    /**
     * calculateValidMoves
     * Calculate the valid moves that a player can perform in his turn.
     */
    protected void calculateValidMoves() {
        if (this.turn == this.calculatedMoves) {
            return;
        } else {
            this.validMoves.clear();
            this.calculatedMoves = this.turn;
        }
        ArrayList<Integer> pieceMoves = new ArrayList<Integer>();
        Iterator<Integer> iterator;
        int lastPosition = 0;
        switch (this.turn) {
            case 'W':
                for (int i = 0; i < MAX_VALUE; i++) {
                    for (Piece piece : pieceBoard[i]) {
                        if (piece.getTeam() == 'W') {
                            lastPosition = piece.getPosition();
                            if (piece.getType() == 'K') {
                                ((King) piece).setRightRookMoved(this.pieceBoard[Defines.WHITE_ROOK - 1][0].getMoves());
                                ((King) piece).setLeftRookMoved(this.pieceBoard[Defines.WHITE_ROOK - 1][1].getMoves());
                            }
                            pieceMoves.addAll(piece.getPossibleMovesFourDGame(lastPosition, board, this.myTeam));
                            if (!pieceMoves.isEmpty()) {
                                iterator = pieceMoves.iterator();
                                while (iterator.hasNext()) {
                                    int pos = iterator.next();
                                    if (setValueForCheck(board[lastPosition], pos, lastPosition, 'W')) {
                                        iterator.remove();
                                    }
                                }
                            }
                            if (!pieceMoves.isEmpty()) {
                                validMoves.put(lastPosition, new ArrayList<Integer>(pieceMoves));
                            }
                            pieceMoves.clear();
                        }
                    }
                }
                break;
            case 'B':
                for (int i = 0; i < MAX_VALUE; i++) {
                    for (Piece piece : pieceBoard[i]) {
                        if (piece.getTeam() == 'B') {
                            lastPosition = piece.getPosition();
                            if (piece.getType() == 'k') {
                                ((King) piece).setRightRookMoved(this.pieceBoard[Defines.BLACK_ROOK - 1][1].getMoves());
                                ((King) piece).setLeftRookMoved(this.pieceBoard[Defines.BLACK_ROOK - 1][0].getMoves());
                            }
                            pieceMoves.addAll(piece.getPossibleMovesFourDGame(lastPosition, board, this.myTeam));
                            if (!pieceMoves.isEmpty()) {
                                iterator = pieceMoves.iterator();
                                while (iterator.hasNext()) {
                                    int pos = iterator.next();
                                    if (setValueForCheck(board[lastPosition], pos, lastPosition, 'B')) {
                                        iterator.remove();
                                    }
                                }
                            }
                            if (!pieceMoves.isEmpty()) {
                                validMoves.put(lastPosition, new ArrayList<Integer>(pieceMoves));
                            }
                            pieceMoves.clear();
                        }
                    }
                }
                break;
            case 'R':
                for (int i = 0; i < MAX_VALUE; i++) {
                    for (Piece piece : pieceBoard[i]) {
                        if (piece.getTeam() == 'R') {
                            lastPosition = piece.getPosition();
                            if (piece.getType() == 'k') {
                                ((King) piece).setRightRookMoved(this.pieceBoard[Defines.RED_ROOK - 1][0].getMoves());
                                ((King) piece).setLeftRookMoved(this.pieceBoard[Defines.RED_ROOK - 1][1].getMoves());
                            }
                            pieceMoves.addAll(piece.getPossibleMovesFourDGame(lastPosition, board, this.myTeam));
                            if (!pieceMoves.isEmpty()) {
                                iterator = pieceMoves.iterator();
                                while (iterator.hasNext()) {
                                    int pos = iterator.next();
                                    if (setValueForCheck(board[lastPosition], pos, lastPosition, 'R')) {
                                        iterator.remove();
                                    }
                                }
                            }
                            if (!pieceMoves.isEmpty()) {
                                validMoves.put(lastPosition, new ArrayList<Integer>(pieceMoves));
                            }
                            pieceMoves.clear();
                        }
                    }
                }
                break;
            case 'G':
                for (int i = 0; i < MAX_VALUE; i++) {
                    for (Piece piece : pieceBoard[i]) {
                        if (piece.getTeam() == 'G') {
                            lastPosition = piece.getPosition();
                            if (piece.getType() == 'K') {
                                ((King) piece).setRightRookMoved(this.pieceBoard[Defines.GREEN_ROOK - 1][1].getMoves());
                                ((King) piece).setLeftRookMoved(this.pieceBoard[Defines.GREEN_ROOK - 1][0].getMoves());
                            }
                            pieceMoves.addAll(piece.getPossibleMovesFourDGame(lastPosition, board, this.myTeam));
                            if (!pieceMoves.isEmpty()) {
                                iterator = pieceMoves.iterator();
                                while (iterator.hasNext()) {
                                    int pos = iterator.next();
                                    if (setValueForCheck(board[lastPosition], pos, lastPosition, 'G')) {
                                        iterator.remove();
                                    }
                                }
                            }
                            if (!pieceMoves.isEmpty()) {
                                validMoves.put(lastPosition, new ArrayList<Integer>(pieceMoves));
                            }
                            pieceMoves.clear();
                        }
                    }
                }
                break;
            default:
                break;
        }
    }

    /**
     * getPossibleMoves
     * @param position - the position of the piece the user clicked on so he will get the valid
     *                   moves that it can make.
     * @return the valid moved for the piece in 'position'.
     */
    public ArrayList<Integer> getPossibleMoves(int position) {
        this.calculateValidMoves();
        if (this.validMoves.containsKey(position)) {
            return new ArrayList<>(this.validMoves.get(position));
        } else {
            return null;
        }
    }

    /**
     * checkForChess
     * @param turn - the team that the turn is it
     * @return 'P' - if there is a draw
     *         'M' - if there is a mate
     *         'C' - if there is a check
     *         'K' - otherwise.
     */
    public char calculateGameState(char turn) {
        if (checkForDraw(turn)) {
            this.gameState = 'P';
            return 'P';
        }
        if (this.validMoves.isEmpty() && moves > 4) {
            this.gameState = 'M';
            return 'M';
        }
        if (this.checkIfChess('W') || this.checkIfChess('R') || this.checkIfChess('B') || this.checkIfChess('G')) {
            this.gameState = 'C';
            return 'C';
        }
        this.gameState = 'K';
        return 'K';
    }

    /**
     * getPreviousTeam
     * @param turn - the team that it is it turn to play.
     * @return the previous team that has been played.
     */
    private char getPreviousTeam(char turn) {
        switch (turn) {
            case 'W':
                return 'R';
            case 'R':
                return 'B';
            case 'B':
                return 'G';
            case 'G':
                return 'W';
            default:
                return 'W';
        }
    }

    /**
     * getPreviousTeam
     * @param turn - the team that it is it turn to play.
     * @return the previous team that has been played.
     */
    public char getNextTeam(char turn) {
        switch (turn) {
            case 'W':
                return 'G';
            case 'G':
                return 'B';
            case 'B':
                return 'R';
            case 'R':
                return 'W';
            default:
                return 'W';
        }
    }

    /**
     * checkForDraw
     * @param turn - the team that the turn is belong to it.
     * @return true - if there is a draw. false - otherwise.
     */
    private boolean checkForDraw(char turn) {
        if (!checkIfChess(turn) && this.validMoves.isEmpty() && moves > 4) {
            return true;
        }
        int numOfKnightsAndBishops = 0;
        for (int i = 0; i < BOARD_SIZE; i++) {
            if (board[i] % Defines.NUMBER_OF_PIECES == Defines.BLACK_KNIGHT ||
                    board[i] % Defines.NUMBER_OF_PIECES == Defines.BLACK_BISHOP ||
                    board[i] % Defines.NUMBER_OF_PIECES == Defines.BLACK_KING) {
                numOfKnightsAndBishops++;
            } else if (board[i] != EMPTY_PIECE && board[i] != EN_PASSANT) {
                numOfKnightsAndBishops = 6;
                break;
            }
        }
        if (numOfKnightsAndBishops <= 5) {
            return true;
        }
        return false;
    }

    /**
     * getTurn
     * @return the team that the turn belongs to it.
     */
    public char getTurn(){
        return this.turn;
    }

    /**
     * checkEnPassant
     * Check if there was an en passant move and take care of it.
     * @param value - the value of the pawn that commit the en passant
     * @param newPosition - the position the pawn is moving to
     * @param lastPosition - the position the pawn came from
     */
    public void checkEnPassant(final int value, final int newPosition, final int lastPosition) {
        if (this.enPassant != -1) {
            if (this.board[this.enPassant] == EN_PASSANT) {
                this.board[this.enPassant] = EMPTY_PIECE;
            }
            this.enPassant = -1;
        }
        if (value % Defines.NUMBER_OF_PIECES == 0) {
            if (lastPosition - newPosition == (BOARD_ROWS * 2)) {
                this.enPassant = lastPosition - BOARD_ROWS;
                this.board[lastPosition - BOARD_ROWS] = EN_PASSANT;
            } else if (newPosition - lastPosition == (BOARD_ROWS  * 2)) {
                this.enPassant = lastPosition + BOARD_ROWS;
                this.board[lastPosition + BOARD_ROWS] = EN_PASSANT;
            } else if (lastPosition - newPosition == 2) {
                this.enPassant = lastPosition - 1;
                this.board[lastPosition - 1] = EN_PASSANT;
            } else if (newPosition - lastPosition == 2) {
                this.enPassant = lastPosition + 1;
                this.board[lastPosition + 1] = EN_PASSANT;
            }
        }
    }

    /**
     * needToChangePawn
     * @param position - the position the pawn is in it.
     * @param value - the value of the pawn
     * @return true - If a pawn has got to the end of the board.
     *         false - otherwise
     */
    public boolean needToChangePawn(int position, int value) {
        if (value % Defines.NUMBER_OF_PIECES == 0 &&
                (position < BOARD_ROWS ||
                        position > (BOARD_SIZE - BOARD_ROWS) ||
                        position % BOARD_ROWS == 0 ||
                        position % BOARD_ROWS == (BOARD_ROWS - 1))) {
            return true;
        }
        return false;
    }

    /**
     * replacePieceBoard
     * Replace the pawn with other piece in case the pawn is in the end of the board
     * @param position - the position the pawn is in it
     * @param team - the team of the pawn
     * @param type - the type of the piece the user would like to change the pawn to
     * @param value - the value of the pawn
     */
    private void replacePieceBoard(int position, char team, char type, int value) {
        Piece[] temp = new Piece[pieceBoard[value].length + 1];
        int i;
        for (i = 0; i < pieceBoard[value].length; i++) {
            temp[i] = pieceBoard[value][i];
        }
        switch (Character.toUpperCase(type)) {
            case 'Q':
                temp[i] = new Queen(position, type, team);
                break;
            case 'N':
                temp[i] = new Knight(position, type, team);
                break;
            case 'B':
                temp[i] = new Bishop(position, type, team);
                break;
            case 'R':
                temp[i] = new Rook(position, type, team);
                break;
            default:
                break;
        }
        pieceBoard[value] = temp;
        board[position] = value + 1;
    }

    /**
     * changePawn
     * changing the pawn in case it got to the end of the board
     * @param position - the position of the pawn
     * @param type - the piece we want to change the pawn to
     */
    public void changePawn(int position, char type) {
        int value = board[position];
        int index = 0;
        for (int i = 0; i < pieceBoard[value - 1].length; i++) {
            if (pieceBoard[value - 1][i].getPosition() == position &&
                    pieceBoard[value - 1][i].getAlive()) {
                index = i;
                break;
            }
        }
        pieceBoard[value - 1][index].setAlive();
        switch (type) {
            case 'Q':
                switch (this.turn) {
                    case 'W':
                        replacePieceBoard(position, this.turn, type, (Defines.WHITE_QUEEN - 1));
                        break;
                    case 'B':
                        replacePieceBoard(position, this.turn, Character.toLowerCase(type), (Defines.BLACK_QUEEN - 1));
                        break;
                    case 'R':
                        replacePieceBoard(position, this.turn, Character.toLowerCase(type), (Defines.RED_QUEEN - 1));
                        break;
                    case 'G':
                        replacePieceBoard(position, this.turn, type, (Defines.GREEN_QUEEN - 1));
                        break;
                    default:
                        break;
                }
                break;
            case 'N':
                switch (this.turn) {
                    case 'W':
                        replacePieceBoard(position, this.turn, type, (Defines.WHITE_KNIGHT - 1));
                        break;
                    case 'B':
                        replacePieceBoard(position, this.turn, Character.toLowerCase(type), (Defines.BLACK_KNIGHT - 1));
                        break;
                    case 'R':
                        replacePieceBoard(position, this.turn, Character.toLowerCase(type), (Defines.RED_KNIGHT - 1));
                        break;
                    case 'G':
                        replacePieceBoard(position, this.turn, type, (Defines.GREEN_KNIGHT - 1));
                        break;
                    default:
                        break;
                }
                break;
            case 'B':
                switch (this.turn) {
                    case 'W':
                        replacePieceBoard(position, this.turn, type, (Defines.WHITE_BISHOP - 1));
                        break;
                    case 'B':
                        replacePieceBoard(position, this.turn, Character.toLowerCase(type), (Defines.BLACK_BISHOP - 1));
                        break;
                    case 'R':
                        replacePieceBoard(position, this.turn, Character.toLowerCase(type), (Defines.RED_BISHOP - 1));
                        break;
                    case 'G':
                        replacePieceBoard(position, this.turn, type, (Defines.GREEN_BISHOP - 1));
                        break;
                    default:
                        break;
                }
                break;
            case 'R':
                switch (this.turn) {
                    case 'W':
                        replacePieceBoard(position, this.turn, type, (Defines.WHITE_ROOK - 1));
                        break;
                    case 'B':
                        replacePieceBoard(position, this.turn, Character.toLowerCase(type), (Defines.BLACK_ROOK - 1));
                        break;
                    case 'R':
                        replacePieceBoard(position, this.turn, Character.toLowerCase(type), (Defines.RED_ROOK - 1));
                        break;
                    case 'G':
                        replacePieceBoard(position, this.turn, type, (Defines.GREEN_ROOK - 1));
                        break;
                    default:
                        break;
                }
                break;
            default:
                break;
        }
    }

    /**
     * addMoveToList
     * Adding a move to the move list
     * @param value - the value of the piece that has moved
     * @param to - the position the piece has been moved to
     * @param from - the position the piece came from
     */
    public void addMoveToList(int value, int to, int from) {
        if (value == Defines.BLACK_KING || value == Defines.WHITE_KING ||
                value == Defines.RED_KING || value == Defines.GREEN_KING) {
            if (this.myTeam == 'B') {
                if (from > to) {
                    if (from - to == 2) {
                        if (value == Defines.WHITE_KING) {
                            this.moveItems.add(new MoveItem("O-O-O", "", value));
                            return;
                        } else { // Defines.BLACK_KING
                            this.moveItems.add(new MoveItem("O-O", "", value));
                            return;
                        }
                    }
                    if (from - to == (FourDGameBoard.BOARD_ROWS * 2)) {
                        if (value == Defines.GREEN_KING) {
                            this.moveItems.add(new MoveItem("O-O-O", "", value));
                            return;
                        } else { // Defines.RED_KING
                            this.moveItems.add(new MoveItem("O-O", "", value));
                            return;
                        }
                    }
                } else {
                    if (to - from == 2) {
                        if (value == Defines.WHITE_KING) {
                            this.moveItems.add(new MoveItem("O-O", "", value));
                            return;
                        } else { // Defines.BLACK_KING
                            this.moveItems.add(new MoveItem("O-O-O", "", value));
                            return;
                        }
                    }
                    if (to - from == (FourDGameBoard.BOARD_ROWS * 2)) {
                        if (value == Defines.RED_KING) {
                            this.moveItems.add(new MoveItem("O-O-O", "", value));
                            return;
                        } else { // Defines.GREEN_KING
                            this.moveItems.add(new MoveItem("O-O", "", value));
                            return;
                        }
                    }
                }
            } else if (this.myTeam == 'W') {
                if (from > to) {
                    if (from - to == 2) {
                        if (value == Defines.WHITE_KING) {
                            this.moveItems.add(new MoveItem("O-O", "", value));
                            return;
                        } else { // Defines.BLACK_KING
                            this.moveItems.add(new MoveItem("O-O-O", "", value));
                            return;
                        }
                    }
                    if (from - to == (FourDGameBoard.BOARD_ROWS * 2)) {
                        if (value == Defines.RED_KING) {
                            this.moveItems.add(new MoveItem("O-O-O", "", value));
                            return;
                        } else { // Defines.GREEN_KING
                            this.moveItems.add(new MoveItem("O-O", "", value));
                            return;
                        }
                    }
                } else {
                    if (to - from == 2) {
                        if (value == Defines.WHITE_KING) {
                            this.moveItems.add(new MoveItem("O-O-O", "", value));
                            return;
                        } else { //Define.BLACK_KING
                            this.moveItems.add(new MoveItem("O-O", "", value));
                            return;
                        }
                    }
                    if (to - from == (FourDGameBoard.BOARD_ROWS * 2)) {
                        if (value == Defines.GREEN_KING) {
                            this.moveItems.add(new MoveItem("O-O-O", "", value));
                            return;
                        } else { // Defines.RED_KING
                            this.moveItems.add(new MoveItem("O-O", "", value));
                            return;
                        }
                    }
                }
            } else if (this.myTeam == 'R') {
                if (from > to) {
                    if (from - to == 2) {
                        if (value == Defines.RED_KING) {
                            this.moveItems.add(new MoveItem("O-O-O", "", value));
                            return;
                        } else { // Defines.GREEN_KING
                            this.moveItems.add(new MoveItem("O-O", "", value));
                            return;
                        }
                    }
                    if (from - to == (FourDGameBoard.BOARD_ROWS * 2)) {
                        if (value == Defines.WHITE_KING) {
                            this.moveItems.add(new MoveItem("O-O-O", "", value));
                            return;
                        } else { // Defines.BLACK_KING
                            this.moveItems.add(new MoveItem("O-O", "", value));
                            return;
                        }
                    }
                } else {
                    if (to - from == 2) {
                        if (value == Defines.RED_KING) {
                            this.moveItems.add(new MoveItem("O-O", "", value));
                            return;
                        } else { // Defines.GREEN_KING
                            this.moveItems.add(new MoveItem("O-O-O", "", value));
                            return;
                        }
                    }
                    if (to - from == (FourDGameBoard.BOARD_ROWS * 2)) {
                        if (value == Defines.BLACK_KING) {
                            this.moveItems.add(new MoveItem("O-O-O", "", value));
                            return;
                        } else { // Defines.WHITE_KING
                            this.moveItems.add(new MoveItem("O-O", "", value));
                            return;
                        }
                    }
                }
            } else { // this.myTeam == 'G'
                if (from > to) {
                    if (from - to == 2) {
                        if (value == Defines.GREEN_KING) {
                            this.moveItems.add(new MoveItem("O-O-O", "", value));
                            return;
                        } else { // Defines.RED_KING
                            this.moveItems.add(new MoveItem("O-O", "", value));
                            return;
                        }
                    }
                    if (from - to == (FourDGameBoard.BOARD_ROWS * 2)) {
                        if (value == Defines.BLACK_KING) {
                            this.moveItems.add(new MoveItem("O-O-O", "", value));
                            return;
                        } else { // Defines.WHITE_KING
                            this.moveItems.add(new MoveItem("O-O", "", value));
                            return;
                        }
                    }
                } else {
                    if (to - from == 2) {
                        if (value == Defines.GREEN_KING) {
                            this.moveItems.add(new MoveItem("O-O", "", value));
                            return;
                        } else { // Defines.RED_KING
                            this.moveItems.add(new MoveItem("O-O-O", "", value));
                            return;
                        }
                    }
                    if (to - from == (FourDGameBoard.BOARD_ROWS * 2)) {
                        if (value == Defines.WHITE_KING) {
                            this.moveItems.add(new MoveItem("O-O-O", "", value));
                            return;
                        } else { // Defines.BLACK_KING
                            this.moveItems.add(new MoveItem("O-O", "", value));
                            return;
                        }
                    }
                }
            }
        }
        switch (this.myTeam) {
            case 'W':
                this.moveItems.add(new MoveItem(convertingPosition(from), convertingPosition(to), value));
                break;
            case 'B':
                this.moveItems.add(new MoveItem(convertingPosition(BOARD_SIZE - 1 - from), convertingPosition(BOARD_SIZE - 1 - to), value));
                break;
            case 'R':
                int i_from = from % BOARD_ROWS;
                int j_from = from / BOARD_ROWS;
                int i_to = to % BOARD_ROWS;
                int j_to = to / BOARD_ROWS;
                this.moveItems.add(new MoveItem(convertingPosition((i_from * BOARD_ROWS) + (BOARD_ROWS - 1) - j_from),
                        convertingPosition((i_to * BOARD_ROWS) + (BOARD_ROWS - 1) - j_to), value));
                break;
            case 'G':
                i_from = from % BOARD_ROWS;
                j_from = from / BOARD_ROWS;
                i_to = to % BOARD_ROWS;
                j_to = to / BOARD_ROWS;
                this.moveItems.add(new MoveItem(convertingPosition(BOARD_SIZE - 1 - ((i_from * BOARD_ROWS) + (BOARD_ROWS - 1) - j_from)),
                        convertingPosition(BOARD_SIZE - 1 - ((i_to * BOARD_ROWS) + (BOARD_ROWS - 1) - j_to)), value));
                break;
            default:
                break;
        }
    }

    /**
     * convertingPosition
     * Converting a number to a position on the board (for example: 56 -> h8)
     * @param position - the position we want to convert
     * @return the converting position
     */
    protected String convertingPosition(int position) {
        String pos = "";
        switch (position % BOARD_ROWS) {
            case 0:
                pos += "n";
                break;
            case 1:
                pos += "m";
                break;
            case 2:
                pos += "l";
                break;
            case 3:
                pos += "k";
                break;
            case 4:
                pos += "j";
                break;
            case 5:
                pos += "i";
                break;
            case 6:
                pos += "h";
                break;
            case 7:
                pos += "g";
                break;
            case 8:
                pos += "f";
                break;
            case 9:
                pos += "e";
                break;
            case 10:
                pos += "d";
                break;
            case 11:
                pos += "c";
                break;
            case 12:
                pos += "b";
                break;
            case 13:
                pos += "a";
                break;
        }
        switch (position / BOARD_ROWS) {
            case 0:
                pos += "14";
                break;
            case 1:
                pos += "13";
                break;
            case 2:
                pos += "12";
                break;
            case 3:
                pos += "11";
                break;
            case 4:
                pos += "10";
                break;
            case 5:
                pos += "9";
                break;
            case 6:
                pos += "8";
                break;
            case 7:
                pos += "7";
                break;
            case 8:
                pos += "6";
                break;
            case 9:
                pos += "5";
                break;
            case 10:
                pos += "4";
                break;
            case 11:
                pos += "3";
                break;
            case 12:
                pos += "2";
                break;
            case 13:
                pos += "1";
                break;
        }
        return pos;
    }

    /**
     * getMoveItems
     * @return the moves that has been played so far in the game.
     */
    public List<MoveItem> getMoveItems() {
        return this.moveItems;
    }

}