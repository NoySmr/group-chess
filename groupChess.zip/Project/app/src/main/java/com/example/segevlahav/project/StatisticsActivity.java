package com.example.segevlahav.project;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import java.io.File;

/**
 * StatisticsActivity
 * The screen of the statistics.
 */
public class StatisticsActivity extends AppCompatActivity {

    private Statistics statistics;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_statistics);

        File file = new File(getFilesDir() + "/" + Defines.STATISTICS_FILE);
        if(file.exists()) {
            this.statistics = FileManager.getStatistics(this);
        } else {
            this.statistics = new Statistics();
        }
        setStatistics();

        Button clearButton = (Button) findViewById(R.id.clearButton);
        clearButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                statistics = new Statistics();
                FileManager.saveStatistics(StatisticsActivity.this, statistics);
                refresh();
            }
        });
    }

    /**
     * setting the statistics by the user statistics
     */
    private void setStatistics() {
        TextView commonWins = (TextView) findViewById(R.id.commonWins);
        TextView commonDraws = (TextView) findViewById(R.id.commonDraws);
        TextView commonWinRate = (TextView) findViewById(R.id.commonWinsRate);
        TextView groupWins = (TextView) findViewById(R.id.groupWins);
        TextView groupDraws = (TextView) findViewById(R.id.groupDraws);
        TextView groupLosses = (TextView) findViewById(R.id.groupLosses);
        TextView groupWinRate = (TextView) findViewById(R.id.groupWinsRate);
        TextView fourDWins = (TextView) findViewById(R.id.fourDWins);
        TextView fourDDraws = (TextView) findViewById(R.id.fourDDraws);
        TextView fourDLosses = (TextView) findViewById(R.id.fourDLosses);
        TextView fourDWinRate = (TextView) findViewById(R.id.fourDWinsRate);

        commonWins.setText(this.statistics.getCommonGames());
        commonDraws.setText(this.statistics.getCommonDraw());
        commonWinRate.setText(this.statistics.getCommonWinRate());
        groupWins.setText(this.statistics.getGroupWin());
        groupDraws.setText(this.statistics.getGroupDraw());
        groupLosses.setText(this.statistics.getGroupLose());
        groupWinRate.setText(this.statistics.getGroupWinRate());
        fourDWins.setText(this.statistics.getFourDWin());
        fourDDraws.setText(this.statistics.getFourDDraw());
        fourDLosses.setText(this.statistics.getFourDLose());
        fourDWinRate.setText(this.statistics.getFourDWinRate());
    }

    @Override
    public void onBackPressed() { // return to the main menu activity
        Intent intent = new Intent(StatisticsActivity.this, MenuActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        super.onBackPressed();
    }

    /**
     * refresh
     * Refreshing the screen if data has changed
     */
    private void refresh() {
        this.finish();
        startActivity(this.getIntent());
    }
}
