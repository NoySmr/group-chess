package com.example.segevlahav.project;

/**
 * Defines
 * This class contains some values that repeat themselves in the code.
 */
public class Defines {
    public static final int WHITE_ROOK = 7;
    public static final int WHITE_KNIGHT = 8;
    public static final int WHITE_BISHOP = 9;
    public static final int WHITE_QUEEN = 10;
    public static final int WHITE_KING = 11;
    public static final int WHITE_PAWN = 12;
    public static final int BLACK_ROOK = 1;
    public static final int BLACK_KNIGHT = 2;
    public static final int BLACK_BISHOP = 3;
    public static final int BLACK_QUEEN = 4;
    public static final int BLACK_KING = 5;
    public static final int BLACK_PAWN = 6;
    public static final int RED_ROOK = 13;
    public static final int RED_KNIGHT = 14;
    public static final int RED_BISHOP = 15;
    public static final int RED_QUEEN = 16;
    public static final int RED_KING = 17;
    public static final int RED_PAWN = 18;
    public static final int GREEN_ROOK = 19;
    public static final int GREEN_KNIGHT = 20;
    public static final int GREEN_BISHOP = 21;
    public static final int GREEN_QUEEN = 22;
    public static final int GREEN_KING = 23;
    public static final int GREEN_PAWN = 24;
    public static final int NUMBER_OF_PIECES = 6;
    public static final String COMMON_GAME_FILE = "GamesName";
    public static final String GROUP_GAME_FILE = "GvGName";
    public static final String FOUR_D_GAME_FILE = "4DName";
    public static final String SETTINGS_FILE = "Settings";
    public static final String STATISTICS_FILE = "Statistics";
    public static final String SPACE = " ";
    public static final String COLON = ":";
    public static final String SEMICOLON = ";";
    public static final String TILDA = "~";
    public static final String PERCENT = "%";
}
