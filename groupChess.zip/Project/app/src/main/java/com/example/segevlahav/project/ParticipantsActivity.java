package com.example.segevlahav.project;

import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.List;

/**
 * ParticipantsActivity
 * The screen with the information about the participants in the game. Their name, phone number
 * and white team they play for.
 */
public class ParticipantsActivity extends AppCompatActivity {
    MyCustomAdapter dataAdapter = null; // the list of the participants adapter
    private String gameCode = ""; // the game code
    private String fileName = ""; // the game details file name


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Bundle bundle = getIntent().getExtras();
        try {
            gameCode = bundle.getString("gameCode");
            fileName = bundle.getString("fileName");
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        if (fileName.equals(Defines.COMMON_GAME_FILE)) {
            setContentView(R.layout.activity_participants);
            displayListView();
        } else if (fileName.equals(Defines.GROUP_GAME_FILE)) {
            setContentView(R.layout.activity_participants_two_teams);
            displayTwoListView();
        } else {
            setContentView(R.layout.activity_participants_four_teams);
            displayFourListView();
        }
    }

    /**
     * displayListView
     * In case we are at the common game list we only have one list for all participants.
     */
    private void displayListView() {
        GameDetails gameDetails = FileManager.getGameDetails(this, fileName);
        List<String> numbers = new ArrayList<String>(gameDetails.getPhoneNumbersByCode(gameCode));
        ArrayList<ContactInfo> contactInfoList = new ArrayList<ContactInfo>();

        for (String num : numbers) {
            String name = getContactName(this, num);
            if (name != null) {
                contactInfoList.add(new ContactInfo(name, num));
            } else {
                contactInfoList.add(new ContactInfo("Unknown", num));
            }
        }
        contactInfoList.add(new ContactInfo("You", ""));

        //create an ArrayAdaptar from the String Array
        dataAdapter = new MyCustomAdapter(this, R.layout.list_item_participants, contactInfoList);
        ListView listView = (ListView) findViewById(R.id.contactList);
        // Assign adapter to ListView
        listView.setAdapter(dataAdapter);
    }

    /**
     * displayTwoListView
     * In case we are at the group game list we have two lists. one for the black group and one for
     * the white group
     */
    private void displayTwoListView() {
        GameDetails gameDetails = FileManager.getGameDetails(this, fileName);
        GroupGameBoard gameBoard = (GroupGameBoard) FileManager.getGameBoard(this, gameCode);
        List<String> whiteNumbers = new ArrayList<String>(gameDetails.getTeamByCode(gameCode, 'W'));
        List<String> blackNumbers = new ArrayList<String>(gameDetails.getTeamByCode(gameCode, 'B'));
        ArrayList<ContactInfo> whiteContactInfoList = new ArrayList<ContactInfo>();
        ArrayList<ContactInfo> blackContactInfoList = new ArrayList<ContactInfo>();

        for (String num : whiteNumbers) {
            String name = getContactName(this, num);
            if (name != null) {
                whiteContactInfoList.add(new ContactInfo(name, num));
            } else {
                whiteContactInfoList.add(new ContactInfo("Unknown", num));
            }
        }

        for (String num : blackNumbers) {
            String name = getContactName(this, num);
            if (name != null) {
                blackContactInfoList.add(new ContactInfo(name, num));
            } else {
                blackContactInfoList.add(new ContactInfo("Unknown", num));
            }
        }

        switch (gameBoard.getMyTeam()) {
            case 'W':
                whiteContactInfoList.add(new ContactInfo("You", ""));
                break;
            case 'B':
                blackContactInfoList.add(new ContactInfo("You", ""));
                break;
        }

        //create an ArrayAdaptar from the String Array
        dataAdapter = new MyCustomAdapter(this, R.layout.list_item_participants, whiteContactInfoList);
        ListView listView = (ListView) findViewById(R.id.contactWhiteList);
        listView.setAdapter(dataAdapter);

        dataAdapter = new MyCustomAdapter(this, R.layout.list_item_participants, blackContactInfoList);
        listView = (ListView) findViewById(R.id.contactBlackList);
        listView.setAdapter(dataAdapter);
        // Assign adapter to ListView
    }

    /**
     * displayFourListView
     * In case we are at the 4D game list we have four lists. one for the black group, one for
     * the white group, one for the red group and one for the green group.
     */
    private void displayFourListView() {
        GameDetails gameDetails = FileManager.getGameDetails(this, fileName);
        FourDGameBoard gameBoard = (FourDGameBoard) FileManager.getGameBoard(this, gameCode);
        List<String> whiteNumbers = new ArrayList<String>(gameDetails.getTeamByCode(gameCode, 'W'));
        List<String> blackNumbers = new ArrayList<String>(gameDetails.getTeamByCode(gameCode, 'B'));
        List<String> redNumbers = new ArrayList<String>(gameDetails.getTeamByCode(gameCode, 'R'));
        List<String> greenNumbers = new ArrayList<String>(gameDetails.getTeamByCode(gameCode, 'G'));
        ArrayList<ContactInfo> whiteContactInfoList = new ArrayList<ContactInfo>();
        ArrayList<ContactInfo> blackContactInfoList = new ArrayList<ContactInfo>();
        ArrayList<ContactInfo> redContactInfoList = new ArrayList<ContactInfo>();
        ArrayList<ContactInfo> greenContactInfoList = new ArrayList<ContactInfo>();

        for (String num : whiteNumbers) {
            String name = getContactName(this, num);
            if (name != null) {
                whiteContactInfoList.add(new ContactInfo(name, num));
            } else {
                whiteContactInfoList.add(new ContactInfo("Unknown", num));
            }
        }

        for (String num : blackNumbers) {
            String name = getContactName(this, num);
            if (name != null) {
                blackContactInfoList.add(new ContactInfo(name, num));
            } else {
                blackContactInfoList.add(new ContactInfo("Unknown", num));
            }
        }

        for (String num : redNumbers) {
            String name = getContactName(this, num);
            if (name != null) {
                redContactInfoList.add(new ContactInfo(name, num));
            } else {
                redContactInfoList.add(new ContactInfo("Unknown", num));
            }
        }

        for (String num : greenNumbers) {
            String name = getContactName(this, num);
            if (name != null) {
                greenContactInfoList.add(new ContactInfo(name, num));
            } else {
                greenContactInfoList.add(new ContactInfo("Unknown", num));
            }
        }

        switch (gameBoard.getMyTeam()) {
            case 'W':
                whiteContactInfoList.add(new ContactInfo("You", ""));
                break;
            case 'B':
                blackContactInfoList.add(new ContactInfo("You", ""));
                break;
            case 'R':
                redContactInfoList.add(new ContactInfo("You", ""));
                break;
            case 'G':
                greenContactInfoList.add(new ContactInfo("You", ""));
                break;
        }

        dataAdapter = new MyCustomAdapter(this, R.layout.list_item_participants, whiteContactInfoList);
        ListView listView = (ListView) findViewById(R.id.contactWhiteList);
        listView.setAdapter(dataAdapter);

        dataAdapter = new MyCustomAdapter(this, R.layout.list_item_participants, blackContactInfoList);
        listView = (ListView) findViewById(R.id.contactBlackList);
        listView.setAdapter(dataAdapter);

        dataAdapter = new MyCustomAdapter(this, R.layout.list_item_participants, redContactInfoList);
        listView = (ListView) findViewById(R.id.contactRedList);
        listView.setAdapter(dataAdapter);

        dataAdapter = new MyCustomAdapter(this, R.layout.list_item_participants, greenContactInfoList);
        listView = (ListView) findViewById(R.id.contactGreenList);
        listView.setAdapter(dataAdapter);
    }

    /**
     * getContactName
     * @param context - the context
     * @param phoneNumber - contact phone number
     * @return - the contact name by their phone number.
     */
    public String getContactName(Context context, String phoneNumber) {
        ContentResolver cr = context.getContentResolver();
        Uri uri = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(phoneNumber));
        Cursor cursor = cr.query(uri, new String[]{ContactsContract.PhoneLookup.DISPLAY_NAME}, null, null, null);
        if (cursor == null) {
            return null;
        }
        String contactName = null;
        if(cursor.moveToFirst()) {
            contactName = cursor.getString(cursor.getColumnIndex(ContactsContract.PhoneLookup.DISPLAY_NAME));
        }

        if(cursor != null && !cursor.isClosed()) {
            cursor.close();
        }

        return contactName;
    }

    /**
     * MyCustomAdapter
     * To fit the contacts info to the list.
     */
    private class MyCustomAdapter extends ArrayAdapter<ContactInfo> {

        private ArrayList<ContactInfo> contactInfoList;

        /**
         * MyCustomAdapter
         * constructor
         * @param context
         * @param textViewResourceId
         * @param contactInfoList
         */
        public MyCustomAdapter(Context context, int textViewResourceId,
                               ArrayList<ContactInfo> contactInfoList) {
            super(context, textViewResourceId, contactInfoList);
            this.contactInfoList = new ArrayList<ContactInfo>();
            this.contactInfoList.addAll(contactInfoList);
        }

        private class ViewHolder {
            TextView number;
            TextView name;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {

            ViewHolder holder = null;
            Log.v("ConvertView", String.valueOf(position));

            if (convertView == null) {
                LayoutInflater vi = (LayoutInflater)getSystemService(
                        Context.LAYOUT_INFLATER_SERVICE);
                convertView = vi.inflate(R.layout.list_item_participants, null);

                holder = new ViewHolder();
                holder.number = (TextView) convertView.findViewById(R.id.participantsNumber);
                holder.name = (TextView) convertView.findViewById(R.id.participantsName);
                convertView.setTag(holder);

            }
            else {
                holder = (ViewHolder) convertView.getTag();
            }

            ContactInfo contactInfo = contactInfoList.get(position);
            if (contactInfo.getNumber().equals("")) {
                holder.number.setText("");
            } else {
                holder.number.setText(" (" + contactInfo.getNumber() + ")");
            }
            holder.name.setText(contactInfo.getName());
            holder.name.setTag(contactInfo);

            return convertView;
        }
    }
}
