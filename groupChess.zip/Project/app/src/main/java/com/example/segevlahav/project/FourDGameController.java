package com.example.segevlahav.project;

import android.app.Activity;
import android.app.FragmentManager;
import android.content.Context;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import java.io.File;
import java.util.List;

/**
 * FourDGameController
 * This class is responsible of managing the game. It also responsible for the display of the game.
 */
public class FourDGameController extends GameController {
    public static boolean iconsInitialized = false;
    public static Drawable[] validIcons = new Drawable[27];
    protected BoardAdapter boardAdapter;

    /**
     * FourDGameController
     * constructor
     * @param context
     * @param gameCode - the game board code
     * @param fileName - the game details file name
     */
    public FourDGameController(final Context context, String gameCode, String fileName) {

        super(context, gameCode, fileName);
        File file = new File(context.getFilesDir() + "/" + gameCode);
        if(file.exists()) {
            this.board = FileManager.getGameBoard(context, gameCode);
        } else {
            this.board = new FourDGameBoard(false);
        }
        this.changeBoardFrame(((FourDGameBoard)this.board).getMyTeam());
        checkTurnMatch();
        checkGameState();
    }

    /**
     * checkMyTurn
     * Checks if the piece the player clicked on belongs to the team that own the turn now
     * @param pieceNum - the piece the user clicked on
     * @return true - if the piece the played clicked on belongs to the team that own the turn now.
     *         false - otherwise.
     */
    protected boolean checkMyTurn(int pieceNum) {
        if ((pieceNum >= Defines.BLACK_ROOK && pieceNum <= Defines.BLACK_PAWN && this.turn == 'B')
                || (pieceNum >= Defines.WHITE_ROOK && pieceNum <= Defines.WHITE_PAWN && this.turn == 'W')
                || (pieceNum >= Defines.RED_ROOK && pieceNum <= Defines.RED_PAWN && this.turn == 'R')
                || (pieceNum >= Defines.GREEN_ROOK && pieceNum <= Defines.GREEN_PAWN && this.turn == 'G')) {
            return true;
        }
        return false;
    }

    /**
     * changeTurn
     * Changing the game turn by order
     */
    protected void changeTurn() {
        switch (this.turn) {
            case 'W':
                this.turn = 'G';
                break;
            case 'G':
                this.turn = 'B';
                break;
            case 'B':
                this.turn = 'R';
                break;
            case 'R':
                this.turn = 'W';
                break;
            default:
                break;
        }
    }

    /**
     * setBoardView
     * This function is responsible for communicate with the user. The function checks if the user can
     * make a move (if it is turn or not, if he won't be in check if he will make this move, if the
     * game is not ove and etc.)
     * @param boardView - the chess board
     */
    public void setBoardView(final GridView boardView) {
        this.boardView = boardView;
        this.boardAdapter = new FourDGameController.BoardAdapter();
        this.boardView.setAdapter(this.boardAdapter);
        this.boardView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View v,
                                    int position, long id) {
                if (board.getGameState() == 'M' || board.getGameState() == 'P') {
                    // If the game is already over
                    return;
                }
                if (!board.isWaitingForPermission()) {
                    // If the user made a move and waiting for the manager to approve it.
                    boolean canMakeThatMove = false;
                    checkTurnMatch();
                    if (selectedNum > 0) {
                        // If the user clicked on a piece (pawn/rook/knight...)
                        if (positionNum == position) {
                            // In case the user clicked the same piece twice - is valid moves will
                            // disappear from the board (return the be regular squares instead of green)
                            canMakeThatMove = true;
                        }
                        if (possibleMoves.contains(position)) {
                            // If the user clicked on green square (valid move)
                            canMakeThatMove = true;
                            if (board.getIsManager()) {
                                // If the user is the manager of the game he can make the move
                                // without waiting for permission, and then he send messages about
                                // the move for the other players.
                                board.setValue(selectedNum, position, positionNum);
                                board.addMoveToList(selectedNum, position, positionNum);
                                board.checkEnPassant(selectedNum, position, positionNum);
                                if (board.needToChangePawn(position, selectedNum)) {
                                    // In case a pawn is in thee end of the board the application will
                                    // open a dialog for the user so he will change is pawn to other
                                    // game piece.
                                    final Activity activity = (Activity) context;
                                    FragmentManager manager = activity.getFragmentManager();
                                    Bundle bundle = new Bundle();
                                    bundle.putInt("position", position);
                                    ChangePawnDialog changePawn = new ChangePawnDialog();
                                    if (turn == 'W') { // In case the pawn was white.
                                        bundle.putChar("team", 'W');
                                        changePawn.setArguments(bundle);
                                        changePawn.show(manager, "whiteChange");
                                        return;
                                    } else if (turn == 'B'){ // In case the pawn was black
                                        bundle.putChar("team", 'B');
                                        changePawn.setArguments(bundle);
                                        changePawn.show(manager, "blackChange");
                                        return;
                                    } else if (turn == 'R') { // In case the pawn was red
                                        bundle.putChar("team", 'R');
                                        changePawn.setArguments(bundle);
                                        changePawn.show(manager, "redChange");
                                        return;
                                    } else { // In case the pawn was green
                                        bundle.putChar("team", 'G');
                                        changePawn.setArguments(bundle);
                                        changePawn.show(manager, "greenChange");
                                        return;
                                    }
                                }
                                // Send sms about the move for the other players.
                                sendSmsMove(positionNum, position, turn, board.getMoves(), 'O');
                                // Change the game turn in the game controller and the game board.
                                board.turnHasChanged();
                                changeTurn();
                                // Make the move sound
                                mediaPlayer.start();
                                // Check if check/math or draw
                                checkGameState();
                                switch (board.getGameState()) {
                                    case 'M':
                                        if (board.turn == ((FourDGameBoard)board).getMyTeam()) {
                                            statistics.incrementFourDLose();
                                        } else {
                                            statistics.incrementFourDWin();
                                        }
                                        FileManager.saveStatistics(context, statistics);
                                        break;
                                    case 'P':
                                        statistics.incrementFourDDraw();
                                        FileManager.saveStatistics(context, statistics);
                                        break;
                                    default:
                                        break;
                                }
                                // Save the game board with the last move
                                FileManager.saveGameBoard(context, gameCode, (FourDGameBoard)board);
                            } else { // In case the user is not the manager
                                if (board.needToChangePawn(position, selectedNum)) {
                                    // In case a pawn is in thee end of the board the application will
                                    // open a dialog for the user so he will change is pawn to other
                                    // game piece.
                                    final Activity activity = (Activity) context;
                                    FragmentManager manager = activity.getFragmentManager();
                                    Bundle bundle = new Bundle();
                                    bundle.putInt("position", position);
                                    ChangePawnDialog changePawn = new ChangePawnDialog();
                                    if (turn == 'W') { // In case the pawn was white
                                        bundle.putChar("team", 'W');
                                        changePawn.setArguments(bundle);
                                        changePawn.show(manager, "whiteChange");
                                        return;
                                    } else if (turn == 'B'){ // In case the pawn was black
                                        bundle.putChar("team", 'B');
                                        changePawn.setArguments(bundle);
                                        changePawn.show(manager, "blackChange");
                                        return;
                                    } else if (turn == 'R') { // In case the pawn was red
                                        bundle.putChar("team", 'R');
                                        changePawn.setArguments(bundle);
                                        changePawn.show(manager, "redChange");
                                        return;
                                    } else { // In case the pawn was green
                                        bundle.putChar("team", 'G');
                                        changePawn.setArguments(bundle);
                                        changePawn.show(manager, "greenChange");
                                        return;
                                    }
                                }
                                // Sending message about the move the user want to operate to the
                                // manger and waiting for approval. The user can't play till he will
                                // get a message from the manager.
                                sendToManager(positionNum, position, turn, board.getMoves(), 'O');
                                board.setWaitingForPermission(true);
                            }
                        }
                        // Clearing the board from all the valid moves and reset the variables.
                        int j = 0;
                        for (Integer i : possibleMoves) {
                            ((ImageView) boardView.getChildAt(i)).setBackground(squaresColors.get(j++));
                        }
                        ((ImageView) boardView.getChildAt(positionNum)).setBackground(squaresColors.get(j++));
                        possibleMoves.clear();
                        squaresColors.clear();
                        selectedNum = 0;
                        positionNum = 0;
                        dataSetChanged();
                    }
                    if (((FourDGameBoard)board).getMyTeam() == turn && !canMakeThatMove) {
                        // If the user clicked a new piece and its the user's turn to play
                        selectedNum = board.getValue(position);
                        positionNum = position;
                        if (checkMyTurn(selectedNum)) {
                            // If the user clicked on a piece that belong to the team that the turn
                            // is it.
                            possibleMoves = board.getPossibleMoves(position);
                            if (possibleMoves != null) {
                                // If the piece can move
                                // Color the valid squares that the clicked piece can move to.
                                for (Integer i : possibleMoves) {
                                    squaresColors.add(((ImageView) boardView.getChildAt(i)).getBackground());
                                    ((ImageView) boardView.getChildAt(i)).setBackgroundResource(R.drawable.valid_icon_background);
                                }
                                squaresColors.add(((ImageView) boardView.getChildAt(positionNum)).getBackground());
                                ((ImageView) boardView.getChildAt(positionNum)).setBackgroundResource(R.drawable.chosen_icon_background);
                            } else {
                                selectedNum = 0;
                            }
                        } else {
                            selectedNum = 0;
                        }
                    }
                } else {
                    // In case we made a move and waiting for the manager to approve his move.
                    Toast.makeText(context, "Waiting for permission", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    /**
     * dataSetChanged
     * To notify the adapter that some data ha changed so it can show the new data on the screen.
     */
    protected void dataSetChanged() {
        if (boardAdapter != null) {
            boardAdapter.notifyDataSetChanged();
        }
    }

    /**
     * checkGameState
     * Checking if there was a check/mate/draw, and changing the picture of the game state (below the
     * board) accordingly.
     */
    protected void checkGameState() {
        switch (board.calculateGameState(turn)) {
            case 'C': // check
                ImageView imageView = (ImageView) ((Activity) context).findViewById(R.id.gameState);
                imageView.setImageResource(R.drawable.check);
                break;
            case 'M': // mate
                imageView = (ImageView) ((Activity) context).findViewById(R.id.gameState);
                imageView.setImageResource(R.drawable.mate);
                break;
            case 'P': // draw
                imageView = (ImageView) ((Activity) context).findViewById(R.id.gameState);
                imageView.setImageResource(R.drawable.draw);
                break;
            case 'K': // nothing
                imageView = (ImageView) ((Activity) context).findViewById(R.id.gameState);
                imageView.setImageResource(R.drawable.empty);
                break;
            default:
                imageView = (ImageView) ((Activity) context).findViewById(R.id.gameState);
                imageView.setImageResource(R.drawable.empty);
                break;
        }
    }

    /**
     * updateCell
     * Changing the picture in a specific cell in the greed view.
     * @param imageView - the image in the celll
     * @param position - the position of the cell
     */
    protected void updateCell(final ImageView imageView, final int position) {
        imageView.setImageDrawable(validIcons[board.getValue(position)]);
    }

    /**
     * initializeIcons
     * Initialize the icons of pieces.
     */
    protected synchronized void initializeIcons() {
        if (iconsInitialized) {
            return;
        }
        validIcons[FourDGameBoard.EMPTY_PIECE] = context.getResources().getDrawable(R.drawable.empty);

        validIcons[Defines.BLACK_ROOK] = context.getResources().getDrawable(R.drawable.black_rook);
        validIcons[Defines.BLACK_KNIGHT] = context.getResources().getDrawable(R.drawable.black_horse);
        validIcons[Defines.BLACK_BISHOP] = context.getResources().getDrawable(R.drawable.black_bishop);
        validIcons[Defines.BLACK_QUEEN] = context.getResources().getDrawable(R.drawable.black_queen);
        validIcons[Defines.BLACK_KING] = context.getResources().getDrawable(R.drawable.black_king);
        validIcons[Defines.BLACK_PAWN] = context.getResources().getDrawable(R.drawable.black_pawn);

        validIcons[Defines.WHITE_ROOK] = context.getResources().getDrawable(R.drawable.white_rook);
        validIcons[Defines.WHITE_KNIGHT] = context.getResources().getDrawable(R.drawable.white_horse);
        validIcons[Defines.WHITE_BISHOP] = context.getResources().getDrawable(R.drawable.white_bishop);
        validIcons[Defines.WHITE_QUEEN] = context.getResources().getDrawable(R.drawable.white_queen);
        validIcons[Defines.WHITE_KING] = context.getResources().getDrawable(R.drawable.white_king);
        validIcons[Defines.WHITE_PAWN] = context.getResources().getDrawable(R.drawable.white_pawn);

        validIcons[Defines.RED_ROOK] = context.getResources().getDrawable(R.drawable.red_rook);
        validIcons[Defines.RED_KNIGHT] = context.getResources().getDrawable(R.drawable.red_horse);
        validIcons[Defines.RED_BISHOP] = context.getResources().getDrawable(R.drawable.red_bishop);
        validIcons[Defines.RED_QUEEN] = context.getResources().getDrawable(R.drawable.red_queen);
        validIcons[Defines.RED_KING] = context.getResources().getDrawable(R.drawable.red_king);
        validIcons[Defines.RED_PAWN] = context.getResources().getDrawable(R.drawable.red_pawn);

        validIcons[Defines.GREEN_ROOK] = context.getResources().getDrawable(R.drawable.green_rook);
        validIcons[Defines.GREEN_KNIGHT] = context.getResources().getDrawable(R.drawable.green_horse);
        validIcons[Defines.GREEN_BISHOP] = context.getResources().getDrawable(R.drawable.green_bishop);
        validIcons[Defines.GREEN_QUEEN] = context.getResources().getDrawable(R.drawable.green_queen);
        validIcons[Defines.GREEN_KING] = context.getResources().getDrawable(R.drawable.green_king);
        validIcons[Defines.GREEN_PAWN] = context.getResources().getDrawable(R.drawable.green_pawn);

        validIcons[FourDGameBoard.EN_PASSANT] = context.getResources().getDrawable(R.drawable.x_pic);
        validIcons[FourDGameBoard.BAD_PLACE] = context.getResources().getDrawable(R.drawable.empty);
        iconsInitialized = true;
    }

    /**
     * sendSmsMove
     * If the manager has made a move he send sms to the other players about the move so they will
     * commit it in their game.
     * @param lastPosition - the position the piece moved from.
     * @param newPosition - the position the piece is moving to.
     * @param turn - the turn of the game.
     * @param moves - the moves that has been played so far (for synchronized).
     * @param changePawn - let the other players know if there were a pawn changing.
     */
    protected void sendSmsMove(int lastPosition, int newPosition, char turn, int moves, char changePawn) {
        SMSManager smsManager = new SMSManager();
        final GameDetails details = FileManager.getGameDetails(this.context, this.fileName);
        List<String> whiteNumbers = details.getTeamByCode(this.gameCode, 'W');
        List<String> blackNumbers = details.getTeamByCode(this.gameCode, 'B');
        List<String> redNumbers = details.getTeamByCode(this.gameCode, 'R');
        List<String> greenNumbers = details.getTeamByCode(this.gameCode, 'G');
        String whiteMessage = SMSManager.messageIdentifier + " o " + this.gameCode;
        String blackMessage = SMSManager.messageIdentifier + " o " + this.gameCode;
        String redMessage = SMSManager.messageIdentifier + " o " + this.gameCode;
        String greenMessage = SMSManager.messageIdentifier + " o " + this.gameCode;
        int x = lastPosition/FourDGameBoard.BOARD_ROWS;
        int y = lastPosition%FourDGameBoard.BOARD_ROWS;
        int r = newPosition/FourDGameBoard.BOARD_ROWS;
        int z = newPosition%FourDGameBoard.BOARD_ROWS;
        switch (turn) {
            case 'W':
                whiteMessage += Defines.SPACE + Integer.toString(lastPosition);
                whiteMessage += Defines.SPACE + Integer.toString(newPosition);
                blackMessage += Defines.SPACE + Integer.toString((FourDGameBoard.BOARD_SIZE - 1) - lastPosition);
                blackMessage += Defines.SPACE + Integer.toString((FourDGameBoard.BOARD_SIZE - 1) - newPosition);
                redMessage += Defines.SPACE + Integer.toString(((FourDGameBoard.BOARD_ROWS-y-1)*FourDGameBoard.BOARD_ROWS+x));
                redMessage += Defines.SPACE + Integer.toString(((FourDGameBoard.BOARD_ROWS-z-1)*FourDGameBoard.BOARD_ROWS+r));
                greenMessage += Defines.SPACE + Integer.toString(((y*FourDGameBoard.BOARD_ROWS)+FourDGameBoard.BOARD_ROWS-1-x));
                greenMessage += Defines.SPACE + Integer.toString(((z*FourDGameBoard.BOARD_ROWS)+FourDGameBoard.BOARD_ROWS-1-r));
                break;
            case 'B':
                blackMessage += Defines.SPACE + Integer.toString(lastPosition);
                blackMessage += Defines.SPACE + Integer.toString(newPosition);
                whiteMessage += Defines.SPACE + Integer.toString((FourDGameBoard.BOARD_SIZE - 1) - lastPosition);
                whiteMessage += Defines.SPACE + Integer.toString((FourDGameBoard.BOARD_SIZE - 1) - newPosition);
                greenMessage += Defines.SPACE + Integer.toString(((FourDGameBoard.BOARD_ROWS-1-y)*FourDGameBoard.BOARD_ROWS+x));
                greenMessage += Defines.SPACE + Integer.toString(((FourDGameBoard.BOARD_ROWS-1-z)*FourDGameBoard.BOARD_ROWS+r));
                redMessage += Defines.SPACE + Integer.toString(((y*FourDGameBoard.BOARD_ROWS)+FourDGameBoard.BOARD_ROWS-x-1));
                redMessage += Defines.SPACE + Integer.toString(((z*FourDGameBoard.BOARD_ROWS)+FourDGameBoard.BOARD_ROWS-r-1));
                break;
            case 'R':
                redMessage += Defines.SPACE + Integer.toString(lastPosition);
                redMessage += Defines.SPACE + Integer.toString(newPosition);
                greenMessage += Defines.SPACE + Integer.toString((FourDGameBoard.BOARD_SIZE - 1) - lastPosition);
                greenMessage += Defines.SPACE + Integer.toString((FourDGameBoard.BOARD_SIZE - 1) - newPosition);
                blackMessage += Defines.SPACE + Integer.toString(((FourDGameBoard.BOARD_ROWS-1-y)*FourDGameBoard.BOARD_ROWS+x));
                blackMessage += Defines.SPACE + Integer.toString(((FourDGameBoard.BOARD_ROWS-1-z)*FourDGameBoard.BOARD_ROWS+r));
                whiteMessage += Defines.SPACE + Integer.toString(((y*FourDGameBoard.BOARD_ROWS)+FourDGameBoard.BOARD_ROWS-x-1));
                whiteMessage += Defines.SPACE + Integer.toString(((z*FourDGameBoard.BOARD_ROWS)+FourDGameBoard.BOARD_ROWS-r-1));
                break;
            case 'G':
                greenMessage += Defines.SPACE + Integer.toString(lastPosition);
                greenMessage += Defines.SPACE + Integer.toString(newPosition);
                redMessage += Defines.SPACE + Integer.toString((FourDGameBoard.BOARD_SIZE - 1) - lastPosition);
                redMessage += Defines.SPACE + Integer.toString((FourDGameBoard.BOARD_SIZE - 1) - newPosition);
                whiteMessage += Defines.SPACE + Integer.toString(((FourDGameBoard.BOARD_ROWS-1-y)*FourDGameBoard.BOARD_ROWS+x));
                whiteMessage += Defines.SPACE + Integer.toString(((FourDGameBoard.BOARD_ROWS-1-z)*FourDGameBoard.BOARD_ROWS+r));
                blackMessage += Defines.SPACE + Integer.toString(((y*FourDGameBoard.BOARD_ROWS)+FourDGameBoard.BOARD_ROWS-1-x));
                blackMessage += Defines.SPACE + Integer.toString(((z*FourDGameBoard.BOARD_ROWS)+FourDGameBoard.BOARD_ROWS-1-r));
                break;
        }
        whiteMessage += Defines.SPACE + turn;
        blackMessage += Defines.SPACE + turn;
        redMessage += Defines.SPACE + turn;
        greenMessage += Defines.SPACE + turn;
        whiteMessage += Defines.SPACE + Integer.toString(moves);
        blackMessage += Defines.SPACE + Integer.toString(moves);
        redMessage += Defines.SPACE + Integer.toString(moves);
        greenMessage += Defines.SPACE + Integer.toString(moves);
        whiteMessage += Defines.SPACE + changePawn;
        blackMessage += Defines.SPACE + changePawn;
        redMessage += Defines.SPACE + changePawn;
        greenMessage += Defines.SPACE + changePawn;
        whiteMessage += Defines.TILDA;
        blackMessage += Defines.TILDA;
        redMessage += Defines.TILDA;
        greenMessage += Defines.TILDA;
        for (String smsNum : whiteNumbers) {
            smsManager.sendSMS(smsNum, whiteMessage);
        }
        for (String smsNum : blackNumbers) {
            smsManager.sendSMS(smsNum, blackMessage);
        }
        for (String smsNum : redNumbers) {
            smsManager.sendSMS(smsNum, redMessage);
        }
        for (String smsNum : greenNumbers) {
            smsManager.sendSMS(smsNum, greenMessage);
        }
    }

    /**
     * sendToManager
     * If the user is not the manager of the game he need to send message to the manager with the
     * play he want to do and wait fot the manager approval.
     * @param lastPosition - the position the piece moved from.
     * @param newPosition - the position the piece is moving to.
     * @param turn - the turn of the game.
     * @param moves - the moves that has been played so far (for synchronized).
     * @param changePawn - let the other players know if there were a pawn changing.
     */
    protected void sendToManager(int lastPosition, int newPosition, char turn, int moves, char changePawn) {
        SMSManager smsManager = new SMSManager();
        final GameDetails details = FileManager.getGameDetails(this.context, this.fileName);
        List<String> whiteNumbers = details.getTeamByCode(this.gameCode, 'W');
        String manager = details.getManager(this.gameCode);
        String managerMessage = SMSManager.messageIdentifier + " o " + this.gameCode;
        int x = lastPosition/FourDGameBoard.BOARD_ROWS;
        int y = lastPosition%FourDGameBoard.BOARD_ROWS;
        int r = newPosition/FourDGameBoard.BOARD_ROWS;
        int z = newPosition%FourDGameBoard.BOARD_ROWS;
        switch (turn) {
            case 'W':
                managerMessage += Defines.SPACE + Integer.toString(lastPosition);
                managerMessage += Defines.SPACE + Integer.toString(newPosition);
                break;
            case 'B':
                managerMessage += Defines.SPACE + Integer.toString(195 - lastPosition);
                managerMessage += Defines.SPACE + Integer.toString(195 - newPosition);
                break;
            case 'R':
                managerMessage += Defines.SPACE + Integer.toString(((y*FourDGameBoard.BOARD_ROWS)+FourDGameBoard.BOARD_ROWS-1-x));
                managerMessage += Defines.SPACE + Integer.toString(((z*FourDGameBoard.BOARD_ROWS)+FourDGameBoard.BOARD_ROWS-r-1));
                break;
            case 'G':
                managerMessage += Defines.SPACE + Integer.toString(((FourDGameBoard.BOARD_ROWS-1-y)*FourDGameBoard.BOARD_ROWS+x));
                managerMessage += Defines.SPACE + Integer.toString(((FourDGameBoard.BOARD_ROWS-z-1)*FourDGameBoard.BOARD_ROWS+r));
                break;
        }
        managerMessage += Defines.SPACE + turn;
        managerMessage += Defines.SPACE + Integer.toString(moves);
        managerMessage += Defines.SPACE + changePawn;
        managerMessage += Defines.TILDA;
        smsManager.sendSMS(manager, managerMessage);
    }

    /**
     * handleChangePawn
     * This function is called when the user has chose to which piece he would like to change his
     * pawn to when his pawn got to the end of the board.
     * @param type - the type of the piece the user want to change his pawn to
     * @param position - the position the pawn is in it when we need to change him
     */
    public void handleChangePawn(char type, int position) {
        if (board.getIsManager()) {
            board.changePawn(position, type);
            sendSmsMove(positionNum, position, turn, board.getMoves(), type);
            board.turnHasChanged();
            changeTurn();
            FileManager.saveGameBoard(context, gameCode, (FourDGameBoard) board);
            int j = 0;
            for (Integer i : possibleMoves) {
                ((ImageView) boardView.getChildAt(i)).setBackground(squaresColors.get(j++));
            }
            ((ImageView) boardView.getChildAt(positionNum)).setBackground(squaresColors.get(j++));
            possibleMoves.clear();
            squaresColors.clear();
            selectedNum = 0;
            positionNum = 0;
            dataSetChanged();
        } else {
            sendToManager(positionNum, position, turn, board.getMoves(), type);
            board.setWaitingForPermission(true);
        }
    }

    /**
     * changeBoardFrame
     * Changing the letters and numbers around the board according to the team that the turn is it.
     * @param team - the team that this is it turn.
     */
    protected void changeBoardFrame (char team) {
        TextView a = (TextView) ((Activity) context).findViewById(R.id.a);
        TextView b = (TextView) ((Activity) context).findViewById(R.id.b);
        TextView c = (TextView) ((Activity) context).findViewById(R.id.c);
        TextView d = (TextView) ((Activity) context).findViewById(R.id.d);
        TextView e = (TextView) ((Activity) context).findViewById(R.id.e);
        TextView f = (TextView) ((Activity) context).findViewById(R.id.f);
        TextView g = (TextView) ((Activity) context).findViewById(R.id.g);
        TextView h = (TextView) ((Activity) context).findViewById(R.id.h);
        TextView i = (TextView) ((Activity) context).findViewById(R.id.i);
        TextView j = (TextView) ((Activity) context).findViewById(R.id.j);
        TextView k = (TextView) ((Activity) context).findViewById(R.id.k);
        TextView l = (TextView) ((Activity) context).findViewById(R.id.l);
        TextView m = (TextView) ((Activity) context).findViewById(R.id.m);
        TextView n = (TextView) ((Activity) context).findViewById(R.id.n);
        TextView one = (TextView) ((Activity) context).findViewById(R.id.one);
        TextView two = (TextView) ((Activity) context).findViewById(R.id.two);
        TextView three = (TextView) ((Activity) context).findViewById(R.id.three);
        TextView four = (TextView) ((Activity) context).findViewById(R.id.four);
        TextView five = (TextView) ((Activity) context).findViewById(R.id.five);
        TextView six = (TextView) ((Activity) context).findViewById(R.id.six);
        TextView seven = (TextView) ((Activity) context).findViewById(R.id.seven);
        TextView eight = (TextView) ((Activity) context).findViewById(R.id.eight);
        TextView nine = (TextView) ((Activity) context).findViewById(R.id.nine);
        TextView ten = (TextView) ((Activity) context).findViewById(R.id.ten);
        TextView eleven = (TextView) ((Activity) context).findViewById(R.id.eleven);
        TextView twelve = (TextView) ((Activity) context).findViewById(R.id.twelve);
        TextView thirteen = (TextView) ((Activity) context).findViewById(R.id.thirteen);
        TextView fourteen = (TextView) ((Activity) context).findViewById(R.id.fourteen);
        switch (team) {
            case 'W':
                a.setText("a");
                b.setText("b");
                c.setText("c");
                d.setText("d");
                e.setText("e");
                f.setText("f");
                g.setText("g");
                h.setText("h");
                i.setText("i");
                j.setText("j");
                k.setText("k");
                l.setText("l");
                m.setText("m");
                n.setText("n");
                one.setText("1");
                two.setText("2");
                three.setText("3");
                four.setText("4");
                five.setText("5");
                six.setText("6");
                seven.setText("7");
                eight.setText("8");
                nine.setText("9");
                ten.setText("10");
                eleven.setText("11");
                twelve.setText("12");
                thirteen.setText("13");
                fourteen.setText("14");
                break;
            case 'B':
                a.setText("n");
                b.setText("m");
                c.setText("l");
                d.setText("k");
                e.setText("j");
                f.setText("i");
                g.setText("h");
                h.setText("g");
                i.setText("f");
                j.setText("e");
                k.setText("d");
                l.setText("c");
                m.setText("b");
                n.setText("a");
                one.setText("14");
                two.setText("13");
                three.setText("12");
                four.setText("11");
                five.setText("10");
                six.setText("9");
                seven.setText("8");
                eight.setText("7");
                nine.setText("6");
                ten.setText("5");
                eleven.setText("4");
                twelve.setText("3");
                thirteen.setText("2");
                fourteen.setText("1");
                break;
            case 'R':
                a.setText("1");
                b.setText("2");
                c.setText("3");
                d.setText("4");
                e.setText("5");
                f.setText("6");
                g.setText("7");
                h.setText("8");
                i.setText("9");
                j.setText("10");
                k.setText("11");
                l.setText("12");
                m.setText("13");
                n.setText("14");
                one.setText("n");
                two.setText("m");
                three.setText("l");
                four.setText("k");
                five.setText("j");
                six.setText("i");
                seven.setText("h");
                eight.setText("g");
                nine.setText("f");
                ten.setText("e");
                eleven.setText("d");
                twelve.setText("c");
                thirteen.setText("b");
                fourteen.setText("a");
                break;
            case 'G':
                a.setText("14");
                b.setText("13");
                c.setText("12");
                d.setText("11");
                e.setText("10");
                f.setText("9");
                g.setText("8");
                h.setText("7");
                i.setText("6");
                j.setText("5");
                k.setText("4");
                l.setText("3");
                m.setText("2");
                n.setText("1");
                one.setText("a");
                two.setText("b");
                three.setText("c");
                four.setText("d");
                five.setText("e");
                six.setText("f");
                seven.setText("g");
                eight.setText("h");
                nine.setText("i");
                ten.setText("j");
                eleven.setText("k");
                twelve.setText("l");
                thirteen.setText("m");
                fourteen.setText("n");
                break;
            default:
                a.setText("a");
                b.setText("b");
                c.setText("c");
                d.setText("d");
                e.setText("e");
                f.setText("f");
                g.setText("g");
                h.setText("h");
                i.setText("i");
                j.setText("j");
                k.setText("k");
                l.setText("l");
                m.setText("m");
                n.setText("n");
                one.setText("1");
                two.setText("2");
                three.setText("3");
                four.setText("4");
                five.setText("5");
                six.setText("6");
                seven.setText("7");
                eight.setText("8");
                nine.setText("9");
                ten.setText("10");
                eleven.setText("11");
                twelve.setText("12");
                thirteen.setText("13");
                fourteen.setText("14");
                break;
        }
    }

    /**
     * BoardAdapter
     * Adapt the chess board to the grid view.
     */
    protected class BoardAdapter extends BaseAdapter {
        private char black; // black squares
        private char white; // white squares

        /**
         * BoardAdapter
         * constructor
         */
        BoardAdapter () {
            // reading from the settings file the colors of the squares.
            Settings settings;
            File file = new File(context.getFilesDir() + "/" + Defines.SETTINGS_FILE);
            if(file.exists()) {
                settings = FileManager.getSettings(context);
            } else {
                settings = new Settings();
            }
            black = settings.getBlackTile();
            white = settings.getWhiteTile();
        }

        /**
         * getCount
         * @return the size of the board
         */
        @Override
        public int getCount() {
            return FourDGameBoard.BOARD_SIZE;
        }

        /**
         * getItem
         * @param position - the square the user clicked on in the board
         * @return the value in the square the user clicked on
         */
        @Override
        public Object getItem(final int position) {
            return board.getValue(position);
        }

        /**
         * getItemId
         * @param position - the square the user clicked on in the board
         * @return the position the user clicked on
         */
        @Override
        public long getItemId(final int position) {
            return position;
        }

        /**
         * getView
         * @param position
         * @param convertView
         * @param parent
         * @return the grid view with all the pieces and the squares
         */
        @Override
        public View getView(final int position, final View convertView, final ViewGroup parent) {
            if (convertView != null) {
                updateCell((ImageView) convertView, position);
                return convertView;
            }
            ImageView view;
            view = (ImageView) View.inflate(context, R.layout.brown, null);
            if(position % (FourDGameBoard.BOARD_ROWS * 2) < FourDGameBoard.BOARD_ROWS) {
                if (board.getValue(position) == FourDGameBoard.BAD_PLACE) {
                    view = (ImageView) View.inflate(context, R.layout.empty, null);
                } else {
                    if (position % 2 == 0) {
                        switch (black) {
                            case 'b':
                                view = (ImageView) View.inflate(context, R.layout.brown, null);
                                break;
                            case 'r':
                                view = (ImageView) View.inflate(context, R.layout.red, null);
                                break;
                            case 'g':
                                view = (ImageView) View.inflate(context, R.layout.green, null);
                                break;
                            default:
                                view = (ImageView) View.inflate(context, R.layout.brown, null);
                        }
                    } else {
                        switch (white) {
                            case 'w':
                                view = (ImageView) View.inflate(context, R.layout.white, null);
                                break;
                            case 'y':
                                view = (ImageView) View.inflate(context, R.layout.yellow, null);
                                break;
                            default:
                                view = (ImageView) View.inflate(context, R.layout.white, null);
                        }
                    }
                }
            } else {
                if (board.getValue(position) == FourDGameBoard.BAD_PLACE) {
                    view = (ImageView) View.inflate(context, R.layout.empty, null);
                } else {
                    if (position % 2 == 0) {
                        switch (white) {
                            case 'w':
                                view = (ImageView) View.inflate(context, R.layout.white, null);
                                break;
                            case 'y':
                                view = (ImageView) View.inflate(context, R.layout.yellow, null);
                                break;
                            default:
                                view = (ImageView) View.inflate(context, R.layout.white, null);
                        }
                    } else {
                        switch (black) {
                            case 'b':
                                view = (ImageView) View.inflate(context, R.layout.brown, null);
                                break;
                            case 'r':
                                view = (ImageView) View.inflate(context, R.layout.red, null);
                                break;
                            case 'g':
                                view = (ImageView) View.inflate(context, R.layout.green, null);
                                break;
                            default:
                                view = (ImageView) View.inflate(context, R.layout.brown, null);
                        }
                    }
                }
            }

            updateCell(view, position);

            return view;
        }
    }
}
